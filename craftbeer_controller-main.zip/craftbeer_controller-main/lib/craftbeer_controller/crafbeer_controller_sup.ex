defmodule CraftbeerController.CraftbeerControllerSup do

  use Task

  def start_link(_arg) do
    Task.start_link(&poll/0)
  end

  def poll() do
    receive do
    after
      60_000 ->
        check_for_recipe()
        poll()
    end
  end

  defp check_for_recipe() do
    # Call API & Persist
    start = CraftbeerController.Agent.value()

    case start do
      :started -> CraftbeerController.CraftbeerController.start
      :ended -> {:ended}
      :idle -> {:idle}
      _ -> {:unknown}
    end

  end


end
