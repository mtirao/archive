defmodule CraftbeerController.Application do
  # See https://hexdocs.pm/elixir/Application.html
  # for more information on OTP Applications
  @moduledoc false

  use Application

  def start(_type, _args) do
    children = [
      # Start the Telemetry supervisor
      CraftbeerControllerWeb.Telemetry,
      # Start the PubSub system
      {Phoenix.PubSub, name: CraftbeerController.PubSub},
      # Start the Endpoint (http/https)
      CraftbeerControllerWeb.Endpoint,
      # Start a worker by calling: CraftbeerController.Worker.start_link(arg)
      # {CraftbeerController.Worker, arg}

      CraftbeerController.CraftbeerControllerSup,

      {CraftbeerController.Agent, :idle}

    #  %{
    #    id: CraftbeerController.CraftbeerController,
    #    start: {CraftbeerController.CraftbeerController, :start_link, ["Hello World"]}
    #  }


    ]

    # See https://hexdocs.pm/elixir/Supervisor.html
    # for other strategies and supported options
    opts = [strategy: :one_for_one, name: CraftbeerController.Supervisor]
    Supervisor.start_link(children, opts)
  end

  # Tell Phoenix to update the endpoint configuration
  # whenever the application is updated.
  def config_change(changed, _new, removed) do
    CraftbeerControllerWeb.Endpoint.config_change(changed, removed)
    :ok
  end
end
