defmodule CraftbeerController.Agent do

  use Agent

  def start_link(initial_value) do
    Agent.start_link(fn -> initial_value end, name: __MODULE__)
  end

  def value do
    Agent.get(__MODULE__, & &1)
  end

  def start_beer do
    Agent.update(__MODULE__, fn(_state) -> :started end)
  end

  def end_beer do
    Agent.update(__MODULE__, fn(_state) -> :ended end)
  end

  def idle_beer do
    Agent.update(__MODULE__, fn(_state) -> :idle end)
  end


end
