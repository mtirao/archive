defmodule CraftbeerController.CraftbeerController do

  use CraftbeerControllerWeb, :controller

  require Logger

  def start do
    recipe = recipe_to_produce()

    case recipe do
      {:recipe, to_cook} -> {:ok, to_cook}
      _ -> {:error, :unstable_state}
    end
  end

  defp recipe_to_produce do
    url = "http://localhost:3000/api/craftbeer/recipe/cooking"


    case HTTPoison.get(url) do
      {:ok, %{status_code: 200, body: body}} ->
        recipes = Jason.decode!(body)
        get_first(:recipe, recipes)
      {:error, %{reason: _reason}} ->
        {:error, :internal_server_error}
    end
  end

  def stage_from_recipe(recipe) do
    url = "http://localhost:3000/api/craftbeer/recipe/#{recipe}/stages"


    case HTTPoison.get(url) do
      {:ok, %{status_code: 200, body: body}} ->
        recipes = Jason.decode!(body)
        get_first(:stage, recipes)
      {:error, %{reason: _reason}} ->
        {:error, :internal_server_error}
    end
  end

  defp get_first(type, recipes) do
    case recipes do
      [] -> :no_recipes
      [head | _tail] -> {type, head}
    end
  end


end
