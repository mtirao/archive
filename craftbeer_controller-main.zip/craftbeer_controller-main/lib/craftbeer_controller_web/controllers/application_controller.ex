defmodule CraftbeerControllerWeb.ApplicationController do

  use CraftbeerControllerWeb, :controller

  require Logger


  def  start_beer(conn, _params) do
    IO.puts("Start....")

    #GenServer.cast(CraftbeerController.CraftbeerController, {:show})

    CraftbeerController.Agent.start_beer


    send_resp(conn, :no_content, "")
  end

  def  end_beer(conn, _params) do
    IO.puts("End....")

    #GenServer.cast(CraftbeerController.CraftbeerController, {:show})

    CraftbeerController.Agent.end_beer


    send_resp(conn, :no_content, "")
  end

  def  idle(conn, _params) do
    IO.puts("Idle....")

    #GenServer.cast(CraftbeerController.CraftbeerController, {:show})

    CraftbeerController.Agent.idle_beer


    send_resp(conn, :no_content, "")
  end

end
