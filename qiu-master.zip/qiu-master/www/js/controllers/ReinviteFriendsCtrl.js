controllers.controller('ReinviteFriendsCtrl', [
  '$scope',
  'AnalyticsSrv',
  'FacebookService',
  '$cordovaToast',
  'UserSvc',
  'TurnSrv',
  '$stateParams',
  '$ionicLoading',
  '$cordovaSocialSharing',
  '$ionicHistory',
  '$filter',
  '$state',
  'UtilsSrv',
  function($scope,AnalyticsSrv,FacebookService,$cordovaToast,UserSvc,TurnSrv,$stateParams,$ionicLoading,$cordovaSocialSharing,$ionicHistory,$filter,$state,UtilsSrv) {

    AnalyticsSrv.trackView("Reinvite View");

    $scope.friends = [];

    var nextFriendsUrl = "";
    $scope.infiniteScroll = false;

    $scope.goBack = function(){
      $ionicHistory.goBack();
    }

    $scope.$on('goBack', function(event, obj) {
      $scope.$parent.activities.show = false;
      $scope.$parent.activities.title = "Actividades";
      $ionicHistory.goBack();
    });

    $scope.$on('$ionicView.enter', function() {
      if($state.current.name == "tab.reinvitefriends_act"){
        setHeader();
      }
    });

    function checkIfExists(friends,idFriends,isNew){
      UserSvc.checkIfExists(idFriends).then(function(data){
        if(data.code !== 200){
          //handle error
          return;
        }
        var friendsRegistered = data.result;
        var filteredFriends = [];

        for (var i = 0; i < friends.length; i++) {
          for (var j = 0; j < friendsRegistered.length; j++) {
            if(friendsRegistered[j].fbLogin == friends[i].id){
              filteredFriends.push(friends[i]);
            }
          };
        };

        getChecked($stateParams.idTurn,filteredFriends,isNew);

      },function(error){
      });
    }


    function getNextFriends(){
      FacebookService.getNextFriends(nextFriendsUrl).then(function(data){
        if(data.status !== 200){
          return;
        }
        var newFriends = data.data.data;

        if(!data.data.paging.next || newFriends.length == 0){
          $scope.infiniteScroll = false;
        }else{
          $scope.infiniteScroll = true;
          nextFriendsUrl = data.data.paging.next;
        }

        if(newFriends.length > 0){
          var idFriends = [];
          for (var i = 0; i < newFriends.length; i++) {
            idFriends.push(newFriends[i].id);
          };
          checkIfExists(newFriends,idFriends,true);
        }else{
          $scope.infiniteScroll = false;
        }
      },function(error){
      });
    }
    var firstLoad = false;
    $scope.loadMore = function(){
      $scope.$broadcast('scroll.infiniteScrollComplete');
      if(firstLoad && $scope.infiniteScroll){
        $scope.infiniteScroll = false;
        getNextFriends();
      }
      firstLoad = true;
    }

    function removeAlreadyInvited(friends,isNew){
      for (var i = friends.length-1; i >= 0; i--) {
        if(friends[i].selected !== null && friends[i].selected){
          friends.splice(i,1);
        }
      };

      if(!isNew){
        $scope.friends = friends;
      }else{
        for (var i = 0; i < friends.length; i++) {
          $scope.friends.push(friends[i]);
        };
      }
    }

    function getChecked(idTurn,friends,isNew){
      TurnSrv.getChecked(idTurn).then(function(data){
        if(data.code !== 200){
          // handle error
          return;
        }

        var invitations = data.result.invitations;
        for (var i = 0; i < friends.length; i++) {
          for (var j = 0; j < invitations.length; j++) {
            if(friends[i].id == invitations[j].fbLogin){
              friends[i].selected = true;
            };
          };
        };

        removeAlreadyInvited(friends,isNew);

      },function(error){

      });
    }

    function getSelectedFriends(){
      var usersInvited = $filter('filter')($scope.friends, {selected: true});
      var idsFb = [];

      for (var i = 0; i < usersInvited.length; i++) {
        idsFb.push(usersInvited[i].id);
      };

      return idsFb;
    }

    function addFriends(idsFb){
      AnalyticsSrv.trackEvent("ReinviteFriends","Action","AddFriends",1);
      TurnSrv.addFriends($stateParams.idTurn,idsFb).then(function(data){
        if(data.code !== 200){
          // handle error
          return;
        }
        $ionicLoading.hide();
        $ionicHistory.goBack();

      },function(err){
        $ionicLoading.hide();
      });
    }

    $scope.goToReservationCard = function(){
      AnalyticsSrv.trackEvent("InviteFriends","Action","Invite New Friends",1);
      var idsFb = getSelectedFriends();

      $ionicLoading.show({template: 'Invitando Amigos...'});
      addFriends(idsFb);
    }

    function getFriends(){

      var token = window.localStorage["tokenFB"];
      $ionicLoading.show({template: 'Obteniendo amigos...'});
      FacebookService.getFriends(token).then(function(data){
        $ionicLoading.hide();
        var friends = data.data;
        if(friends.length == 0){
          UtilsSrv.showPopup("No tiene amigos usando Qiu",1500);
        }else{
          $scope.infiniteScroll = true;
          if(!data.paging.next){
            $scope.infiniteScroll = false;
          }else{
            nextFriendsUrl = data.paging.next;
          }

          var idFriends = [];
          for (var i = 0; i < friends.length; i++) {
            idFriends.push(friends[i].id);
          };
          checkIfExists(friends,idFriends,false);
        }
      },function(error){
        $ionicLoading.hide();
        handleFacebookErrors(error);
      });

    }

    function handleFacebookErrors(error){
      if(!error){
        UtilsSrv.showPopup("Hubo un error",1500);
        return;
      }
      if(error.error.code == 190){
        if(error.error.error_subcode == 463){
          UtilsSrv.showPopup("La sesion de Facebook ha expirado por favor loguearse nuevamente",1500);
        }else if(error.error.error_subcode == 467){
          UtilsSrv.showPopup("Por favor loguearse nuevamente",1500);
        }
      }else{
        UtilsSrv.showPopup("Hubo un error",1500);
      }
    }

    $scope.share = function(){
      AnalyticsSrv.trackEvent("InviteFriends","Action","Reinvitar via...",1);
      $ionicLoading.show({template:"Compartiendo..."});

      var link = "http://qiupro.com/test/verify/"+$stateParams.idTurn;

      $cordovaSocialSharing
          .share("Usa qiu", "tema", "http://cdn2.uvnimg.com/3c/a6/921400d0499cb2980b77c519307e/futbol-generic-entry-point.jpg",  link) // Share via native share sheet
          .then(function(result) {
            // Success!
            $ionicLoading.hide();
            getFriends();
          }, function(err) {
            // An error occured. Show a message to the user
            $ionicLoading.hide();
          });
    }

    function setHeader(){
      $scope.$parent.activities.show = true;
      $scope.$parent.activities.shareButton = false;
      $scope.$parent.activities.title = "Invita Amigos";
    }

    setHeader();
    getFriends();

  }])