controllers.controller('StateTurnCtrl', [
	'$scope',
	'TurnSrv',
	'$stateParams',
	'$ionicHistory',
	'$state',
	'$cordovaToast',
	'$ionicLoading',
	'UtilsSrv',
	'AnalyticsSrv',
	function($scope,TurnSrv,$stateParams,$ionicHistory,$state,$cordovaToast,$ionicLoading,UtilsSrv,AnalyticsSrv){

		AnalyticsSrv.trackView("State View");

		$scope.$parent.activities.show = true;
		$scope.$parent.activities.shareButton = false;
		$scope.$parent.activities.title = "Estado Turno";
		$scope.$on('goBack', function(event, obj) {
			$scope.$parent.activities.title = "Ficha de Reserva";
			$ionicHistory.goBack();
		});

		var turnId = $stateParams.turnId;

		$scope.listCanSwipe = true;

		$scope.invited = [];

		$scope.imagetest = "img/clock.png";

		function getDataInvited(){
			$ionicLoading.show({template:"Cargando estado..."});
			TurnSrv.getDataInvited(turnId).then(function(data){
				$ionicLoading.hide();
				$scope.$broadcast('scroll.refreshComplete');

				if(!data){
					UtilsSrv.showPopup("Hubo un error al traer los jugadores",2000);
          			return;
				}

				if(data.code !== 200){
					// handle error
					// $cordovaToast.show('Hubo un error al cargar el estado.', 'short', 'center');
					UtilsSrv.showPopup('Hubo un error al cargar el estado.',1500);
					$scope.$broadcast('scroll.refreshComplete');
					return;
				}

				var invited = data.result.invitations;
				for (var i = 0; i < invited.length; i++) {
					if(invited[i].accepted == null){
						invited[i].state = "Sin confirmar";
						invited[i].icon = "ion-help";
						invited[i].iconColor = "#675E5E";
						// invited[i].icon = "img/face_example.jpeg";
					}else if(invited[i].accepted){
						invited[i].state = "Acepto la invitacion";
						invited[i].icon = "ion-checkmark-round";
						invited[i].iconColor = "#299C29";
					}else{
						invited[i].state = "Rechazo la invitacion";
						invited[i].icon = "ion-close-round";
						invited[i].iconColor = "#A74C4C";
						// invited[i].icon = "img/phone.png";
					}
				};

				$scope.invited = invited;

			},function(error){
				$ionicLoading.hide();
				UtilsSrv.showPopup('Hubo un error al cargar el estado.',1500);
				$scope.$broadcast('scroll.refreshComplete');
			});
		}


		$scope.doRefresh = function(){
			getDataInvited();
		}

		$scope.addInvited = function(){

			if($state.current.name == "tab.stateTurn"){
				$state.go("tab.reinvitefriends",{"idTurn":turnId});
			}
			if($state.current.name == "tab.stateTurn_act"){
				$state.go("tab.reinvitefriends_act",{"idTurn":turnId});
			}

		};

		function removeFromList(fbLogin){
			for (var i = 0; i < $scope.invited.length; i++) {
				if($scope.invited[i].fbLogin == fbLogin){
					$scope.invited.splice(i, 1);
					// $cordovaToast.show('Se elimino la invitacion', 'short', 'center');
					UtilsSrv.showPopup('Se elimino la invitacion',1500);
					break;
				}
			};
		}
		function configure(){
			if($stateParams.type == "invitation"){
				$scope.listCanSwipe = false;
			}
		}
		$scope.removeInvited = function(deviceId,fbLogin){
			if(window.localStorage["deviceId"] == deviceId){
				// $cordovaToast.show("No puede elimiarse de su propia reserva","short","center");
				AnalyticsSrv.trackEvent("Status","Action","Intento Eliminarse a si mismo",1);
				UtilsSrv.showPopup('No puede elimiarse de su propia reserva',1500);
				return;
			}
			AnalyticsSrv.trackEvent("Status","Action","Elimino a jugador",1);
			$ionicLoading.show({template:"Eliminando invitado..."});
			TurnSrv.removeInvited(turnId,deviceId,fbLogin).then(function(data){
				$ionicLoading.hide();
				if(data.code !== 200){
					// handle error
					// $cordovaToast.show("Hubo un error al eliminar el invitado, por favor int\u00e9ntelo nuevamente","short","center");
					UtilsSrv.showPopup('Hubo un error al eliminar el invitado, por favor int\u00e9ntelo nuevamente',1500);
					return;
				}
				removeFromList(fbLogin);
				// $cordovaToast.show('Se elimino la invitacion', 'short', 'center');

			},function(error){
				$ionicLoading.hide();
				// $cordovaToast.show("Hubo un error al eliminar el invitado, por favor int\u00e9ntelo nuevamente","short","center");
				UtilsSrv.showPopup('Hubo un error al eliminar el invitado, por favor int\u00e9ntelo nuevamente',1500);
			});
		}

		configure();
		getDataInvited();

	}]);