controllers.controller("VotationCtrl",[
	'$scope',
	'AnalyticsSrv',
	'$stateParams',
	'TurnSrv',
	'$ionicLoading',
	'UtilsSrv',
	'$ionicHistory',
	function($scope,AnalyticsSrv,$stateParams,TurnSrv,$ionicLoading,UtilsSrv,$ionicHistory){
		var idTurn = $stateParams.idTurn;

		AnalyticsSrv.trackView("Votation View");

		$scope.canvote = true;
		$scope.date = {};
		$scope.players = [];

		$scope.$on('goBack', function(event, obj) {
			$scope.$parent.activities.show = true;
			$scope.$parent.activities.title = "Partidos Jugados";
			$ionicHistory.goBack();
		});

		function getFriendsToVote(){
			$ionicLoading.show({template:"Obteniendo jugadores..."});
			TurnSrv.getFriendsToVote(idTurn).then(function(data){
				$ionicLoading.hide();
				if(data.code !== 200){
					// handle error
					return;
				}

				var hasVoted = data.result.hasVoted;
				$scope.date = data.result.date;
				if(hasVoted){
					$scope.msgAlreadyVoted = true;
					$scope.canvote = false;
				}
				$scope.players = data.result.players;

			},function(error){
				$ionicLoading.hide();
				UtilsSrv.showPopup("Hubo un error al obtener jugadores",1500);
				$ionicHistory.goBack();
			});
		}

		function setHeader(){
			$scope.$parent.activities.show = true;
			$scope.$parent.activities.shareButton = false;
			$scope.$parent.activities.title = "Vot\u00e1 a tus amigos";
		}

		$scope.votePlayers = function(){
			$ionicLoading.show({template:"Procesando votacion..."});
			TurnSrv.votatePlayers(idTurn,$scope.players).then(function(data){
				$ionicLoading.hide();
				if(data.code !== 200){
					// handle error
					UtilsSrv.showPopup("Hubo un error al votar",1500);
					return;
				}

				$scope.canvote = false;
				UtilsSrv.showPopup("Se ha votado correctamente",1500);

			},function(error){
				$ionicLoading.hide();
				UtilsSrv.showPopup("Hubo un error al votar",1500);
			});
		};

		setHeader();
		getFriendsToVote();

	}]);