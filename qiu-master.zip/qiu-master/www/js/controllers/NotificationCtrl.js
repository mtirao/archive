controllers.controller('NotificationCtrl', [
  '$timeout',
  'ContactSrv',
  'AnalyticsSrv',
  '$cordovaDevice',
  '$cordovaSocialSharing',
  '$scope',
  'NotificationSvc',
  '$ionicLoading',
  '$state',
  '$rootScope',
  '$cordovaToast',
  'UtilsSrv',
  '$ionicScrollDelegate',
  function($timeout,ContactSrv,AnalyticsSrv,$cordovaDevice,$cordovaSocialSharing,$scope,NotificationSvc,$ionicLoading,$state,$rootScope,$cordovaToast,UtilsSrv,$ionicScrollDelegate) {
    var deviceId = window.localStorage["deviceId"];
    AnalyticsSrv.trackView("Notification View");

    $scope.notifications = [];
    $scope.listCanSwipe = false;

    $scope.$on('$ionicView.enter', function() {
      $rootScope.setIconNotification(false);
      setHeader();
    });

    $scope.infiniteScroll = false;

    $scope.message = "";

    var greatestTop = 0;

    $ionicLoading.show({
      template: 'Cargando notificaciones...'
    });

    function getAllNotifications(from){
      var skip = $scope.notifications.length;
      var limit = 5;

      if(from === 'doRefresh'){
        skip = 0;
      }

      NotificationSvc.getAllNotifications(deviceId,skip,limit).then(function(data){
        $ionicLoading.hide();
        $scope.$broadcast('scroll.refreshComplete');

        if(!data){

          if(from === 'doRefresh'){
            UtilsSrv.showPopup("Hubo un error al traer las notificaciones",1500);
          }else if(from === 'loadMore'){
            
            $scope.infiniteScroll = false;
          }else{
            $scope.message = "Hubo un error al traer las notificaciones";
          }

          return;  
        }
        if(data.code !== 200){
          return;
        }

        if(from === 'doRefresh'){
          $rootScope.newNotifications = 0;
          $scope.notifications = [];
        }

        $scope.infiniteScroll = true;

        if(data.result.length < limit){
          greatestTop = (-document.getElementById("vot_containter_id").getBoundingClientRect().top) + 72;
          $scope.infiniteScroll = false;
        }

        if($scope.notifications.length==0){
          $scope.message = "No tiene notificaciones";
          $scope.notifications = data.result;
        }else{
          for (var i = 0; i < data.result.length; i++) {
            $scope.notifications.push(data.result[i]);
          }
        }

        // if($scope.notifications.length == 0){
        //   $scope.message = "No tiene notificaciones";
        // }

      },function(error){
        $scope.$broadcast('scroll.refreshComplete');
        $ionicLoading.hide();
        UtilsSrv.showPopup("Hubo un error por favor vuelva a intentarlo",1500);
      });
    }

    $scope.goToVotationList = function(){
      $state.go("tab.votation-list");
    };

    $scope.go = function(isInvitation, turn,idNotification,isInvited){

      if(!turn){
        $state.go("tab.cancellation",{"idNotification":idNotification});
        return;
      }

      if(!isInvited){
        $state.go("tab.uninvited",{"idTurn":turn._id,"idNotification":idNotification});
        return;
      }

      if(isInvitation){
        $state.go("tab.invitation",{"idTurn":turn._id,"idNotification":idNotification});
        return;
      }
      
    };

    $scope.doRefresh = function(){
      getAllNotifications("doRefresh");
    };

    function removeFromList(idNotification){
      for (var i = 0; i < $scope.notifications.length; i++) {
        if($scope.notifications[i]._id == idNotification){
          $scope.notifications.splice(i, 1);
          // $cordovaToast.show('Se elimino la notificacion', 'short', 'center');
          UtilsSrv.showPopup("Se elimino la notificacion",1500);
          break;
        }
      }
    }

    $scope.loadMore = function(){
      $scope.$broadcast('scroll.infiniteScrollComplete');
      if($scope.infiniteScroll){
        greatestTop = (-document.getElementById("vot_containter_id").getBoundingClientRect().top) + 72;
        getAllNotifications("loadMore");
      }
    };

    $scope.deleteNotification = function(idNotification){
      NotificationSvc.deleteNotification(idNotification).then(function(data){
        if(data.code !==200){
          UtilsSrv.showPopup("No pudo eliminarse la notificacion",1500);
          return;
        }
        removeFromList(idNotification);
      },function(){
        UtilsSrv.showPopup("No pudo eliminarse la notificacion",1500);
      });
    };

    function setHeader(){
      $scope.$parent.activities.show = false;
      $scope.$parent.activities.shareButton = false;
      $scope.$parent.activities.title = "Actividades";
    }

    $scope.gotScrolled = function(scroll){
      if((-document.getElementById("vot_containter_id").getBoundingClientRect().top) + 72 < greatestTop){
        $scope.infiniteScroll = true;

        if ($scope.$root && $scope.$root.$$phase != '$apply' && $scope.$root.$$phase != '$digest') {
            $scope.$apply();
        }

      }
    }

    setHeader();
    getAllNotifications();

  }]);