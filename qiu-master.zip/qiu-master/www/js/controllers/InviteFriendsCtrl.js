controllers.controller('InviteFriendsCtrl', [
  '$scope',
  '$rootScope',
  'AnalyticsSrv',
  '$filter',
  '$ionicHistory',
  'DataSvc',
  '$state',
  '$stateParams',
  'TurnSrv',
  '$cordovaToast',
  'FacebookService',
  'UserSvc',
  '$ionicLoading',
  '$cordovaSocialSharing',
  'UtilsSrv',
  'env',
  function($scope,$rootScope,AnalyticsSrv,$filter,$ionicHistory,DataSvc,$state, $stateParams,TurnSrv,$cordovaToast,FacebookService,UserSvc,$ionicLoading,$cordovaSocialSharing,UtilsSrv,env) {

    AnalyticsSrv.trackView("First invitation View");

    $scope.animated = false;
    $scope.test = {};

    $scope.friends = [];

    var nextFriendsUrl = "";

    $scope.infiniteScroll = false;

    $scope.goBack = function(){
      $ionicHistory.goBack();
    };

    $scope.$parent.activities.show = true;
    $scope.$parent.activities.shareButton = true;
    $scope.$parent.activities.title = "Invita amigos";

    $scope.$on('goBack', function() {
      AnalyticsSrv.trackEvent("InviteFriends","Action","goBack",1);
      $scope.$parent.activities.title = "Ficha de Reserva";
      $ionicHistory.goBack();
    });

    $scope.$on('share', function() {
      $scope.share();
    });

    function checkIfExists(friends,idFriends,isNew){
      UserSvc.checkIfExists(idFriends).then(function(data){
        if(!data){
          return;
        }
        if(data.code !== 200){
          //handle error
          return;
        }
        var friendsRegistered = data.result;
        var filteredFriends = [];

        for (var i = 0; i < friends.length; i++) {
          for (var j = 0; j < friendsRegistered.length; j++) {
            if(friendsRegistered[j].fbLogin == friends[i].id){
              filteredFriends.push(friends[i]);
            }
          }
        }

        getChecked($stateParams.idTurn,filteredFriends,isNew);

      },function(error){
      });
    }

    function getNextFriends(){
      FacebookService.getNextFriends(nextFriendsUrl).then(function(data){
        if(data.status !== 200){
          return;
        }
        var newFriends = data.data.data;

        if(!data.data.paging.next || newFriends.length == 0){
          $scope.infiniteScroll = false;
        }else{
          $scope.infiniteScroll = true;
          nextFriendsUrl = data.data.paging.next;
        }

        if(newFriends.length > 0){
          var idFriends = [];
          for (var i = 0; i < newFriends.length; i++) {
            idFriends.push(newFriends[i].id);
          }
          checkIfExists(newFriends,idFriends,true);
        }else{
          $scope.infiniteScroll = false;
        }
      },function(error){
      });
    }

    function getFriends(){

      var token = window.localStorage["tokenFB"];
      $ionicLoading.show({template: 'Obteniendo amigos...'});
      FacebookService.getFriends(token).then(function(data){
        $ionicLoading.hide();
        var friends = data.data;
        if(friends.length == 0){
          UtilsSrv.showPopup("No tiene amigos usando Qiu",1500);
        }else{
          $scope.infiniteScroll = true;
          if(!data.paging.next){
            $scope.infiniteScroll = false;
          }else{
            nextFriendsUrl = data.paging.next;
          }

          var idFriends = [];
          for (var i = 0; i < friends.length; i++) {
            idFriends.push(friends[i].id);
          }
          checkIfExists(friends,idFriends,false);
        }
      },function(error){
        $ionicLoading.hide();
        handleFacebookErrors(error);
      });
    }

    function handleFacebookErrors(error){
      if(error.error.code == 190){
        if(error.error.error_subcode == 463){
          UtilsSrv.showPopup("La sesion de Facebook ha expirado por favor loguearse nuevamente",1500);
        }else if(error.error.error_subcode == 467){
          UtilsSrv.showPopup("Por favor loguearse nuevamente",1500);
        }
      }
    }

    function createCompleteTurn(idTurn,idsFb){
      AnalyticsSrv.trackEvent("InviteFriends","Action","CreateTurn",1);
      TurnSrv.createCompleteTurn(idTurn,idsFb).then(function(data){

        $ionicLoading.hide();

        if(!data){
          UtilsSrv.showPopup("Hubo un error al crear el turno",2000);
          return;
        }

        if(data.code !== 200){
          return;

        }

        if(data.result.error){
          UtilsSrv.showPopup(data.result.error.message,2500);
          $ionicHistory.goBack();
          return;
        }

        var date = new Date(data.result.date.from);

        var day = date.getDate();
        var month = date.getMonth()+1;
        var year = date.getFullYear();

        var hour = date.getHours();

        $rootScope.findTurnsByDateAndHour(day+"/"+month+"/"+year,hour,null);
        $state.go("tab.reservation_cardRes",{"turnId":data.result._id});

      },function(){
        $ionicLoading.hide();
        UtilsSrv.showPopup("Hubo un error al crear el turno, por favor int\u00e9ntelo nuevamente",1500);
      });
    }

    function getSelectedFriends(){
      var usersInvited = $filter('filter')($scope.friends, {selected: true});
      var idsFb = [];

      for (var i = 0; i < usersInvited.length; i++) {
        idsFb.push(usersInvited[i].id);
      }

      return idsFb;
    }

    function addFriends(idsFb){
      TurnSrv.addFriends($stateParams.idTurn,idsFb).then(function(data){
        if(data.code !== 200){
          // handle error
          return;
        }
        $ionicLoading.hide();
        $ionicHistory.goBack();

      },function(){
        $ionicLoading.hide();
      });
    }

    $scope.goToReservationCard = function(){

      var idsFb = getSelectedFriends();

      if($state.current.name == "tab.invitefriends_act"){
        $ionicLoading.show({template: 'Invitando Amigos...'});
        addFriends(idsFb);
        return;
      }

      $ionicLoading.show({template: 'Creando Turno...'});

      idsFb.push(window.localStorage["idFacebook"]);

      createCompleteTurn($stateParams.idTurn,idsFb);
    };

    window.addEventListener('native.keyboardshow', keyboardShowHandler);

    function keyboardShowHandler(){
      document.body.classList.add('keyboard-open');
    }

    window.addEventListener('native.keyboardhide', keyboardHideHandler);

    function keyboardHideHandler(){
      document.body.classList.remove('keyboard-open');
    }

    function removeAlreadyInvited(friends,isNew){
      for (var i = friends.length-1; i >= 0; i--) {
        if(friends[i].selected !== null && friends[i].selected){
          friends.splice(i,1);
        }
      }
      if(!isNew){
        $scope.friends = friends;
      }else{
        for (var e = 0; e < friends.length; e++) {
          $scope.friends.push(friends[e]);
        }
      }
    }

    function getChecked(idTurn,friends,isNew){

      TurnSrv.getChecked(idTurn).then(function(data){

        if(data.code !== 200){
          return;
        }

        var invitations = data.result.invitations;
        for (var i = 0; i < friends.length; i++) {
          for (var j = 0; j < invitations.length; j++) {
            if(friends[i].id == invitations[j].fbLogin){
              friends[i].selected = true;
            }
          }
        }

        removeAlreadyInvited(friends,isNew);

      },function(error){

      });
    }

    $scope.check = function(){

      for (var i = 0; i < $scope.friends.length; i++) {
        if($scope.friends[i].selected){
          $scope.animated = true;
          return;
        }
      }
      $scope.animated = false;
    };

    var firstLoad = false;
    $scope.loadMore = function(){
      $scope.$broadcast('scroll.infiniteScrollComplete');
      if(firstLoad && $scope.infiniteScroll){
        $scope.infiniteScroll = false;
        getNextFriends();
      }
      firstLoad = true;
    };

    $scope.share = function(){
      AnalyticsSrv.trackEvent("InviteFriends","Action","Invitar via...",1);
      $ionicLoading.show({template:"Compartiendo..."});

      var link = env.url+"/test/verify/"+$stateParams.idTurn;

      $cordovaSocialSharing
          .share("Usa qiu", "tema", "http://cdn2.uvnimg.com/3c/a6/921400d0499cb2980b77c519307e/futbol-generic-entry-point.jpg",  link) // Share via native share sheet
          .then(function() {
            $scope.animated = true;
            $ionicLoading.hide();
          }, function() {
            $ionicLoading.hide();
          });
    };

    getFriends();

  }]);
