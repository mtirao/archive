controllers.controller('ReservationCardCtrl',[
	'$scope',
	'AnalyticsSrv',
	'$ionicHistory',
	'$state',
	'$stateParams',
	'TurnSrv',
	'$cordovaDialogs',
	'$cordovaToast',
	'$rootScope',
	'$ionicLoading',
	'$timeout',
	'UtilsSrv',
	'$ionicPopup',
	function($scope,AnalyticsSrv,$ionicHistory,$state,$stateParams,TurnSrv,$cordovaDialogs,$cordovaToast,$rootScope,$ionicLoading,$timeout,UtilsSrv,$ionicPopup) {

		AnalyticsSrv.trackView("Reservation Card View");

		$scope.data = {};
		$scope.decision = {};

		$scope.showButtonState = false;
		$scope.showCancelButton = true;

		$scope.$on('goBack', function(event, obj) {
			$scope.$parent.activities.show = false;
			$scope.$parent.activities.title = "Actividades";
			$ionicHistory.goBack();
		});

		$scope.$on('$ionicView.enter', function() {
			if($state.current.name == "tab.reservation_cardAct"){
				setHeader();
			}
		});

		var turnId = $stateParams.turnId;
		var adminId;

		$scope.goToInvitation = function(){
			if($state.current.name == "tab.reservation_cardRes"){
				$state.go("tab.invitefriends",{"idTurn":turnId});
				return;
			}
			if($state.current.name == "tab.reservation_cardAct"){
				$state.go("tab.invitefriends_act",{"idTurn":turnId});
				return;
			}
		};

		function getStatus(status){
			switch(status){
				case 1:
					break;
				case 2:
					return "en puja";
					break;
				case 3:
					return "bloqueado";
					break;
				case 4:
					return "confirmado";
					break;
			}
		}

		function getTurn(turnId){
			$ionicLoading.show({
				template: 'Cargando Reserva...'
			});
			TurnSrv.getTurn(turnId).then(function(data){
				$ionicLoading.hide();

				if(data.code !== 200){
					UtilsSrv.showPopup('No se pudo obtener la informacion de la reserva',1500);
					$ionicHistory.goBack();
					return;
				}

				if(data.result.error){
					if(data.result.error){
						$ionicLoading.show({template:data.result.error.message});
						$timeout(function() {
							$ionicLoading.hide();
							// $ionicHistory.goBack();
							$state.go("tab.reservations");
						}, 2000);
					}
					return;
				}

				var info = data.result;
				$scope.data.state = getStatus(info.status);
				$scope.data.name = info.admin.name;
				adminId = info.admin._id;
				$scope.decision.name = info.name;
				$scope.data.address = info.admin.address;
				$scope.data.phone = info.admin.phone;
				var date = new Date(info.date.from);
				var dayOfWeek = date.getDay();
				var dayNumber = date.getDate();
				var month = date.getMonth()+1;
				$scope.data.date = days[dayOfWeek]+" "+dayNumber+"/"+month;
				$scope.data.hour = date.getHours()+":00";

				var toConfirmate = info.toConfirmate;

				if($state.current.name == "tab.reservation_cardRes"){
					window.localStorage["lastLat"] = info.admin.location[1];
					window.localStorage["lastLng"] = info.admin.location[0];
				}

				var decision;
				if(isExternal(info.externalInvitations)){
					decision = isExternalDecision(info.externalInvitations);
					$scope.decision.exists = decision.exists;
					$scope.decision.value = decision.value;
					$scope.decision.message = (decision.value)?"Ha aceptado la invitacion":"Ha rechazado la invitacion";
				}else{
					decision = isDecision(info.invitations);
					$scope.decision.exists = decision.exists;
					$scope.decision.value = decision.value;
					$scope.decision.message = (decision.value)?"Ha aceptado la invitacion":"Ha rechazado la invitacion";
				}

				var friendsAccept = 0;
				for (var i = 0; i < info.invitations.length; i++) {
					if(info.invitations[i].accepted){
						friendsAccept++;
					}
				}
				for (var e = 0; e < info.externalInvitations.length; e++) {
					if(typeof info.externalInvitations[e] === 'object' && info.externalInvitations[e].accepted){
						friendsAccept++;
					}
				}
				$scope.data.confirmed = (friendsAccept==1)?friendsAccept + " confirmado/"+toConfirmate:friendsAccept + " confirmados/"+toConfirmate;

			},function(){
				$ionicLoading.hide();
				UtilsSrv.showPopup('No se pudo obtener la informacion de la reserva',1500);
				$ionicHistory.goBack();
			});
		}

		$scope.goBack = function() {
			if($state.current.name == "tab.reservation_cardRes"){
				$state.go("tab.reservations");
				return;
			}
			$ionicHistory.goBack();
		};

		function isExternal(extInvitations){
			for (var i = 0; i < extInvitations.length; i++) {
				if(typeof extInvitations[i] === 'object' && extInvitations[i]._id == window.localStorage["deviceId"]){
					return true;
				}
			}
		}

		function isExternalDecision(invitations){
			for (var i = 0; i < invitations.length; i++) {
				if(typeof invitations[i] === 'object' && invitations[i]._id == window.localStorage["deviceId"]){
					if(invitations[i].accepted != null){
						return {"exists":true,"value":invitations[i].accepted};
					}
				}
			}
			return {"exists":false};
		}

		function isDecision(invitations){
			for (var i = 0; i < invitations.length; i++) {
				// if(invitations[i]._id == window.localStorage["deviceId"]){
				if(invitations[i].fbLogin == window.localStorage["idFacebook"]){
					if(invitations[i].accepted != null){
						return {"exists":true,"value":invitations[i].accepted};
					}
				}
			}
			return {"exists":false };
		}

		$scope.cancelReservation = function(){

			var confirmPopup = $ionicPopup.confirm({
				title: 'Cancelar',
				template: '¿Desea cancelar la reserva?'
			});
			confirmPopup.then(function(res) {
				if(res) {
					$ionicLoading.show({
						template: 'Elminando turno...'
					});
					AnalyticsSrv.trackEvent("ReservationCard","Action","Cancel Turn",1);
					TurnSrv.removeTurn(adminId,turnId).then(function(data){
						$ionicLoading.hide();
						if(!data){
							UtilsSrv.showPopup("Hubo un error al cancelar la reserva",2000);
							return;
						}
						if(data.code !== 200){
							UtilsSrv.showPopup('No se pudo eliminar el turno',1500);
							return;
						}

						UtilsSrv.showPopup('Se elimino el turno correctamente',1500);

						if($state.current.name == "tab.reservation_cardRes"){
							var date = new Date(data.result.date.from);

							var day = date.getDate();
							var month = date.getMonth()+1;
							var year = date.getFullYear();

							var hour = date.getHours();
							$rootScope.findTurnsByDateAndHour(day+"/"+month+"/"+year,hour,null);
							$state.go("tab.reservations");
							return;
						}

						if($state.current.name == "tab.reservation_cardAct"){
							$state.go("tab.info_reservations",{"a":"b"});
						}

					},function(){
						$ionicLoading.hide();
						UtilsSrv.showPopup('No pudo eliminarse el turno correctamente',1500);
					});
				}
			});
		};

		$scope.goToTurnState = function(){
			AnalyticsSrv.trackEvent("Reservation Card","Action","Go to Turn Status",1);
			if($state.current.name == "tab.reservation_cardAct"){
				$state.go("tab.stateTurn_act",{"turnId":turnId,"type":$stateParams.type});
			}
			if($state.current.name == "tab.reservation_cardRes"){
				$state.go("tab.stateTurn",{"turnId":turnId});
			}
		};

		function setHeader(){
			$scope.$parent.activities.show = true;
			$scope.$parent.activities.shareButton = false;
			$scope.$parent.activities.title = "Ficha de Reserva";
		}

		function configureCard(){
			if($stateParams.type == "invitation"){
				$scope.showCancelButton = false;
			}
		}

		function acceptTurn(){
			$ionicLoading.show({
				template: 'Espere por favor...'
			});
			TurnSrv.acceptTurn(turnId).then(function(data){
				$ionicLoading.hide();
				if(data.code !== 200){
					UtilsSrv.showPopup(data.result.error.messag,1500);
					return;
				}
				if(data.result.error){
					UtilsSrv.showPopup(data.result.error.messag,1500);
					return;
				}

				$scope.accepted = true;
				UtilsSrv.showPopup("Ha aceptado la invitacion",1500);

				setMessageDecision(true);
				$scope.decision.value = true;

			},function(){
				$ionicLoading.hide();
				UtilsSrv.showPopup("Hubo un error, por favor int\u00e9ntelo nuevamente",1500);
			});
		}

		function cancelTurn(){
			$ionicLoading.show({
				template: 'Espere por favor...'
			});
			TurnSrv.cancelTurn(turnId).then(function(data){
				$ionicLoading.hide();
				if(data.code !== 200){
					UtilsSrv.showPopup(data.result.error.message,1500);
					return;
				}
				if(data.result.error){
					UtilsSrv.showPopup(data.result.error.message,1500);
					return;
				}

				$scope.accepted = false;
				UtilsSrv.showPopup("Ha rechazado la invitacion",1500);

				setMessageDecision(false);
				$scope.decision.value = false;

			},function(){
				$ionicLoading.hide();
				UtilsSrv.showPopup("Hubo un error, por favor int\u00e9ntelo nuevamente",1500);
			});
		}

		$scope.accept = function(){

			var confirmPopup = $ionicPopup.confirm({
				title: 'Confirmar',
				template: '¿Desea aceptar el turno?'
			});
			confirmPopup.then(function(res) {
				if(res) {
					AnalyticsSrv.trackEvent("ReservationCard","Action","Accept Turn",1);
					acceptTurn();
				}
			});
		};

		$scope.cancel = function(){
			var confirmPopup = $ionicPopup.confirm({
				title: 'Confirmar',
				template: '¿Desea cancelar el turno?'
			});
			confirmPopup.then(function(res) {
				if(res) {
					AnalyticsSrv.trackEvent("ReservationCard","Action","Cancel Turn",1);
					cancelTurn();
				}
			});
		};

		function setMessageDecision(accept){
			$scope.decision.exists = true;
			$scope.decision.message = (accept)?"Ha aceptado la invitacion":"Ha rechazado la invitacion";
		}

		var days = ['Domingo','Lunes','Martes','Miercoles','Jueves','Viernes','S\u00e1bado'];

		setHeader();
		configureCard();
		getTurn(turnId);
	}]);
