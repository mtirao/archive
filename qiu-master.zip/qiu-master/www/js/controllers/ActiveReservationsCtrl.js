controllers.controller('ActiveReservationsCtrl', [
	'$scope',
	'DataSvc',
	function($scope,DataSvc) {
		function getActiveReservations(){
			$scope.reservations = DataSvc.getActiveReservations();
		}

		getActiveReservations();
	}]);
