controllers.controller('InvitationCtrl', [
    '$scope',
    'AnalyticsSrv',
    '$state',
    '$ionicHistory',
    '$stateParams',
    'TurnSrv',
    'NotificationSvc',
    '$cordovaDialogs',
    '$cordovaToast',
    '$ionicLoading',
    '$timeout',
    'UtilsSrv',
    '$ionicPopup',
    function($scope,AnalyticsSrv,$state,$ionicHistory,$stateParams,TurnSrv,NotificationSvc,$cordovaDialogs,$cordovaToast,$ionicLoading,$timeout,UtilsSrv,$ionicPopup) {

        AnalyticsSrv.trackView("Invitation View");

        var idTurn = $stateParams.idTurn;
        var idNotification = $stateParams.idNotification;
        var turnId = $stateParams.idTurn;

        $scope.decision = {};
        $scope.turn = {};

        function readNotification(idNotification){
            NotificationSvc.readNotification(idNotification).then(function(data){
            },function(error){
            });
        }

        function isExternal(extInvitations){
            for (var i = 0; i < extInvitations.length; i++) {

                if(typeof extInvitations[i] === 'object' && extInvitations[i]._id == window.localStorage["deviceId"]){
                    return true;
                }
            }
        }

        function getStatus(status){
            switch(status){
                case 1:
                    break;
                case 2:
                    return "en puja";
                    break;
                case 3:
                    return "bloqueado";
                    break;
                case 4:
                    return "confirmado";
                    break;
            }
        }

        function getTurn(idTurn){

            TurnSrv.getTurn(idTurn).then(function(data){
                $ionicLoading.hide();

                if(!data){
                    $ionicHistory.goBack();
                    return;
                }

                if(data.code !== 200){
                    // handle error
                    // $cordovaToast.show("Hubo un error","short","center");
                    UtilsSrv.showPopup("Hubo un error",1500);
                    $ionicHistory.goBack();
                    return;
                }
                var result = data.result;

                if(data.result.error){
                    // handle error
                    if(data.result.error){
                        $ionicLoading.show({template:data.result.error.message});

                        $timeout(function() {
                            $ionicLoading.hide();
                            $ionicHistory.goBack();
                        }, 2000);
                    }
                    return;
                }

                $scope.turn = result;

                var date = new Date(result.date.from);
                var dayOfWeek = date.getDay();
                var dayNumber = date.getDate();
                var month = date.getMonth()+1;
                $scope.turn.dateMatch = days[dayOfWeek]+" "+dayNumber+"/"+month;
                $scope.turn.hour = date.getHours()+":00";
                $scope.turn.status = getStatus(result.status);

                $scope.turn.address = result.admin.name;
                $scope.turn.phone = result.admin.phone;

                var toConfirmate = result.toConfirmate;
                var decision;

                if(isExternal(result.externalInvitations)){
                    decision = isExternalDecision(result.externalInvitations);
                    $scope.decision.exists = decision.exists;
                    $scope.decision.value = decision.value;
                    $scope.decision.message = (decision.value)?"Ha aceptado la invitacion":"Ha rechazado la invitacion";
                }else{
                    decision = isDecision(result.invitations);
                    $scope.decision.exists = decision.exists;
                    $scope.decision.value = decision.value;
                    $scope.decision.message = (decision.value)?"Ha aceptado la invitacion":"Ha rechazado la invitacion";
                }

                if(result.user == window.localStorage["deviceId"]){
                    $scope.decision.exists = true;
                    $scope.decision.value = null;
                }

                var friendsAccept = 0;
                for (var i = 0; i < result.invitations.length; i++) {
                    if(result.invitations[i].accepted){
                        friendsAccept++;
                    }
                }
                for (var e = 0; e < result.externalInvitations.length; e++) {
                    if(typeof result.externalInvitations[e] === 'object' && result.externalInvitations[e].accepted){
                        friendsAccept++;
                    }
                }
                $scope.turn.confirmed = (friendsAccept==1)?friendsAccept+" confirmado/"+toConfirmate:friendsAccept+" confirmados/"+toConfirmate;
                $scope.turn.totalInvited = result.invitations.length;

            },function(error){
                $ionicLoading.hide();
                // $cordovaToast.show("Hubo un error","short","center");
                UtilsSrv.showPopup("Hubo un error",1500);
                $ionicHistory.goBack();
            });
        }

        function isExternalDecision(invitations){
            for (var i = 0; i < invitations.length; i++) {
                if(typeof invitations[i] === 'object' && invitations[i]._id == window.localStorage["deviceId"]){
                    if(invitations[i].accepted != null){
                        return {"exists":true,"value":invitations[i].accepted};
                    }
                }
            }
            return {"exists":false};
        }

        function isDecision(invitations){
            for (var i = 0; i < invitations.length; i++) {
                // if(invitations[i]._id == window.localStorage["deviceId"]){
                if(invitations[i].fbLogin == window.localStorage["idFacebook"]){
                    if(invitations[i].accepted != null){
                        return {"exists":true,"value":invitations[i].accepted};
                    }
                }
            }

            return {"exists":false};
        }

        $scope.$parent.activities.show = true;

        $scope.$on('goBack', function() {
            $scope.$parent.activities.show = false;
            $ionicHistory.goBack();
        });

        function setMessageDecision(accept){
            $scope.decision.exists = true;
            $scope.decision.message = (accept)?"Ha aceptado la invitacion":"Ha rechazado la invitacion";
        }

        function acceptTurn(){

            TurnSrv.acceptTurn(idTurn).then(function(data){
                if(data.code !== 200){
                    // $cordovaToast.show(data.result.error.message,"short","center");
                    UtilsSrv.showPopup(data.result.error.message,1500);
                    return;
                }
                if(data.result.error){
                    // $cordovaToast.show(data.result.error.message,"short","center");
                    UtilsSrv.showPopup(data.result.error.message,1500);
                    return;
                }

                $scope.accepted = true;
                // $cordovaToast.show("Ha aceptado la invitacion","short","center");
                UtilsSrv.showPopup("Ha aceptado la invitacion",1500);

                TurnSrv.getLocation(idTurn).then(function(data){
                    if(data.result && data.result.admin){
                        window.localStorage["lastLat"] = data.result.admin.location[1];
                        window.localStorage["lastLng"] = data.result.admin.location[0];
                    }
                },function(err){
                });

                setMessageDecision(true);
                $scope.decision.value = true;

            },function(){
                UtilsSrv.showPopup("Hubo un error por favor int\u00e9ntelo nuevamente",1500);
            });
        }

        function cancelTurn(){

            TurnSrv.cancelTurn(idTurn).then(function(data){
                if(data.code !== 200){
                    UtilsSrv.showPopup(data.result.error.message,1500);
                    return;
                }
                if(data.result.error){
                    UtilsSrv.showPopup(data.result.error.message,1500);
                    return;
                }

                $scope.accepted = false;
                UtilsSrv.showPopup("Ha rechazado la invitacion",1500);

                setMessageDecision(false);
                $scope.decision.value = false;

            },function(){
                UtilsSrv.showPopup("Hubo un error por favor int\u00e9ntelo nuevamente",1500);
            });
        }

        $scope.accept = function(){

            var confirmPopup = $ionicPopup.confirm({
                title: 'Confirmar',
                template: '¿Desea aceptar la invitacion?'
            });
            confirmPopup.then(function(res) {
                if(res) {
                    AnalyticsSrv.trackEvent("Invitation","Decision","Accept",1);
                    acceptTurn();
                }
            });
        };

        $scope.cancel = function(){

            var confirmPopup = $ionicPopup.confirm({
                title: 'Confirmar',
                template: '¿Desea cancelar la invitacion?'
            });
            confirmPopup.then(function(res) {
                if(res) {
                    AnalyticsSrv.trackEvent("Invitation","Decision","Cancel",1);
                    cancelTurn();
                }
            });
        };

        $scope.goToTurnState = function(){
            $state.go("tab.stateTurn_act",{"turnId":turnId,"type":"invitation"});
        };

        var days = ['DOMINGO','LUNES','MARTES','MIERCOLES','JUEVES','VIERNES','S\u00c1BADO'];

        function setHeader(){
            $scope.$parent.activities.show = true;
            $scope.$parent.activities.title = "Invitaci\u00f3n";
        }

        $ionicLoading.show({
            template: 'Cargando invitacion...'
        });

        readNotification(idNotification);
        setHeader();
        getTurn(idTurn);
    }]);