controllers.controller('LoginCtrl', [
    '$scope',
    'AnalyticsSrv',
    '$rootScope',
    '$state',
    'FacebookService',
    'LoginSrv',
    '$ionicLoading',
    '$cordovaToast',
    'UtilsSrv',
    'UserSvc',
    '$cordovaNetwork',
    '$ionicHistory',
    '$timeout',
    'AccessSvc',
    'PushSvc',
    function($scope,AnalyticsSrv,$rootScope,$state,FacebookService,LoginSrv,$ionicLoading,$cordovaToast,UtilsSrv,UserSvc,$cordovaNetwork,$ionicHistory,$timeout,AccessSvc,PushSvc) {
        AnalyticsSrv.trackView("Login View");
        var cancelLogin = false;


        var isIOS = ionic.Platform.isIOS();
        var isAndroid = ionic.Platform.isAndroid();
        var platform = "";
        if(isAndroid){
            platform = "android";
        }
        if(isIOS){
            platform = "ios";
        }

        function getFacebookData(tokenFB){
            if(cancelLogin){
                $ionicLoading.hide();
                cancelLogin = false;
                UtilsSrv.showPopup("Hubo un error al loguerase, por favor inténtelo nuevamente",1500);
                return;
            }
            
            FacebookService.getIdFacebook(tokenFB).then(function(data){
                
                window.localStorage["name"] = data.name;
                window.localStorage["email"] = data.email;
                var name = data.name;
                var idFacebook = data.id;
                var email = data.email;
                LoginSrv.authorize(idFacebook,name,platform).then(function(data){
                    if(!data){
                        getFacebookData(tokenFB);
                        return;
                    }
                    
                    window.localStorage["tokenQiu"] = data.token;
                    window.localStorage["deviceId"] = data.deviceId;
                    var phone = (data.phone == undefined)? "" : data.phone;
                    window.localStorage["phone"]  = phone;
                    $ionicLoading.hide();
                    AccessSvc.logDevice(function(){
                        PushSvc.register().then(function(data){
                          
                        },function(err){
                          
                        });
                    });
                    UserSvc.getLeaderboardData().then(function(data){
                        if(!data){
                            getFacebookData(tokenFB);
                            return;
                        }
                        window.localStorage["rate"]  = data.result.points;
                        window.localStorage["votes"]  = data.result.votes;
                        $rootScope.refreshMenu(name,email,phone,idFacebook,data.result.points,data.result.votes);
                        $ionicHistory.nextViewOptions({
                            disableBack: true,
                            disableAnimate: true,
                            historyRoot: true
                        });
                        $ionicHistory.clearCache();
                        $ionicHistory.clearHistory();
                        $state.go("tab.leaderboard");
                    },function(){
                        $rootScope.refreshMenu(name,email,phone,idFacebook,data.result.points,data.result.votes);
                        $ionicHistory.nextViewOptions({
                            disableBack: true,
                            disableAnimate: true,
                            historyRoot: true
                        });
                        $ionicHistory.clearCache();
                        $ionicHistory.clearHistory();
                        $state.go("tab.leaderboard");
                    });

                },function(err){
                    console.log(err);
                    getFacebookData(tokenFB);
                });
            },function(error){
                console.log(error);
                cancelLogin = true;
                getFacebookData(tokenFB);
            });
        }

        function loginFacebook(){

            $ionicLoading.show({
                template: 'Espere por favor...'
            })
            FacebookService.login().then(function(data){

                window.localStorage["tokenFB"] = data.accessToken;
                window.localStorage["idFacebook"] = data.userID;
                
                var tokenFB = window.localStorage["tokenFB"];
                $timeout(function() {
                    cancelLogin = true;
                }, 25000);
                getFacebookData(tokenFB);
                
            },function(e){
                console.log(e);
                $ionicLoading.hide();
                UtilsSrv.showPopup("Hubo un error al loguearse",1500);
            });     
        }

        $scope.loginFacebook = function(){
            loginFacebook();
        }


    }]);
