controllers
	.controller("CancellationCtrl",[
		'$scope',
		'$ionicHistory',
		'NotificationSvc',
		'$stateParams',
		function($scope,$ionicHistory,NotificationSvc,$stateParams){

			function readNotification(idNotification){
				NotificationSvc.readNotification(idNotification).then(function(data){

				},function(error){
				
				});
			}

			$scope.$on('$ionicView.enter', function() {
				setHeader();
			});

			$scope.$on('goBack', function() {
				$scope.$parent.activities.show = false;
				$scope.$parent.activities.title = "Actividades";
				$ionicHistory.goBack();
			});

			function setHeader(){
				$scope.$parent.activities.show = true;
				$scope.$parent.activities.shareButton = false;
				$scope.$parent.activities.title = "Partido Cancelado";
			}

			setHeader();
			readNotification($stateParams.idNotification);
		}]);