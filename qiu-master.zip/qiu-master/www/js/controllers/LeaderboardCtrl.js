controllers.controller('LeaderboardCtrl', [
  '$scope',
  '$rootScope',
  'DataSvc',
  'PushSvc',
  '$http',
  '$q',
  'env',
  'LocationSrv',
  '$ionicLoading',
  '$cordovaToast',
  'UserSvc',
  'UtilsSrv',
  'AnalyticsSrv',
  '$ionicScrollDelegate',
  function($scope,$rootScope,DataSvc,PushSvc,$http,$q,env,LocationSrv,$ionicLoading,$cordovaToast,UserSvc,UtilsSrv,AnalyticsSrv,$ionicScrollDelegate) {

    AnalyticsSrv.trackView("Leaderboard View");
    
    $scope.isLeaderboardLoaded = false;

    $scope.rating1 = 1;
    $scope.isReadonly = false;

    $scope.infiniteScroll = false;

    $scope.winner = {};
    $scope.winner.device = {};

    $scope.otherPlayers = [];

    $scope.message = "";

    var countPlayers = 0;

    var skipSended = [];

    var greatestTop = 0;

    $scope.rateFunction = function(rating) {
    
    };
    
    $ionicLoading.show({
      template: 'Cargando Leaderboard...'
    });
    
    $scope.loadMore = function(){
      
      $scope.$broadcast('scroll.infiniteScrollComplete');
      if($scope.infiniteScroll){
        greatestTop = $ionicScrollDelegate.getScrollPosition().top;
        $scope.infiniteScroll = false;
        getLeaderboards("loadMore");
      }
    };

    function isAlreadySended(skip){
      for (var i = 0; i < skipSended.length; i++) {
        if(skipSended[i] == skip){
          return true;
        }
      };
      return false;
    }

    function getLeaderboards(from){
      var skip = countPlayers;

      if(from === 'doRefresh'){
        skip = 0;
        countPlayers = 0;
        skipSended = [];
      }else{
        if(isAlreadySended(skip)){
          return;
        }
      }

      skipSended.push(skip);
      
      DataSvc.getLeaderboard(skip).then(function(data){
        $ionicLoading.hide();
        $scope.$broadcast('scroll.refreshComplete');

        if(!data){
          skipSended.pop();
          if(from === 'doRefresh'){
            UtilsSrv.showPopup("Hubo un error al traer el Leaderboard y no pudo actualizarse",2000);
          }else if(from === 'loadMore'){
            
          }else{
            $scope.isLeaderboardLoaded = false;
            $scope.message = "Hubo un error al traer el Leaderboard";
          }
          return;
        }

        if(data.code !== 200){
          
          return;
        }


        if(data.result.error){
          if(data.result.error.code == 1504){
            greatestTop = $ionicScrollDelegate.getScrollPosition().top;
            $scope.infiniteScroll = false;
          }
          return;
        }
        
        $scope.infiniteScroll = true;

        $scope.isLeaderboardLoaded = true;

        var user = data.result.user;
        var users = data.result.users;

        if(skip > 0){
          for (var i = 0; i < users.length; i++) {
            if(users[i].device._id == window.localStorage["deviceId"]){
              users[i].me = "me";
            }
            $scope.otherPlayers.push(users[i]);
          };
          countPlayers += users.length;
          return;
        }

        if(from === 'doRefresh'){
          $scope.winner = {};
          $scope.otherPlayers = [];
        }


        $scope.winner.position = users[0].position;
        $scope.winner.name = users[0].name;
        $scope.winner.points = users[0].points;
        $scope.winner.points = Math.round($scope.winner.points);
        $scope.winner.votes = users[0].votes;
        $scope.winner.device = users[0].device;

        var rest = users.slice(1, users.length);

        for (var e = 0; e < rest.length; e++) {
          if(rest[e].device._id == window.localStorage["deviceId"]){
            rest[e].me = "me";
          }
          rest[e].points = Math.round(rest[e].points);
        }
        $scope.otherPlayers = rest;
        countPlayers = 5;

      },function(err){
        $ionicLoading.hide();
        $scope.$broadcast('scroll.refreshComplete');
        skipSended.pop();
        if(from === 'doRefresh'){
          UtilsSrv.showPopup("Hubo un error al traer el Leaderboard y no pudo actualizarse",2000);
        }else if(from === 'loadMore'){
          
        }else{
          $scope.isLeaderboardLoaded = false;
          $scope.message = "Hubo un error al traer el Leaderboard";
        }
      });
    }

    function checkExternalInvitation(){
      UserSvc.checkExternalInvitation().then(function(data){
        if(data.code !== 200){
          return;
        }
        if(data.result.count > 0){
          UtilsSrv.showPopup("Tiene nuevas invitaciones",2500);
          $rootScope.setIconNotification(true);
        }
      },function(error){
      });
    }

    $scope.doRefresh = function(){
      getLeaderboards("doRefresh");
    };

    $scope.gotScrolled = function(scroll){
      
      if($ionicScrollDelegate.getScrollPosition().top < greatestTop){
        $scope.infiniteScroll = true;
      }
    }

    getLeaderboards();

  }]);
