controllers.controller('ConfirmationCtrl', [
    '$scope',
    '$ionicHistory',
    '$state',
    '$stateParams',
    'UserSvc',
    '$ionicLoading',
    '$cordovaToast',
    'TurnSrv',
    'UtilsSrv',
    'AnalyticsSrv',
    function($scope,$ionicHistory,$state,$stateParams,UserSvc,$ionicLoading,$cordovaToast,TurnSrv,UtilsSrv,AnalyticsSrv) {
        $scope.data = {};

        $scope.goBack = function(){
            $ionicHistory.goBack();
            AnalyticsSrv.trackEvent("Phone","Confirmation","Back",1);
        };

        $scope.savePhone = function(){
            $ionicLoading.show({
                template: 'Guardando telefono...'
            });
            UserSvc.savePhone($scope.data.phone).then(function(data){
                $ionicLoading.hide();
                if(data.code !== 200){
                    //$cordovaToast.show("Hubo un error al guardar el telefono","short","center");
                    UtilsSrv.showPopup("Hubo un error al guardar el telefono",1500);
                    return;
                }
                window.localStorage["phone"] = $scope.data.phone;
                // $state.go("tab.leaderboard");
                var idAdmin = $stateParams.idAdmin;
                var idGround = $stateParams.idGround;
                var name = $stateParams.name;
                var from = $stateParams.from;
                var to = $stateParams.to;
                var typeId = $stateParams.typeId;

                TurnSrv.createHeaderTurn(idAdmin,idGround,name,window.localStorage["phone"],from,to).then(function(data){
                    if(data.code !== 200){
                        return;
                    }
                    $state.go("tab.invitefriends",{"idTurn":data.result._id});
                },function(err){
                });

            },function(error){
                UtilsSrv.showPopup("Hubo un error al guardar el telefono",1500);
                $ionicLoading.hide();
            });
        }
    }]);

directives.directive('focus',[
    function() {
        return {
            scope : {
                trigger : '@focus'
            },
            link : [
                'scope',
                'element',
                function(scope, element) {
                    scope.$watch('trigger', function(value) {
                        if (value === "true") {
                            element[0].focus();
                        }
                    });
                }]
        };
    }]);