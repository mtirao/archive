controllers.controller('VotationListCtrl', [
	'$scope',
	'AnalyticsSrv',
	'$ionicHistory',
	'DataSvc',
	'$state',
	'$ionicLoading',
	'UtilsSrv',
	function($scope,AnalyticsSrv,$ionicHistory,DataSvc,$state,$ionicLoading,UtilsSrv) {

		$scope.matches = [];

		AnalyticsSrv.trackView("Votation List");

		$scope.$on('$ionicView.enter', function() {
			setHeader();
		});

		$scope.$on('goBack', function(event, obj) {
			$scope.$parent.activities.show = false;
			$scope.$parent.activities.title = "Actividades";
			$ionicHistory.goBack();
		});

		function getMatchPlayed(){
			$ionicLoading.show({template:"Obteniendo partidos..."});
			DataSvc.getMatchPlayed().then(function(data){
				if(!data){
					UtilsSrv.showPopup("Hubo un error al traer los partidos",2000);
					return;	
				}
				$ionicLoading.hide();
				if(data.code !== 200){
					// handle error
					return;
				}

				$scope.matches = data.result;

			},function(error){
				$ionicLoading.hide();
				UtilsSrv.showPopup("Hubo un error al obtener partidos",1500);
				$ionicHistory.goBack();
			});
		}
		function setHeader(){
			$scope.$parent.activities.show = true;
			$scope.$parent.activities.shareButton = false;
			$scope.$parent.activities.title = "Partidos Jugados";
		}

		$scope.goToVotation = function(idTurn){
			$state.go("tab.votation",{"idTurn":idTurn});
		};

		setHeader();
		getMatchPlayed();
	}]);
