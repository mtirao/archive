controllers.controller('FriendsCtrl', [
	'$scope',
	'$ionicLoading',
	'AnalyticsSrv',
	'FacebookService',
	'DataSvc',
	'UtilsSrv',
	function($scope,$ionicLoading,AnalyticsSrv,FacebookService,DataSvc,UtilsSrv) {

		AnalyticsSrv.trackView("Friends View");

		$scope.isLeaderboardLoaded = false;

		$scope.infiniteScroll = false;

		$scope.friends = [];

		$scope.message = "";

		var countPlayers = 0;
		var skipSended = [];

		// $scope.$on('$ionicView.enter', function() {
		// 	if(!$scope.isLeaderboardLoaded){
		// 		getAllFriends();
		// 	}
		// });

		var token = window.localStorage["tokenFB"];
		$ionicLoading.show({
			template: 'Cargando Amigos...'
		});

	    function isAlreadySended(skip){
	      for (var i = 0; i < skipSended.length; i++) {
	        if(skipSended[i] == skip){
	          return true;
	        }
	      };
	      return false;
	    }

		function getAllFriends(){
			var skip = countPlayers;
			
		    if(isAlreadySended(skip)){
		    	return;
		    }

		    skipSended.push(skip);

			DataSvc.getFriendsLeaderboard(skip).then(function(data){
				
				$ionicLoading.hide();
				$scope.$broadcast('scroll.refreshComplete');

				if(!data){
					
					$scope.message = "Hubo un error al traer el Leaderboard";
			    	if($scope.friends.length > 0){
			    		UtilsSrv.showPopup("Hubo un error al traer el Leaderboard",2000);
			    	}
					return;
				}

				if(data.code !== 200){
					return;
				}

				$scope.infiniteScroll = true;

				$scope.isLeaderboardLoaded = true;

				if(skip > 0){
					for (var i = 0; i < data.result.length; i++) {
						if(data.result[i].device._id == window.localStorage["deviceId"]){
			              data.result[i].me = "me";
			            }
						$scope.friends.push(data.result[i]);
					}
					countPlayers += data.result.length;
					return;
				}

				$scope.winner = data.result[0];
				countPlayers += data.result.length;
				data.result.shift();
				for (var i = 0; i < data.result.length; i++) {
					if(data.result[i].device._id == window.localStorage["deviceId"]){
		              data.result[i].me = "me";
		            }
				}
				$scope.friends = data.result;
				if($scope.friends.length == 0){
					$scope.message = "No tienes amigos usando Qiú";
				}
			},function(error){
				$ionicLoading.hide();
				UtilsSrv.showPopup("Hubo un error al cargar el Leaderboard de Amigos",1500);
			});

		}

		function handleFacebookErrors(error){
			if(error.error.code == 190){
				if(error.error.error_subcode == 463){
					// $cordovaToast.show('La sesion de Facebook ha expirado por favor loguearse nuevamente','long','center');
					UtilsSrv.showPopup("La sesion de Facebook ha expirado por favor loguearse nuevamente",1500);
				}else if(error.error.error_subcode == 467){
					// access_token error
					// $cordovaToast.show('Por favor loguearse nuevamente','short','center');
					UtilsSrv.showPopup("Por favor loguearse nuevamente",1500);
				}
			}
		}

		$scope.loadMore = function(){
			$scope.$broadcast('scroll.infiniteScrollComplete');
			if($scope.infiniteScroll){
				$scope.infiniteScroll = false;
				getAllFriends();
			}
		}

		$scope.doRefresh = function(){
			countPlayers = 0;
			skipSended = [];
			getAllFriends();
		};

		getAllFriends();
	}]);
