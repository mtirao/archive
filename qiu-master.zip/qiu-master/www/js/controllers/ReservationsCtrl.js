controllers.controller('ReservationsCtrl', [
  '$scope',
  '$compile',
  'AnalyticsSrv',
  '$ionicModal',
  '$state',
  '$rootScope',
  'LocationSrv',
  'TurnSrv',
  'AdminSrv',
  '$cordovaToast',
  'UserSvc',
  '$ionicLoading',
  'UtilsSrv',
  function($scope,$compile,AnalyticsSrv, $ionicModal,$state,$rootScope,LocationSrv,TurnSrv,AdminSrv,$cordovaToast,UserSvc,$ionicLoading,UtilsSrv) {

    AnalyticsSrv.trackView("Map View");

    var mapaInit = false;
    var lastCenter;

    $scope.dateReservation = "";

    var map;
    $scope.markers = [];

    $scope.modalinfo = {};

    var lastDate;
    var lastHour;
    var lastType;

    var firstCenter;

    $scope.$on('$ionicView.enter', function() {
      if(window.isLoaded()){
        if(!mapaInit){
          if(window.localStorage["lastLat"] != undefined && window.localStorage["lastLng"] != undefined){
            initialize(window.localStorage["lastLat"],window.localStorage["lastLng"]);
            return;
          }
          var lat = -32.8902722;
          var lon = -68.8439728;
          initialize(lat,lon);
        }else{
          resize();
        }
      }
    });

    function existsPhone(){
      return (window.localStorage["phone"] !== "" && window.localStorage["phone"] !== undefined);
    }

    function initialize(lat,lon) {
      var myLatlng = new google.maps.LatLng(lat,lon);
      lastCenter = myLatlng;

      var mapOptions = {
        center: myLatlng,
        zoom: 13,
        mapTypeId: google.maps.MapTypeId.ROADMAP,
        disableDefaultUI: true,
        draggable: false
      };
      map = new google.maps.Map(document.getElementById("map"),mapOptions);

      firstCenter = map.getCenter();

      map.addListener('dragend', function(e) {
        var dist = getDistance(firstCenter,map.getCenter());
        lastCenter = map.getCenter();
        if(dist > 0){// metros
          $rootScope.findTurnsByDateAndHour(lastDate,lastHour,lastType);
          firstCenter = map.getCenter();
        }
      });

      $scope.map = map;

      mapaInit = true;
    }
    // ionic.Platform.ready(initialize);

    $rootScope.resizeMap = function(){
      if(window.localStorage["lastLat"] != undefined && window.localStorage["lastLng"] != undefined){
        initialize(window.localStorage["lastLat"],window.localStorage["lastLng"]);
        return;
      }
      var lat = -32.8902722;
      var lon = -68.8439728;
      initialize(lat,lon);
    }

    function resize(){
      google.maps.event.trigger(map, 'resize');
      map.setCenter(lastCenter);
    }

    var rad = function(x) {
      return x * Math.PI / 180;
    };

    var getDistance = function(p1, p2) {
      var R = 6378137; // Earth’s mean radius in meter
      var dLat = rad(p2.lat() - p1.lat());
      var dLong = rad(p2.lng() - p1.lng());
      var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
          Math.cos(rad(p1.lat())) * Math.cos(rad(p2.lat())) *
          Math.sin(dLong / 2) * Math.sin(dLong / 2);
      var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
      var d = R * c;
      return d; // returns the distance in meter
    };


    $ionicModal.fromTemplateUrl('templates/modals/reservation-modal.html', {
      scope: $scope,
      animation: 'slide-in-up'
    }).then(function(modal) {
      $scope.modal = modal;
    });

    function formatHour(lastHour){
      var newHour;
      if(parseInt(lastHour) < 10){
        newHour = "0"+lastHour+":00";
      }else{
        newHour = lastHour+":00";
      }
      return newHour;
    }
    $scope.openModal = function(idAdmin) {
      AdminSrv.getAdmin(idAdmin).then(function(data){
        if(data.code !== 200){
          // $cordovaToast.show('No pudo obtenerse la informacion de la cancha', 'short', 'center');
          UtilsSrv.showPopup('No pudo obtenerse la informacion de la cancha',1500);
          return;
        }
        $scope.modalinfo.name = data.result.name;
        $scope.modalinfo.address = data.result.address;
        $scope.modalinfo.hour = formatHour(lastHour);

      });
      $scope.modal.show();
    };
    $scope.closeModal = function() {
      $scope.modal.hide();
    };

    $scope.inviteFriends = function(){
      $scope.modal.hide();
      $rootScope.activeFromController();
    }

    //Cleanup the modal when we're done with it!
    $scope.$on('$destroy', function() {
      $scope.modal.remove();
    });
    // Execute action on hide modal
    $scope.$on('modal.hidden', function() {
      // Execute action
    });
    // Execute action on remove modal
    $scope.$on('modal.removed', function() {
      // Execute action
    });


    function cleanAllMarkers(){
      for (var i = 0; i < $scope.markers.length; i++) {
        $scope.markers[i].setMap(null);
      }
      $scope.markers = [];
    }

    $rootScope.setMapDraggable = function(value){
      if(!map){
        return;
      }
      map.setOptions({draggable: value});
    }

    function getObjectDate(plusHours){
      if (typeof plusHours === 'undefined') { plusHours = 0; }
      var day = lastDate.split("/")[0];
      var month = lastDate.split("/")[1];
      var year = lastDate.split("/")[2];
      var date = new Date(parseInt(year),parseInt(month)-1,parseInt(day),parseInt(lastHour)+plusHours,0,0,0);
      return date;
    }

    function getIcon(state){
      var icon = "";
      switch(state){
        case 1:
          icon = "img/icon-map-pin-green.png";
          break;
        case 2:
          icon = "img/icon-map-pin-yellow.png";
          break;
        case 3:
          icon = "img/icon-map-pin-red.png";
          break;
      }
      return icon;
    }

    $scope.clickInfoWindow = function(idAdmin,idGround,state){
      var date = getObjectDate();
      if(state == 3){
        $scope.openModal(idAdmin);
        return;
      }
      $ionicLoading.show({
        template: 'Verificando cancha...'
      });
      UserSvc.checkTurnsByDate(date).then(function(data){
        $ionicLoading.hide();
        if(!data){
          UtilsSrv.showPopup("Hubo un error, por favor verifique su conexion a internet",2000);
          return;
        }

        if(data.code !== 200){
          
          // $cordovaToast.show('Hubo un error', 'short', 'center');
          UtilsSrv.showPopup('Hubo un error',1500);
          return;
        }

        if(data.result.error){
          // $cordovaToast.show(data.result.error, 'short', 'center');
          UtilsSrv.showPopup(data.result.error,1500);
          return;
        }

        if(data.result.groundsReserved > 0){
          // $cordovaToast.show('Ya tiene una reserva en un cancha para esa fecha y hora', 'short', 'center');
          UtilsSrv.showPopup('Ya tiene una reserva en un cancha para esa fecha y hora',1500);
          return;
        }


        if(state !== 3){
          lastCenter = map.getCenter();

          // var day = lastDate.split("/")[0];
          // var month = lastDate.split("/")[1];
          // var year = lastDate.split("/")[2];
          // var from = new Date(parseInt(year),parseInt(month)-1,parseInt(day),parseInt(lastHour),0,0,0);
          var from = getObjectDate();
          // var to = new Date(parseInt(year),parseInt(month)-1,parseInt(day),parseInt(lastHour)+1,0,0,0);
          var to = getObjectDate(1);


          if(!existsPhone()){
            $state.go("tab.confirmation",
                {'idAdmin':idAdmin,
                  'idGround':idGround,
                  'name':window.localStorage["name"],
                  'from':from,
                  'to':to,
                  'typeId':lastType
                });
            return;
          }

          var name = window.localStorage["name"];
          var phone = window.localStorage["phone"];

          TurnSrv.createHeaderTurn(idAdmin,idGround,name,phone,from,to).then(function(data){

            if(data.code !== 200){
              // handle error
              return;

            }

            // $state.go("tab.invitefriends",
            //   {'idAdmin':idAdmin,
            //   'idGround':idGround,
            //   'name': window.localStorage["name"],
            //   'phone': window.localStorage["phone"],
            //   'from':from,
            //   'to':to,
            //   'typeId':lastType
            // });
            // $state.go("tab.invitefriends",{"idAdmin":data.result._id});

            $state.go("tab.invitefriends",{"idTurn":data.result._id});

          },function(err){
            // $cordovaToast.show("Hubo un error y no pudo crearse el turno por favor intentelo nuevamente","short","center");
            UtilsSrv.showPopup("Hubo un error y no pudo crearse el turno por favor intentelo nuevamente",1500);
          });

        }

      },function (err){
        $ionicLoading.hide();
        // $cordovaToast.show("Hubo un error y no pudo crearse el turno por favor intentelo nuevamente","short","center");
        UtilsSrv.showPopup("Hubo un error y no pudo crearse el turno por favor intentelo nuevamente",1500);
      });
    };

    function addClickListener(marker){

      var contentString = "<button class='button button-clear button-positive' \
                        ng-click=\"clickInfoWindow('"+marker.idAdmin+"','"+marker.idGround+"','"+marker.state+"')\">"
          +marker.name+"</button>";
      var compiled = $compile(contentString)($scope);
      marker.infowindow = new google.maps.InfoWindow({
        content: compiled[0]
      });

      google.maps.event.addListener(marker, 'click', function() {
        marker.infowindow.open(map, marker);
      });
    }
    function addMarker(marker){

      var ll = new google.maps.LatLng(marker.location[1],marker.location[0]);

      var newMarker = new google.maps.Marker({
        position: ll,
        map: map,
        title: '',
        icon: getIcon(marker.state),
        idAdmin: marker._id,
        idGround: marker.ground,
        state: marker.state,
        name: marker.name
      });

      addClickListener(newMarker);

      $scope.markers.push(newMarker);
    }

    function removeMarker(idMarker){
      for (var i = 0; i < $scope.markers.length; i++) {
        if($scope.markers[i].idAdmin == idMarker){
          $scope.markers[i].setMap(null);
          $scope.markers.splice(i, 1);
          break;
        }
      };
    }

    function closeAllInfoWindows(){
      for (var i = 0; i < $scope.markers.length; i++) {
        $scope.markers[i].infowindow.close();
      };
    }

    function checkState(marker,newState,oldState){

      if(newState !== oldState){
        marker.setIcon(getIcon(newState));
        marker.state = newState;
        marker.infowindow.close();
        google.maps.event.clearListeners(marker, 'click');
        addClickListener(marker);
      }

    };

    function removeIfNotExists(markers){
      var toRemove = [];
      for (var i = 0; i < $scope.markers.length; i++) {
        var exists = false;

        for (var j = 0; j < markers.length; j++) {

          if(markers[j] == null){
            continue;
          }

          if($scope.markers[i].idAdmin == markers[j]._id){
            exists = true;
            break;
          }
        };
        if(!exists){
          toRemove.push($scope.markers[i].idAdmin);
        }
      };
      if(toRemove.length > 0){
        for (var i = 0; i < toRemove.length; i++) {
          removeMarker(toRemove[i]);
        };
      }
    };

    function checkMarkers(newMarkers){

      removeIfNotExists(newMarkers);

      for (var i = 0; i < newMarkers.length; i++) {

        if(newMarkers[i] == null){
          continue;
        }

        var exists = false;
        for (var j = 0; j < $scope.markers.length; j++) {
          if(newMarkers[i]._id == $scope.markers[j].idAdmin){
            checkState($scope.markers[j],newMarkers[i].state,$scope.markers[j].state);
            exists = true;
            break;
          }
        };

        if(!exists){
          addMarker(newMarkers[i]);
        }

      };

    }

    function getTurnsByLocationAndDate(day,hour,location,typeId){
      TurnSrv.getTurnsByLocationAndDate(day,hour,location,typeId).then(function(data){
        if(data.code !== 200){
          cleanAllMarkers();
          return;
        }

        // window.localStorage["lastLat"] = location.lat;
        // window.localStorage["lastLng"] = location.lng;

        $scope.dateReservation = day.split("/")[0]+"/"+day.split("/")[1]+" "+hour+"hs" ;


        lastDate = day;
        lastHour = hour;
        lastType = typeId;
        var newMarkers = data.result.object;
        // cleanAllMarkers();

        if(newMarkers.length == 0){
          // handle when there is no grounds
          cleanAllMarkers();
          // $cordovaToast.show("No se encontraron canchas en esta zona","short","center");
        }else{
          // addMarkers(newMarkers);
          checkMarkers(newMarkers);
        }

      });
    }

    $rootScope.findTurnsByDateAndHour = function(day,hour,typeId){
      var location = {
        "lat": map.getCenter().lat(),
        "lng": map.getCenter().lng()
      };

      closeAllInfoWindows();

      if(lastType != typeId){
        cleanAllMarkers();
      }

      if(typeId == null){
        typeId = lastType;
      }
      getTurnsByLocationAndDate(day,hour,location,typeId);
    }

  }]);
