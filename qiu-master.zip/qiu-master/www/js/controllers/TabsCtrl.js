controllers.controller('TabsCtrl', [
  '$scope',
  '$rootScope',
  function($scope,$rootScope) {
    $scope.reservations = false;

    $scope.activities = {};
    $scope.activities.show = false;
    $scope.activities.shareButton = false;
    $scope.activities.title = "Actividades";

    $scope.classNotification = "";

    $scope.changeActive = function(){
      $scope.reservations = !$scope.reservations;
    };

    $scope.goBack = function(){
      $scope.$broadcast('goBack');
    };

    $scope.share = function(){
      $scope.$broadcast('share');
    };

    $rootScope.setIconNotification = function(existsNotification){
      if(existsNotification){
        $scope.classNotification = "act";
      }else{
        $scope.classNotification = "";
      }
    };

  }]);
