controllers.controller('ActivitiesCtrl', [
  '$scope',
  'AnalyticsSrv',
  'NotificationSvc',
  '$state',
  '$stateParams',
  '$ionicLoading',
  '$cordovaToast',
  'UtilsSrv',
  function($scope,AnalyticsSrv,NotificationSvc,$state,$stateParams,$ionicLoading,$cordovaToast,UtilsSrv) {

    AnalyticsSrv.trackView("Reservations View");

    var deviceId = window.localStorage["deviceId"];
    var days = ['Domingo','Lunes','Martes','Miercoles','Jueves','Viernes','S\u00e1bado'];

    $scope.reservations_this = [];
    $scope.reservations_next = [];

    $scope.message = "";

    $scope.$on('$ionicView.enter', function() {
      setHeader();
    });

    $scope.goReservationCard = function(idTurn,type){
      $state.go("tab.reservation_cardAct",{"turnId":idTurn,"type":type});
    };

    $scope.doRefresh = function(){
      getAllReservations();
    };

    function getResponse(data){
      var resp = [];

      for (var i = 0; i < data.length; i++) {
        var date  = new Date(data[i].date.from);
        var friendsAccept = 0;
        for (var j = 0; j < data[i].invitations.length; j++) {
          if(data[i].invitations[j].accepted){
            friendsAccept++;
          }
        }

        var icon = getIcon(data[i].confirmed,data[i].type);
        resp.push({
          "idTurn":data[i]._id,
          "detail": "Partido "+getDateAndHour(date),
          "players":(friendsAccept==1)?friendsAccept+" confirmado":friendsAccept+" confirmados",
          "icon":icon,
          "type":data[i].type,
          "name":data[i].name,
          "isThisWeek":data[i].isThisWeek
        });
      }
      return resp;
    }

    function getIcon(confirmed,type){
      if(confirmed){
        if(type == "invitation"){
          return "icons-invitar-green.png";
        }else{
          return "icons-invitar-green-star.png";
        }
      }else{
        if(type == "invitation"){
          return "icons-invitar.png";
        }else{
          return "icons-invitar-star.png";
        }
      }
    }

    function getAllReservations(){

      NotificationSvc.getAllReservations(deviceId).then(function(data){
        $ionicLoading.hide();
        $scope.$broadcast('scroll.refreshComplete');

        if(!data){
          // UtilsSrv.showPopup("Hubo un error, por favor verifique su conexion a internet",2000);
          $scope.message = "Hubo un error al traer las reservas";
          if(($scope.reservations_this.length + $scope.reservations_next.length) > 0){
            UtilsSrv.showPopup("Hubo un error al traer las reservas",2000);
          }
          return;
        }

        if(data.code !== 200){
          UtilsSrv.showPopup("Hubo un error al cargar las Reservas",1500);
          return;
        }

        var resp = getResponse(data.result);
        $scope.reservations_this = [];
        $scope.reservations_next = [];
        
        for (var i = 0; i < resp.length; i++) {
          if(resp[i].isThisWeek){
            $scope.reservations_this.push(resp[i]);
          }else{
            $scope.reservations_next.push(resp[i]);
          }
        }

        if(($scope.reservations_this.length + $scope.reservations_next.length) == 0){
          $scope.message = "No tiene reservas";
        }

      },function(error){
        $ionicLoading.hide();
        $scope.$broadcast('scroll.refreshComplete');
        UtilsSrv.showPopup("Hubo un error al cargar las Reservas",1500);
      });
    }

    function getDateAndHour(date){
      var dayOfWeek = days[date.getDay()];
      var day = formatDayOrHour(date.getDate());
      var month = formatDayOrHour(date.getMonth()+1);
      var hour = formatDayOrHour(date.getHours());
      var minutes = formatDayOrHour(date.getMinutes());
      return dayOfWeek+" "+day+"/"+month+" | "+hour+":"+minutes;
    }
    function formatDayOrHour(value){
      if(parseInt(value)<10){
        return "0"+value;
      }else{
        return value;
      }
    }

    function setHeader(){
      $scope.$parent.activities.show = false;
      $scope.$parent.activities.shareButton = false;
      $scope.$parent.activities.title = "Actividades";
    }

    setHeader();
    getAllReservations();

  }]);