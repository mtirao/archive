services
    .factory('HttpInterceptorSvc', [
        'env',
        'Base64',
        function testInterceptor(env,Base64) {
            return {
                request: function(config) {
                    if(config.url.indexOf("api") !== -1){
                        config.headers['Content-Type'] = "application/json";
                        config.headers['Authorization'] = 'Basic ' + Base64.encode(env.user + ':' + env.pass);
                    }
                    return config;
                },

                requestError: function(config) {
                    return config;
                },

                response: function(res) {
                    return res;
                },

                responseError: function(res) {
                    return res;
                }
            }
        }
    ])
.factory('$localstorage', ['$window', function($window) {
    return {
        set: function(key, value) {
            $window.localStorage[key] = value;
        },
        get: function(key, defaultValue) {
            return $window.localStorage[key] || defaultValue;
        },
        setObject: function(key, value) {
            $window.localStorage[key] = JSON.stringify(value);
        },
        getObject: function(key) {
            return JSON.parse($window.localStorage[key] || '{}');
        }
    }
}]);