services.factory('AccessSvc', [
  "$http",
  "$q",
  "$localstorage",
  "env",
  function($http,$q,$localstorage,env) {

    var access = {};

    /**
     * Add new device to the server
     * @TODO: JULIAN, FIJATE LO QUE TENGAS QUE CAMBIAR EN EL SERVER O EN ESTE SERVICIO PARA QUE FUNCIONE
     */
    access.logDevice = function logDeviceFn(cb){
      console.log($localstorage.get('device'));      
      if($localstorage.get('device')){
        cb();
        return;
      }

      var platform = 'android';
      var isIOS = ionic.Platform.isIOS();
      if(isIOS){
        platform = 'ios';
      }

      var device = {
        platform: platform,
        device: ionic.Platform.device(),
        isPushActive: true
      };
      console.log(device);
      var deviceId = window.localStorage["deviceId"];
      console.log(env.api+'/user/'+deviceId+'/addDeviceInfo');
      $http.post(env.api+'/user/'+deviceId+'/addDeviceInfo',device)
        .success(function(response){
          console.log(response);
          if(response.code !== 200){
            return;
          }
          $localstorage.setObject('device',response.result);
          cb();
        })
        .error(function(err){
          console.log(err);
        });
    };

    /**
     * Get user by device id
     * @returns {*}
     */
    access.get = function(){
      var deferred = $q.defer();

      if(!$localstorage.get('device')){
        deferred.reject("The user is not logged");
        return;
      }

      var device = $localstorage.getObject("device");

      $http.get(env.http+'devices/show/'+device._id)
        .success(function(response) {
          if(response.code !== 200 || !response.result){
            deferred.reject("No user on database");
            return;
          }
          deferred.resolve(response.result);
        })
        .error(function(err){
          deferred.reject(err);
        });
      return deferred.promise;
    };

    /**
     * Get user by device id
     * @returns {*}
     */
    access.update = function(isPushActive){
      var deferred = $q.defer();

      if(!$localstorage.get('device')){
        deferred.reject("The user is not logged");
        return;
      }
      var device = $localstorage.getObject("device");

      $http.post(env.http+'devices/update/'+device._id,{devices:{isPushActive:isPushActive}})
        .success(function(response) {
          if(response.code !== 200){
            deferred.reject("No user on database");
            return;
          }
          $localstorage.setObject('device',response.result);
          deferred.resolve(response.result);
        })
        .error(function(err){
          deferred.reject(err);
        });
      return deferred.promise;
    };

    return access;
  }]);
