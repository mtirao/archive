services
    .factory('PushSvc',[
      '$http',
      '$q',
      '$localstorage',
      '$state',
      'env',
      '$cordovaPush',
      '$rootScope',
      function($http,$q,$localstorage,$state,env,$cordovaPush,$rootScope){

        var conf = {
          android: {
            senderID: "365814209128",
            "icon": "icon",
            "iconColor": "black"
          },
          ios: {
            alert: "true",
            badge: false,
            sound: 'false'
          },
          windows: {}
        };

        var config = {};

        var isIOS = ionic.Platform.isIOS();
        var isAndroid = ionic.Platform.isAndroid();
        if(isAndroid){
          config.senderID = "365814209128";
        }
        if(isIOS){
          config.badge = true;
          config.sound = true;
          config.alert = true;
        }

        var pushNot = {
          // init: function initFn(conf){
          //   return {
          //     on: function OnFn(verb,cb){}
          //   }
          // }
          register: function registerFn(){
            
          }
        };
        

        function updateIdRegister(idGcm){

          var deferred = $q.defer();
          var deviceId = window.localStorage["deviceId"];
          $http.post(env.api+'/user/'+deviceId+"/registergcm/"+idGcm,{})
              .success(function (response) {
                deferred.resolve(response);
              })
              .error(function (data, status, headers, config) {
                deferred.reject('Error occured');
              });

          return deferred.promise;
        }


        function register(){
          var deferred = $q.defer();

          $cordovaPush.register(config).then(function(result) {
            // Success
            if(isIOS){
              updateIdRegister(result).then(function(data){
                // console.log(data);
                if(data.code !== 200){
                  // handle error
                  return;
                }

              },function(err){
                console.log(err);
              });
            }
            deferred.resolve(result);
          }, function(err) {
            // Error
            deferred.reject("Error on register");
          })

          return deferred.promise;

        }

        $rootScope.$on('$cordovaPush:notificationReceived', function(event, notification) {

          if(isIOS){
            if (notification.alert) {
              $rootScope.setIconNotification(true);
              $rootScope.newNotifications++;
            }

            if (notification.sound) {
              
            }

            if (notification.badge) {
              
            }
            return;
          }

          switch(notification.event) {
            case 'registered':
              if (notification.regid.length > 0 ) {
                // alert('registration ID = ' + notification.regid);
                var idNotification = notification.regid;

                updateIdRegister(idNotification).then(function(data){
                  
                  if(!data){
                    return;
                  }
                  if(data.code !== 200){
                    // handle error
                    return;
                  }

                },function(err){
                  console.log(err);
                });
              }
              break;

            case 'message':
              // this is the actual push notification. its format depends on the data model from the push server
              // alert('message = ' + notification.message + ' msgCount = ' + notification.msgcnt);
              // console.log("NOTIFICATION");
              $rootScope.setIconNotification(true);
              $rootScope.newNotifications++;
              break;

            case 'error':
              break;

            default:
              break;
          }

        });



        /**
         * Initialized plugin
         */
        function initialized(){
          if(window.cordova && window.cordova.plugins){
            // pushNot = PushNotification;
            pushNot = $cordovaPush;
          }
          return pushNot;
        }

        /**
         * Listen register and notification
         * @param instance
         */
        function listen(instance){
          instance.on('registration', function(data) {
            var update = {
              token: data.registrationId
            };

            //@todo: JULIAN Mandar la informacion de la plataforma al server
           
            // var deviceId = $localstorage.getObject('device')._id;
            // $http.post(env.api+'/user/'+deviceId+"/registergcm/"+data.registrationId,{})
            //     .success(function (response) {
            //     })
            //     .error(function (data, status, headers, config) {
            //     });
          });

          instance.on('notification', function(data) {
          });

          instance.on('error', function(e) {
            console.log(e);
          });
        }

        return {
          initialized: initialized,
          conf: conf,
          listen: listen,
          register: register
        };
      }
    ]);
