services.factory('LoginSrv', [
  '$q',
  '$http',
  'env',
  '$timeout',
  function($q,$http,env,$timeout) {

    var login = {};

    login.authorize = function(id,name,platform){
      var deferred = $q.defer();
      var timeoutPromise = $timeout(function() {
        deferred.reject("Timed out");
      }, 15000);
      var device = ionic.Platform.device();
      $http.post(env.api+'/user/authorize',{"hash":id,"fbLogin":id,"name":name,"platform":platform,"device":device})
          .success(function (response) {
            if(response && response.deviceId){
              $timeout.cancel(timeoutPromise);
              deferred.resolve(response);
            }else{
              $timeout.cancel(timeoutPromise);
              deferred.reject('Error occured');
            }
            
          })
          .error(function (data, status, headers, config) {
            $timeout.cancel(timeoutPromise);
            deferred.reject('Error occured');
          });

      return deferred.promise;
    }

    return login;
  }])