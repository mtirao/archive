services.factory('LocationSrv',[
  '$http',
  '$q',
  function($http,$q) {

    var location = {};

    location.getIpLocation = function(id){
      var deferred = $q.defer();
      $http.post("http://ip-api.com/json",{})
          .success(function (response) {
            deferred.resolve(response);
          })
          .error(function (data, status, headers, config) {
            deferred.reject('Error occured');
          });

      return deferred.promise;
    }

    return location;
  }])