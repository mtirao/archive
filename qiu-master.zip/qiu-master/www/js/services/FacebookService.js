services.factory('FacebookService', [
    '$q',
    '$http',
    '$cordovaOauth',
    'env',
    function($q,$http,$cordovaOauth,env) {

        var facebook = {};
        var sdkIsLoaded = false;

        facebook.login = function(){

            var deferred = $q.defer();
            facebookConnectPlugin.login(['email',"user_friends"], function(resp){
                deferred.resolve(resp.authResponse);
            }, function(error){
                console.log(error);
                deferred.reject('Error no pudo ingresar');
            });
            return deferred.promise;
        };

        facebook.getFriends = function(token){
            var deferred = $q.defer();

            if(!sdkIsLoaded){
                this.loadFacebookSDK().then(function(status){
                    sdkIsLoaded = true;
                    FB.init({
                        appId      : env.appID,
                        xfbml      : true,
                        version    : 'v2.0',
                    });
                    FB.api('/me/friends',{
                        access_token: token
                    }, function(response){
                        if (!response || response.error) {
                            deferred.reject(response);
                        } else {
                            deferred.resolve(response);
                        }
                    });
                },function(status){
                    deferred.reject(status);
                });
                return deferred.promise;
            }

            FB.api('/me/friends',{
                access_token: token
            }, function(response){
                if (!response || response.error) {
                    deferred.reject(response);
                } else {
                    deferred.resolve(response);
                }
            });
            return deferred.promise;
        }

        facebook.getNextFriends = function(url){
            var deferred = $q.defer();
            $http.get(url,{}).then(function(data){
                deferred.resolve(data);
            },function(error){
                deferred.reject(error);
            });
            return deferred.promise;
        }

        facebook.getIdFacebook = function(token){
            var deferred = $q.defer();
            
            if(!sdkIsLoaded){
                this.loadFacebookSDK().then(function(status){
                    sdkIsLoaded = true;
                    FB.init({
                        appId      : env.appID,
                        xfbml      : true,
                        version    : 'v2.0',
                    });
                    FB.api('/me', {
                        fields: 'name,email',
                        access_token: token
                    }, function(response) {
                        // alert(response);
                        if (!response || response.error) {
                            deferred.reject('Error occured');
                        } else {
                            deferred.resolve(response);
                        }
                    });
                },function(status){
                    deferred.reject('Error ocurred');
                });
                return deferred.promise;
            }
            
            FB.api('/me', {
                fields: 'name,email',
                access_token: token
            }, function(response) {
                // alert(response);
                if (!response || response.error) {
                    deferred.reject('Error occured');
                } else {
                    deferred.resolve(response);
                }
            });
            return deferred.promise;
        }

        facebook.actualizeLeaderboardFriends = function(token){
            var deferred = $q.defer();
            var deviceId = window.localStorage["deviceId"];
            var idFacebook = window.localStorage["idFacebook"];
            var token = window.localStorage["tokenFB"];
            $http.put(env.api+'/leaderboard/actualizeFriends',{"deviceId":deviceId,"token":token})
            .success(function (response) {
                deferred.resolve(response);
            })
            .error(function (data, status, headers, config) {
                deferred.reject('Error occured');
            });
            return deferred.promise;
        }

        facebook.loadFacebookSDK = function(){
        
            var deferred = $q.defer();
            var script = document.createElement('script');
            script.type = 'text/javascript';
            script.src = 'http://connect.facebook.net/en_US/all.js';
            document.body.appendChild(script); 
            script.addEventListener('load', function() {
                deferred.resolve(true);
            }, false);

            script.addEventListener('error', function() {
                deferred.reject(false);
            }, false);
            return deferred.promise;
        }

        return facebook;
    }]);