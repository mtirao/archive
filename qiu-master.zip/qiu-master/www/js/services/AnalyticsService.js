services.factory('AnalyticsSrv',[
    function(){

      var response = {};
      var isAnalyticsActive = false;

      response.checkAnalytics = function checkAnalyticsFn(){
        isAnalyticsActive = (typeof analytics !== "undefined");
        return isAnalyticsActive;
      };

      response.startTrackerWithId = function startTrackerWithIdFn(trackId){
        if(response.checkAnalytics()){
          window.analytics.startTrackerWithId(trackId);
        }
      };

      response.trackView = function trackViewFn(title){
        if(response.checkAnalytics()) {
          window.analytics.trackView(title);
        }
      };

      response.trackEvent = function trackEventFn(category,action,label,value){
        if(response.checkAnalytics()) {
          window.analytics.trackEvent(category, action, label, value);
        }
      };

      response.addTransaction = function addTransactionFn(id,affiliation,revenew,tax,shipping,currencyCode){
        if(response.checkAnalytics()) {
          window.analytics.addTransaction(id, affiliation, revenew, tax, shipping, currencyCode);
        }
      };

      response.addTransactionItem = function addTransactionItemFn(id,name,sku,category,price,quantity,currencyCode){
        if(response.checkAnalytics()) {
          window.analytics.addTransactionItem(id, name, sku, category, price, quantity, currencyCode);
        }
      };

      response.setUserId = function setUserIdFn(userId){
        if(response.checkAnalytics()){
          window.analytics.setUserId(userId);
        }
      };

      response.debugMode = function debugModeFn(){
        if(response.checkAnalytics()){
          window.analytics.debugMode();
        }
      };

      return response;
    }
  ]);
