services.factory('DataSvc', [
  '$q',
  '$http',
  'env',
  '$timeout',
  function($q,$http,env,$timeout) {
    var data = {};

    data.getLeaderboard = function(skip){

      var deferred = $q.defer();

      var timeoutPromise = $timeout(function() {
        deferred.reject("Timed out");
      }, 10000);

      var deviceId = window.localStorage["deviceId"];
      $http.post(env.api+'/leaderboard/mvp/top/5?deviceId='+deviceId,{"skip":skip})
          .success(function (response) {
            $timeout.cancel(timeoutPromise);
            deferred.resolve(response);            
          })
          .error(function (data, status, headers, config) {
            $timeout.cancel(timeoutPromise);
            deferred.reject('Error occured');
          });

      return deferred.promise;
    }

    data.getMatchPlayed = function(){
      var deferred = $q.defer();
      var idFacebook = window.localStorage["idFacebook"];
      var deviceId = window.localStorage["deviceId"];

      var timeoutPromise = $timeout(function() {
        deferred.reject("Timed out");
      }, 10000);

      $http.post(env.api+'/user/'+deviceId+'/getMatchPlayed',{"idFacebook":idFacebook})
          .success(function (response) {
            $timeout.cancel(timeoutPromise);
            deferred.resolve(response);
          })
          .error(function (data, status, headers, config) {
            $timeout.cancel(timeoutPromise);
            deferred.reject('Error occured');
          });

      return deferred.promise;
    }

    data.getTypes = function(){
      var deferred = $q.defer();
      $http.post(env.api+'/type',{})
          .success(function (response) {

            if(response){
              deferred.resolve(response);
            }else{
              deferred.reject('Error occured');
            }
            
          })
          .error(function (data, status, headers, config) {
            deferred.reject('Error occured');
          });

      return deferred.promise;
    }

    data.getFriendsLeaderboard = function(skip){
      var deferred = $q.defer();

      var timeoutPromise = $timeout(function() {
        deferred.reject("Timed out");
      }, 10000);

      var deviceId = window.localStorage["deviceId"];
      var idFacebook = window.localStorage["idFacebook"];
      $http.post(env.api+'/leaderboard/mvp/getFriends',
          {"deviceId":deviceId,"skip":skip,"idFacebook":idFacebook}
      )
          .success(function (response) {
            $timeout.cancel(timeoutPromise);
            deferred.resolve(response);
          })
          .error(function (data, status, headers, config) {
            $timeout.cancel(timeoutPromise);
            deferred.reject('Error occured');
          });

      return deferred.promise;
    }

    return data;

  }])