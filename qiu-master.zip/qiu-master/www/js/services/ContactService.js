services.factory('ContactSrv', [
  '$cordovaContacts',
  function($cordovaContacts) {

    var contacts = {};

    contacts.getAllContacts = function(){
      var opts = {                                  //search options
        filter : "",
        multiple: true,                                      // Yes, return any contact that matches criteria
        fields:  [ 'displayName', 'name','phoneNumbers'],
        desiredFields: ['displayName', 'name','phoneNumbers']   //return fields.
      };

      $cordovaContacts.find(opts).then(function (contactsFound) {
        var existsContact = [];
        var finalResult = [];

        for (var i = 0; i < contactsFound.length; i++) {
          if(contactsFound[i].phoneNumbers !== null){
            existsContact.push(contactsFound[i]);
          }
        };
        existsContact.sort(function(a, b) {
          if(a.displayName < b.displayName) return -1;
          if(a.displayName > b.displayName) return 1;
          return 0;
        });

        return existsContact;
      });
    };

    return contacts;
  }]);