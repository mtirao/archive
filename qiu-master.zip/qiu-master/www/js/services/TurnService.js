services.factory('TurnSrv',[
  '$q',
  '$http',
  'env',
  '$timeout',
  function($q,$http,env,$timeout) {

    var turns = {};

    turns.getTurnsByLocationAndDate = function(date,hour,location,typeId){
      var deferred = $q.defer();
      var day = date.split("/")[0];
      var month = date.split("/")[1];
      var year = date.split("/")[2];
      var newDate = new Date(year,month-1,day,hour,0,0,0);
      $http.post(env.api+'/turn',{"date":newDate,"location":location,"typeId":typeId})
          .success(function (response) {
            deferred.resolve(response);
          })
          .error(function (data, status, headers, config) {
            deferred.reject('Error occured');
          });

      return deferred.promise;
    }

    turns.votatePlayers = function(turnId,players){
      var deferred = $q.defer();
      var idFacebook = window.localStorage["idFacebook"];
      var timeoutPromise = $timeout(function(){
        deferred.reject("Timed out");
      },10000);
      $http.post(env.api+'/turn/'+turnId+'/votate',{"players":players,"idFacebook":idFacebook})
          .success(function(response){
            $timeout.cancel(timeoutPromise);
            deferred.resolve(response);
          }).error(function(data,status,headers,config){
            $timeout.cancel(timeoutPromise);
            deferred.reject("Error ocurred");
          });
      return deferred.promise;
    }

    turns.getFriendsToVote = function(turnId){
      var deferred = $q.defer();

      var timeoutPromise = $timeout(function(){
        deferred.reject("Timed out");
      },10000);

      var idFacebook = window.localStorage["idFacebook"];
      $http.post(env.api+'/turn/'+turnId+'/getFriendsToVote',{"idFacebook":idFacebook})
          .success(function (response) {
            $timeout.cancel(timeoutPromise);
            deferred.resolve(response);
          })
          .error(function (data, status, headers, config) {
            $timeout.cancel(timeoutPromise);
            deferred.reject('Error occured');
          });

      return deferred.promise;
    }

    turns.createTurn = function(idAdmin,idGround,name,phone,from,to,idsFb){
      var deviceId = window.localStorage["deviceId"];
      var deferred = $q.defer();
      $http.post(env.api+'/turn/client/'+idAdmin,{
        "ground":idGround,
        "deviceId":deviceId,
        "name":name,
        "phone":phone,
        "date":{
          "from":from,
          "to":to
        },
        "idsFb":idsFb
      })
          .success(function (response) {
            deferred.resolve(response);
          })
          .error(function (data, status, headers, config) {
            deferred.reject('Error occured');
          });

      return deferred.promise;
    }

    turns.getTurn = function(idTurn){
      var deferred = $q.defer();

      var timeoutPromise = $timeout(function() {
        deferred.reject("Timed out");
      }, 10000);


      var deviceId = window.localStorage["deviceId"];
      var idFacebook = window.localStorage["idFacebook"];
      $http.post(env.api+'/turn/'+idTurn+"/info",{"deviceId":deviceId,"fbLogin":idFacebook})
          .success(function (response) {
            $timeout.cancel(timeoutPromise);
            deferred.resolve(response);
          })
          .error(function (data, status, headers, config) {
            $timeout.cancel(timeoutPromise);
            deferred.reject('Error occured');
          });

      return deferred.promise;
    }

    turns.checkTurns = function(idAdmin,date,hour){

      var deviceId = localStorage["deviceId"];
      var day = date.split("/")[0];
      var month = date.split("/")[1];
      var year = date.split("/")[2];
      var newDate = new Date(year,month-1,day,hour,0,0,0);

      var deferred = $q.defer();
      $http.post(env.api+'/turn/'+idAdmin+"/check",{
        "date":newDate,
        "deviceId":deviceId
      })
          .success(function (response) {
            deferred.resolve(response);
          })
          .error(function (data, status, headers, config) {
            deferred.reject('Error occured');
          });

      return deferred.promise;
    }

    turns.removeTurn = function(idAdmin,idTurn){
      var deferred = $q.defer();
      var deviceId = window.localStorage["deviceId"];
      var fbLogin = window.localStorage["idFacebook"];

      var timeoutPromise = $timeout(function() {
        deferred.reject("Timed out");
      }, 10000);

      $http.post(env.api+'/turn/'+idAdmin+"/removeTurnFromClient",{
        "turnId":idTurn,
        "deviceId":deviceId,
        "fbLogin":fbLogin
      })
          .success(function (response) {
            $timeout.cancel(timeoutPromise);
            deferred.resolve(response);
          })
          .error(function (data, status, headers, config) {
            $timeout.cancel(timeoutPromise);
            deferred.reject('Error occured');
          });

      return deferred.promise;
    }

    turns.getLocation = function(idTurn){
      var deferred = $q.defer();
      $http.post(env.api+'/turn/getLocation/'+idTurn,{}).success(function(response){
        deferred.resolve(response);
      }).error(function (data, status, headers, config){
        deferred.reject("Error");
      });
      return deferred.promise;
    }

    turns.getChecked = function(idTurn){
      var deferred = $q.defer();
      $http.post(env.api+'/turn/invited/'+idTurn,{}).success(function(response){
        deferred.resolve(response);
      }).error(function (data, status, headers, config){
        deferred.reject("Error");
      });
      return deferred.promise;
    }

    turns.acceptTurn = function(idTurn){

      var deviceId = window.localStorage["deviceId"];
      var idFacebook = window.localStorage["idFacebook"];
      var name = window.localStorage["name"];

      var deferred = $q.defer();
      var timeoutPromise = $timeout(function() {
        deferred.reject("Timed out");
      }, 10000);
      $http.post(env.api+'/turn/acceptTurn/'+idTurn,
          {
            "deviceId":deviceId,
            "name":name,
            "fbLogin":idFacebook
          }
      )
          .success(function(response){
            $timeout.cancel(timeoutPromise);
            deferred.resolve(response);
          }).error(function(data,status,header,config){
            $timeout.cancel(timeoutPromise);
            deferred.reject("Error");
          });
      return deferred.promise;
    }

    turns.cancelTurn = function(idTurn){

      var deviceId = window.localStorage["deviceId"];
      var idFacebook = window.localStorage["idFacebook"];
      var name = window.localStorage["name"];

      var deferred = $q.defer();
      var timeoutPromise = $timeout(function() {
        deferred.reject("Timed out");
      }, 10000);
      $http.post(env.api+'/turn/cancelTurn/'+idTurn,
          {
            "deviceId":deviceId,
            "name":name,
            "fbLogin":idFacebook
          }
      )
          .success(function(response){
            $timeout.cancel(timeoutPromise);
            deferred.resolve(response);
          }).error(function(data,status,header,config){
            $timeout.cancel(timeoutPromise);
            deferred.reject("Error");
          });
      return deferred.promise;
    }
    turns.acceptCancelTurn = function(idTurn,accept){
      var deviceId = window.localStorage["deviceId"];
      var deferred = $q.defer();
      $http.post(env.api+'/turn/acceptCancel/'+idTurn,
          {
            "deviceId":deviceId,
            "accept":accept
          }
      )
          .success(function(response){
            deferred.resolve(response);
          }).error(function(data,status,header,config){
            deferred.reject("Error");
          });
      return deferred.promise;
    }

    turns.getDataInvited = function(idTurn){
      var deviceId = window.localStorage["deviceId"];
      var deferred = $q.defer();

      var timeoutPromise = $timeout(function() {
        deferred.reject("Timed out");
      }, 10000);

      $http.post(env.api+'/turn/'+idTurn+'/state',
          {
            "deviceId":deviceId
          }
      )
          .success(function(response){
            $timeout.cancel(timeoutPromise);
            deferred.resolve(response);
          }).error(function(data,status,header,config){
            $timeout.cancel(timeoutPromise);
            deferred.reject("Error");
          });
      return deferred.promise;
    }

    turns.addFriends = function(idTurn,idsFb){
      var deviceId = window.localStorage["deviceId"];
      var name = window.localStorage["name"];
      var deferred = $q.defer();
      var timeoutPromise = $timeout(function() {
        deferred.reject("Timed out");
      }, 10000);
      $http.post(env.api+'/turn/addFriends/'+idTurn,{"idsFb":idsFb,"name":name})
          .success(function(response){
            $timeout.cancel(timeoutPromise);
            deferred.resolve(response);
          }).error(function(data,status,header,config){
            $timeout.cancel(timeoutPromise);
            deferred.reject("Error");
          });
      return deferred.promise;
    }

    turns.removeInvited = function(idTurn,deviceId,fbLogin){
      var deferred = $q.defer();
      var timeoutPromise = $timeout(function() {
        deferred.reject("Timed out");
      }, 10000);
      
      $http.post(env.api+'/turn/removeInvited/'+idTurn,{"deviceId":deviceId,"fbLogin":fbLogin})
          .success(function(response){
            $timeout.cancel(timeoutPromise);
            deferred.resolve(response);
          }).error(function(data,status,header,config){
            $timeout.cancel(timeoutPromise);
            deferred.reject("Error");
          });
      return deferred.promise;
    }

    turns.createHeaderTurn = function(idAdmin,idGround,name,phone,from,to){
      var deferred = $q.defer();
      var deviceId = window.localStorage["deviceId"];

      var timeoutPromise = $timeout(function() {
        deferred.reject("Timed out");
      }, 10000);

      $http.post(env.api+'/turn/createHeaderTurn/'+idAdmin,{
        "ground":idGround,
        "deviceId":deviceId,
        "name":name,
        "phone":phone,
        "date":{
          "from":from,
          "to":to
        }
      })
          .success(function(response){
            $timeout.cancel(timeoutPromise);
            deferred.resolve(response);
          })
          .error(function(data,status,header,config){
            $timeout.cancel(timeoutPromise);
            deferred.reject("Error");
          });
      return deferred.promise;
    }
    turns.createCompleteTurn = function(idTurn,idsFb){
      var deviceId = window.localStorage["deviceId"];
      var deferred = $q.defer();

      var timeoutPromise = $timeout(function() {
        deferred.reject("Timed out");
      }, 10000);

      $http.post(env.api+'/turn/createCompleteTurn/'+idTurn,{
        "idsFb":idsFb,
        "deviceId":deviceId
      })
          .success(function(response){
            $timeout.cancel(timeoutPromise);
            deferred.resolve(response);
          })
          .error(function(data,status,header,config){
            $timeout.cancel(timeoutPromise);
            deferred.reject("Error");
          });
      return deferred.promise;
    }

    return turns;
  }])