services.factory('AdminSrv', [
  '$q',
  '$http',
  'env',
  function($q,$http,env) {

    var admin = {};

    admin.getAdmin = function(idAdmin){
      var deferred = $q.defer();
      $http.get(env.api+'/admin/'+idAdmin,{})
          .success(function (response) {
            deferred.resolve(response);
          })
          .error(function (data, status, headers, config) {
            deferred.reject('Error occured');
          });

      return deferred.promise;
    };

    return admin;
  }]);