services.factory('NotificationSvc', [
  '$q',
  '$http',
  'env',
  '$timeout',
  function($q,$http,env,$timeout) {
    var notifications = {};
    notifications.allNotifications = [{
      "detail":"Pepe Armando Rodriguez te ha invitado a su partido",
      "date":"Hace 30 minutos",
      "invitation":true,
      "icon":"icons-invitar.png",
      "readed":true
    }, {
      "detail":"Aceptaste la invitación de CarlitoXMDZ",
      "date":"Hace 3 dias",
      "invitation":false,
      "icon":"icons-invitar.png",
      "readed":false
    }, {
      "detail":"Roberto CL te ha puntuado :(",
      "date":"20 de Julio",
      "invitation":false,
      "icon":"icon-puntuar.png",
      "readed":true
    }];

    notifications.getAllNotifications = function(deviceId,skip,limit){
      // return notifications.allNotifications;
      var deferred = $q.defer();

      var timeoutPromise = $timeout(function(){
        deferred.reject("Timed out")
      }, 10000);

      var idFacebook = window.localStorage["idFacebook"];
      $http.post(env.api+'/user/'+deviceId+"/notifications_v2",{"skip":skip,"limit":limit,"idFacebook":idFacebook})
          .success(function(response){
            $timeout.cancel(timeoutPromise);
            deferred.resolve(response);
          })
          .error(function(data,status,headers,config){
            $timeout.cancel(timeoutPromise);
            deferred.reject("Error");
          });

      return deferred.promise;

    };

    notifications.getAllReservations = function(deviceId){

      var deferred = $q.defer();

      var timeoutPromise = $timeout(function() {
        deferred.reject("Timed out");
      }, 10000);

      var fbLogin = localStorage["idFacebook"];
      $http.post(env.api+'/user/'+deviceId+"/reservations",{fbLogin:fbLogin})
          .success(function (response) {

            $timeout.cancel(timeoutPromise);
            deferred.resolve(response);
          })
          .error(function (data, status, headers, config) {
            $timeout.cancel(timeoutPromise);
            deferred.reject('Error occured');
          });

      return deferred.promise;
    };

    notifications.readNotification = function(notificationId){
      var deferred = $q.defer();

      $http.post(env.api+'/user/readNotification/'+notificationId,{})
          .success(function(response){
            deferred.resolve(response);
          })
          .error(function(data,status,headers,config){
            deferred.reject("Error");
          });

      return deferred.promise;
    };

    notifications.deleteNotification = function(notificationId){
      var deferred = $q.defer();
      var deviceId = window.localStorage["deviceId"];
      $http.put(env.api+'/user/'+deviceId+'/notifications/'+notificationId,{})
          .success(function(response){
            deferred.resolve(response);
          })
          .error(function(data,status,headers,config){
            deferred.reject("Error");
          });

      return deferred.promise;
    };

    return notifications;

  }]);
