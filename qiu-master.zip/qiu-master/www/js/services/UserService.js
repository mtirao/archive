services.factory('UserSvc',[
  '$q',
  '$http',
  'env',
  '$timeout',
  function($q,$http,env,$timeout) {

    var user = {};

    user.data = {
      "name" : window.localStorage["name"],
      // "image" : "img/face_example.jpeg",
      "image" : "http://graph.facebook.com/"+window.localStorage["idFacebook"]+"/picture?width=300&height=300",
      "rate" : window.localStorage["rate"],
      "votes" : window.localStorage["votes"],
      "phone" : window.localStorage["phone"],
      "email" : window.localStorage["email"],
      "address" : "Agustin Alvarez 456, Maipu, Mendoza",
    };

    user.getUser = function(){
      return user.data;
    };

    user.getLeaderboardData = function(){

      var deferred = $q.defer();
      var deviceId = window.localStorage["deviceId"];

      var timeoutPromise = $timeout(function() {
        deferred.reject("Timed out");
      }, 10000);

      $http.post(env.api+'/user/'+deviceId+"/getLeaderboardData",{})
          .success(function (response) {
            $timeout.cancel(timeoutPromise);
            deferred.resolve(response);
          })
          .error(function (data, status, headers, config) {
            $timeout.cancel(timeoutPromise);
            deferred.reject('Error occured');
          });

      return deferred.promise;
    }

    user.checkTurnsByDate = function(date){

      var deferred = $q.defer();
      var deviceId = window.localStorage["deviceId"];

      var timeoutPromise = $timeout(function() {
        deferred.reject("Timed out");
      }, 10000);

      $http.post(env.api+'/user/'+deviceId+"/check",{
        "date":date,
        "fbLogin":window.localStorage["idFacebook"]
      })
          .success(function (response) {
            $timeout.cancel(timeoutPromise);
            deferred.resolve(response);
          })
          .error(function (data, status, headers, config) {
            $timeout.cancel(timeoutPromise);
            deferred.reject('Error occured');
          });

      return deferred.promise;
    };

    user.checkIfExists = function(friends){
      var deferred = $q.defer();
      $http.post(env.api+"/user/checkIfExists",{"friends":friends})
          .success(function(response){
            deferred.resolve(response);
          }).error(function(data, status, headers, config){
            deferred.reject("Error");
          });
      return deferred.promise;
    }
    user.savePhone = function(phone){
      var deviceId = window.localStorage["deviceId"];
      var deferred = $q.defer();
      $http.post(env.api+"/user/"+deviceId+"/savePhone",{"phone":phone})
          .success(function(response){
            deferred.resolve(response);
          }).error(function(data, status, headers, config){
            deferred.reject("Error");
          });
      return deferred.promise;
    }
    user.checkExternalInvitation = function(){
      var deviceId = window.localStorage["deviceId"];
      var phone = window.localStorage["phone"];
      var name = window.localStorage["name"];
      var fbLogin = window.localStorage["idFacebook"];
      var deferred = $q.defer();
      $http.post(env.api+"/user/"+deviceId+"/checkExternalInvitation",{
        "phone":phone,
        "name":name,
        "fbLogin":fbLogin
      })
          .success(function(response){
            deferred.resolve(response);
          }).error(function(data, status, headers, config){
            deferred.reject("Error");
          });
      return deferred.promise;
    }

    return user;
  }])
