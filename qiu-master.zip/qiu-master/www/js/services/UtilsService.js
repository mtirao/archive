services.factory('UtilsSrv',[
  '$timeout',
  '$ionicPopup',
  '$ionicLoading',
  function($timeout,$ionicPopup,$ionicLoading) {
    var util = {};
    util.showPopup = function(message,time){
      $ionicLoading.show({template:message});
      $timeout(function(){
        $ionicLoading.hide();
      },time);
    };
    return util;

  }]);