var Qiu = angular.module('Qiu', [
  'ionic',
  'Qiu.controllers',
  'Qiu.services',
  'Qiu.directives',
  'Qiu.environment',
  'ngCordova'
])

    .run([
      '$ionicPlatform',
      '$rootScope',
      '$location',
      '$state',
      '$ionicHistory',
      '$cordovaDialogs',
      'PushSvc',
      '$cordovaNetwork',
      'AnalyticsSrv',
      '$ionicPopup',
      'FacebookService',
      'AccessSvc',
      function($ionicPlatform,$rootScope,$location,$state,$ionicHistory,$cordovaDialogs,PushSvc,$cordovaNetwork,AnalyticsSrv,$ionicPopup,FacebookService,AccessSvc) {
        $ionicPlatform.ready(function() {

          $rootScope.enableMenu = true;
          $rootScope.connection = {};
          $rootScope.connection.online = true;

          $rootScope.newNotifications = 0;


          if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
            cordova.plugins.Keyboard.hideKeyboardAccessoryBar(false);
            cordova.plugins.Keyboard.disableScroll(true);
          }
          if (window.StatusBar) {
            // org.apache.cordova.statusbar required
            StatusBar.styleLightContent();
          }

          /**
           * Flag to know if the google map api is loaded
           * @property mapLoad
           * @type {boolean}
           */
          var mapLoad = false;

          /**
           * This will happen when the user is online
           * @method onOnline
           */
          function onOnline() {
            if(mapLoad)return;
            loadMapScript();
          }

          /**
           * This method is executed when the js of google map is loaded
           * @method mapLoaded
           */
          function mapLoaded(){
            mapLoad = true;
          }

          function isLoaded(){
            return mapLoad;
          }
          window.mapLoaded = mapLoaded;
          window.isLoaded = isLoaded;

          /**
           * This load the javascript of google maps asyncrounsly in order to not delay the init charge.
           * @method loadMapScript
           */
          function loadMapScript() {
            
              var script = document.createElement('script');
              script.className = 'gm_script';
              script.type = 'text/javascript';
              script.src = 'https://maps.googleapis.com/maps/api/js?key=AIzaSyB16sGmIekuGIvYOfNoW9T44377IU2d2Es&sensor=true&signed_in=true&callback=mapLoaded&signed_in=false';
              document.body.appendChild(script);
            
          }
          window.loadMapScript = loadMapScript;

          AnalyticsSrv.startTrackerWithId("UA-70465373-2");

          if(window.localStorage["deviceId"]){
            AccessSvc.logDevice(function(){
              PushSvc.register().then(function(data){},function(err){});
            });
          }

          FacebookService.actualizeLeaderboardFriends().then(function(data){});

          /*ANTES CARGABA EL MAPA EN run(), ahora lo hace directamente
           desde el controlador del mapa*/
          // onOnline();
          /*************************/

        });


        if(window.localStorage["tokenQiu"] == undefined){
          window.localStorage["tokenQiu"] = "";
        }
        $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
          if(window.localStorage["tokenQiu"] !== "") {

          }else{
            if(toState.name == 'tab.leaderboard'){
              $location.path('/login');
            }
          }
        });

        // listen for Online event
        $rootScope.$on('$cordovaNetwork:online', function(event, networkState){
          if(!$rootScope.connection){
            $rootScope.connection = {};
          }
          $rootScope.connection.online = true;
        });

        // listen for Offline event
        $rootScope.$on('$cordovaNetwork:offline', function(event, networkState){
          if(!$rootScope.connection){
            $rootScope.connection = {};
          }
          $rootScope.connection.online = false;
        });


        //Solo para Android: Modifica el comportamiento del boton Back
        if (ionic.Platform.isAndroid()) {
          $ionicPlatform.registerBackButtonAction(function () {
            var currentState = $state.current.name;
            if (currentState == 'tab.leaderboard' || currentState == 'tab.reservations' || currentState == 'tab.activities' || currentState == 'login') {
              $rootScope.toOriginalPointFromRoot();
              var confirmPopup = $ionicPopup.confirm({
                title: 'Salir',
                template: '¿Desea salir de la aplicaci\u00f3n?'
              });
              confirmPopup.then(function(res) {
                if(res) {
                  ionic.Platform.exitApp();
                }
              });
            }else if(currentState == 'tab.reservation_cardRes'){
              $state.go('tab.reservations');
            }else{
              $ionicHistory.goBack();
            }
          }, 100);
        }
      }])

    .config([
      '$stateProvider',
      '$urlRouterProvider',
      '$ionicConfigProvider',
      function($stateProvider, $urlRouterProvider,$ionicConfigProvider) {

        $ionicConfigProvider.tabs.position("bottom");
        $ionicConfigProvider.views.swipeBackEnabled(false);

        $stateProvider

            .state('login', {
              url: '/login',
              templateUrl: 'templates/login.html',
              controller: "LoginCtrl",
              cache: false
            })
            .state('tab', {
              url: '/tab',
              abstract: true,
              templateUrl: 'templates/tabs.html',
              controller: "TabsCtrl"
            })
            .state('tab.leaderboard', {
              url: '/leaderboard',
              views: {
                'tab-leaderboard': {
                  templateUrl: 'templates/leaderboard.html',
                  controller: 'LeaderboardCtrl'
                }
              }
            })
            .state('tab.friends', {
              url: '/friends',
              views: {
                'tab-leaderboard': {
                  templateUrl: 'templates/friends.html',
                  controller: 'FriendsCtrl'
                }
              }
            })

            .state('tab.reservations', {
              url: '/reservations',
              views: {
                'tab-reservations': {
                  templateUrl: 'templates/reservations.html',
                  controller: 'ReservationsCtrl'
                }
              }
            })
            .state('tab.invitefriends', {
              url: '/invitefriends',
              views: {
                'tab-reservations': {
                  templateUrl: 'templates/invitefriends.html',
                  controller: 'InviteFriendsCtrl'
                }
              },
              params: {
                'idAdmin':null,
                'idGround':null,
                'name':null,
                'phone':null,
                'from':null,
                'to':null,
                'typeId':null,
                'idTurn':null
              },
              cache: false
            })
            .state('tab.reinvitefriends', {
              url: '/reinvitefriends/:idTurn',
              views: {
                'tab-reservations': {
                  templateUrl: 'templates/reinvitefriends.html',
                  controller: 'ReinviteFriendsCtrl'
                }
              }
            })
            .state('tab.invitefriends_act', {
              url: '/invitefriends',
              views: {
                'tab-activities': {
                  templateUrl: 'templates/invitefriends.html',
                  controller: 'InviteFriendsCtrl'
                }
              },
              params: {
                'idAdmin':null,
                'idGround':null,
                'name':null,
                'phone':null,
                'from':null,
                'to':null,
                'typeId':null,
                'idTurn':null
              }
            })
            .state('tab.reinvitefriends_act', {
              url: '/reinvitefriends/:idTurn',
              views: {
                'tab-activities': {
                  templateUrl: 'templates/reinvitefriends.html',
                  controller: 'ReinviteFriendsCtrl'
                }
              }
            })
            .state('tab.confirmation', {
              url: '/confirmation',
              views: {
                'tab-reservations': {
                  templateUrl: 'templates/confirmation.html',
                  controller: 'ConfirmationCtrl'
                }
              },
              params: {
                'idAdmin':null,
                'idGround':null,
                'name':null,
                'from':null,
                'to':null,
                'typeId':null
              }
            })
            .state('tab.reservation_cardRes', {
              url: '/reservation_card/:turnId',
              views: {
                'tab-reservations':{
                  templateUrl: 'templates/reservation_card.html',
                  controller: 'ReservationCardCtrl'
                }
              },
              cache:false
            })
            .state('tab.reservation_cardAct', {
              url: '/reservation_card/:turnId',
              views: {
                'tab-activities':{
                  templateUrl: 'templates/reservation_card.html',
                  controller: 'ReservationCardCtrl'
                }
              },
              params: {
                'type':null
              }
            })
            .state('tab.stateTurn', {
              url: '/reservation_card/:turnId/state',
              views: {
                'tab-reservations':{
                  templateUrl: 'templates/state_turn.html',
                  controller: 'StateTurnCtrl'
                }
              },
              cache: false
            })
            .state('tab.stateTurn_act', {
              url: '/reservation_card/:turnId/state',
              views: {
                'tab-activities':{
                  templateUrl: 'templates/state_turn.html',
                  controller: 'StateTurnCtrl'
                }
              },
              params: {
                'type':null
              },
              cache: false
            })
            .state('tab.activities', {
              url: '/activities',
              views: {
                'tab-activities': {
                  templateUrl: 'templates/activities.html',
                  controller: 'NotificationCtrl'
                }
              }
            })
            .state('tab.info_reservations', {
              url: '/info_reservations',
              views: {
                'tab-activities': {
                  templateUrl: 'templates/info_reservations.html',
                  controller: 'ActivitiesCtrl'
                }
              }
            })
            .state('tab.votation-list', {
              url: '/votation-list',
              views: {
                'tab-activities':{
                  templateUrl: 'templates/votation-list.html',
                  controller: 'VotationListCtrl'
                }
              }
            })
            .state('tab.votation', {
              url: '/votation-list/:idTurn',
              views: {
                'tab-activities':{
                  templateUrl: 'templates/votation.html',
                  controller: 'VotationCtrl'
                }
              },
              cache: false
            })
            .state('tab.invitation', {
              url: '/invitation/:idTurn',
              views: {
                'tab-activities':{
                  templateUrl: 'templates/invitation.html',
                  controller: 'InvitationCtrl'
                }
              },
              params:{
                "idNotification":null
              }
            })
            .state('tab.cancellation', {
              url: '/cancellation/:idNotification',
              views: {
                'tab-activities':{
                  templateUrl: 'templates/cancellation.html',
                  controller: 'CancellationCtrl'
                }
              }
            })
            .state('tab.uninvited', {
              url: '/cancellation/:idNotification',
              views: {
                'tab-activities':{
                  templateUrl: 'templates/uninvited.html',
                  controller: 'UninvitedCtrl'
                }
              }
            })
        ;
        $urlRouterProvider.otherwise('/tab/leaderboard');

      }]);

var controllers = angular.module('Qiu.controllers',[]);
var services = angular.module('Qiu.services',[]);
var directives = angular.module('Qiu.directives',[]);
var environment = angular.module('Qiu.environment',[]);