environment.constant('env', {
    "url": "http://qiupro.com",
    "api": "http://qiupro.com",
    //'api':'http://qiupro.com/api',
    'img':'http://qiupro.com/',
    "user": "qiu",
    "pass": "2016$",
    "appID":"707644746035589"
});

Qiu.config([
    '$ionicConfigProvider',
    '$httpProvider',
    function($ionicConfigProvider,$httpProvider) {
        $httpProvider.interceptors.push('HttpInterceptorSvc');
    }]);