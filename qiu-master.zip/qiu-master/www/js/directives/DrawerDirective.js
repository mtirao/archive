directives.directive('drawer', [
  '$rootScope',
  '$ionicGesture',
  function($rootScope, $ionicGesture) {
    return {
      restrict: 'E',
      controller: 'drawerCtrl',
      templateUrl: 'templates/directives/drawer.html',
      link: [
        '$scope',
        '$element',
        '$attr',
        'ctrl',
        function($scope, $element, $attr, ctrl) {
        }]
    }
  }]);

controllers.controller('drawerCtrl', [
  '$scope',
  '$element',
  '$attrs',
  '$ionicGesture',
  '$document',
  '$rootScope',
  '$cordovaDatePicker',
  '$window',
  '$cordovaToast',
  'DataSvc',
  'UserSvc',
  '$ionicLoading',
  'UtilsSrv',
  '$timeout',
  function($scope,$element, $attrs, $ionicGesture, $document,$rootScope,$cordovaDatePicker,$window,$cordovaToast,DataSvc,UserSvc,$ionicLoading,UtilsSrv,$timeout) {

    var typesLoaded = false;
    var loadingMap = true;
    $scope.$on('$ionicView.enter', function() {
      tryToLoad();
    });



    var el = $element[0];

    /* height of filter (100% of the screen)*/
    var h = el.offsetHeight;
    /* height of the bottom bar with the arrow (5% of the filter)*/
    var bottomBarHeight = h * 0.05;

    /*Start point in pixels of filter*/
    var initialTop = el.clientHeight*-0.4;

    /*y when filter is active*/
    var yActive = initialTop;

    // var input_hack = $element[0].getElementsByClassName("input_hack")[0];

    /* get .slides_container div*/
    var slidesSports = $element[0].getElementsByClassName("slides_container")[0];

    if($window.innerWidth < 600){
      var boxW = 80;
    }else{
      var boxW = 100;
    }

    var widthSlidesSports;

    /* Start position of .slides_container*/
    var lastXSlide = 0;
    /* Left limit when you drag to the left .slides_containter*/
    var limitXLeft = $window.innerWidth - slidesSports.clientWidth;

    var enableSlideScroll = true;

    /*active: when filter is expanded*/
    var active = true;

    var disableDrag = false;

    var draggingPanel = false;

    $scope.data = {};
    $scope.data.recurrent = false;

    $scope.hours = [
      {id: '8', label: '08:00'},
      {id: '9', label: '09:00'},
      {id: '10', label: '10:00'},
      {id: '11', label: '11:00'},
      {id: '12', label: '12:00'},
      {id: '13', label: '13:00'},
      {id: '14', label: '14:00'},
      {id: '15', label: '15:00'},
      {id: '16', label: '16:00'},
      {id: '17', label: '17:00'},
      {id: '18', label: '18:00'},
      {id: '19', label: '19:00'},
      {id: '20', label: '20:00'},
      {id: '21', label: '21:00'},
      {id: '22', label: '22:00'},
      {id: '23', label: '23:00'}
    ];

    $scope.sports = [];
    var timeout = null;

    function tryToLoad(){
      $ionicLoading.show({
        template:"Cargando mapa..."
      });
      if(!typesLoaded){
        getTypes();
      }
      if(typeof google !== 'undefined'){
        $ionicLoading.hide();
      }else{
        timeout = $timeout(function(){
          loadingMap = false;
          $ionicLoading.hide();
          UtilsSrv.showPopup("Hubo un error al cargar el mapa, por favor verifique su conexion a internet",2000);
        }, 10000);
        loadMap();
      }
    }


    function loadMap(){
      if(!loadingMap){
        loadingMap = true;
        return;
      }
      var gm_script = document.getElementsByClassName("gm_script");
      for (var i = 0; i < gm_script.length; i++) {
        gm_script[i].remove();
      };
      // window.loadMapScript();
      var script = document.createElement('script');
      script.className = 'gm_script';
      script.type = 'text/javascript';
      script.src = 'https://maps.googleapis.com/maps/api/js?key=AIzaSyB16sGmIekuGIvYOfNoW9T44377IU2d2Es&sensor=true&signed_in=true&callback=mapLoaded&signed_in=false';
      script.onload = function(){
        $timeout.cancel(timeout);
        loadingMap = false;
        $rootScope.resizeMap();
        $ionicLoading.hide();
      }
      script.onerror = function(err){
        loadMap();
      }
      document.body.appendChild(script);
      
    }

    function getTypes(){

      DataSvc.getTypes().then(function(data){
        if(data.code !== 200){
          // handle error
          return;
        }
        typesLoaded = true;
        var types = data.result;

        $scope.sports = [];

        for (var i = 0; i < types.length; i++) {

          $scope.sports.push({
            "id":types[i]._id,
            "name":types[i].name,
            "active": (i == 0 ? true : false),
            "icon":"img/icons-pelota-futbol.png"
          });

        };

        setWidthSlidesSports(boxW,types.length);

      },function(err){
        $timeout.cancel(timeout);
        UtilsSrv.showPopup("Hubo un error al cargar los tipos de canchas",2000);
      });
    }

    function checkWidthSlide(){
      if($window.innerWidth > widthSlidesSports){
        enableSlideScroll = false;
        slidesSports.className += " center";
      }
    }

    function setWidthSlidesSports(boxW,length){
      var total = 15 + (boxW+15)*length;
      widthSlidesSports = total;
      limitXLeft = $window.innerWidth - widthSlidesSports;
      slidesSports.style.width = total+"px";
      checkWidthSlide();
    }

    var getActiveSportId = function(){
      for (var i = 0; i < $scope.sports.length; i++) {
        if($scope.sports[i].active === true){
          return $scope.sports[i].id;
        }
      };
    }

    function isDateAndHour(){
      var date = $scope.data.day;
      var hour = $scope.data.hour;

      if(!date || !hour){
        return false;
      }else{
        return true;
      }

    }

    var verifyDateAndHour = function(){

      var date = $scope.data.day;
      var hour = $scope.data.hour;

      // if(!date || !hour){
      //   $cordovaToast.show('Debe colocar una fecha y hora', 'short', 'center');
      //   toActivePoint();
      //   return;
      // }

      if(!isDateAndHour()){

        // $cordovaToast.show('Debe colocar una fecha y hora', 'short', 'center');
        UtilsSrv.showPopup("Debe colocar una fecha y hora",1000);

        toActivePoint();
        return;
      }

      var day = date.split("/")[0];
      var month = date.split("/")[1];
      var year = date.split("/")[2];
      var date = new Date(year,month-1,day,hour,0,0,0);

      $ionicLoading.show({
        template: "Buscando turnos..."
      });

      UserSvc.checkTurnsByDate(date).then(function(data){
        $ionicLoading.hide();
        if(data.code !== 200){
          // handle error
          return;
        }

        var groundReserved = data.result.groundsReserved;
        if(groundReserved > 0){
          // $cordovaToast.show('Ya tiene un turno para esa fecha y hora', 'short', 'center');
          UtilsSrv.showPopup("Ya tiene un turno para esa fecha y hora",1000);
          toActivePoint();
          return;
        }

        toOriginalPoint();
        active = false;

      },function(error){
        $ionicLoading.hide();
        toActivePoint();
        // $cordovaToast.show('Un error ha ocurrido no pudo traer las canchas', 'short', 'center');
        UtilsSrv.showPopup("Un error ha ocurrido no pudo traer las canchas",1000);
      });
    };

    // var focusHackInput = function(){
    //   if($rootScope.isAndroid44){
    //     input_hack.focus();
    //   }
    // }

    var removeActiveButtons = function(){
      for (var i = 0; i < $scope.sports.length; i++) {
        $scope.sports[i].active = false;
      };
    };

    var activeButton = function(id){
      for (var i = 0; i < $scope.sports.length; i++) {
        if($scope.sports[i].id == id){
          $scope.sports[i].active = true;
          break;
        }
      };
    };

    var moveSlide = function(x,y,z){
      ionic.requestAnimationFrame(function() {
        slidesSports.style.transform = slidesSports.style.webkitTransform = 'translate3d('+x+', '+y+', '+z+')';
      });
    };

    var moveFilter = function(x,y,z){
      ionic.requestAnimationFrame(function() {
        el.style.transform = el.style.webkitTransform = 'translate3d('+x+', '+y+', '+z+')';
      });
    };

    var toOriginalPoint = function(){
      var y = -h+bottomBarHeight;
      moveFilter(0,y+"px",0);
      // focusHackInput();
      $scope.icon = "img/arrow-down.png";
      initialTop = (-h+bottomBarHeight);
      var day = $scope.data.day;
      var hour = $scope.data.hour;
      $rootScope.setMapDraggable(true);
      var typeId = getActiveSportId();
      draggingPanel = false;
      $rootScope.findTurnsByDateAndHour(day,hour,typeId);
    };

    var toActivePoint = function(){
      moveFilter(0,"-40%",0);
      $rootScope.setMapDraggable(false);
      // focusHackInput();
      initialTop = el.clientHeight*-0.4;

      $scope.icon = "img/arrow-up.png";
      draggingPanel = false;
    };

    var enableAnimation = function() {
      $element.addClass('animate');
    };

    var disableAnimation = function() {
      $element.removeClass('animate');
    };

    $scope.onDrag = function(e) {
      if(!disableDrag){
        disableAnimation();
        var newY = initialTop + e.gesture.deltaY;
        if(newY < yActive){
          draggingPanel = true;
          moveFilter(0,newY+"px",0);
        }
      }
    }

    function check(deltaY){
      if(!active){
        enableAnimation();
        if(deltaY >= 50){
          toActivePoint();
          active = true;
        }else{
          toOriginalPoint();
          verifyDateAndHour();
        }
      }else{
        if(deltaY < -50){
          toOriginalPoint();
          verifyDateAndHour();
        }else{
          toActivePoint();
          active = true;
        }
      }
    }

    $scope.checkData = function(){
      if(isDateAndHour()){

        if(typeof google == 'undefined'){
          // $cordovaToast.show('No se ha cargado correctamente el mapa', 'short', 'center');
          UtilsSrv.showPopup("No se ha cargado correctamente el mapa",1000);
          return;
        }

        enableAnimation();
        verifyDateAndHour();

      }
    }

    $scope.onRelease = function(e) {
      if(!draggingPanel){
        return;
      }

      if(typeof google == 'undefined'){
        //$cordovaToast.show("No se ha cargado correctamente el mapa", 'short', 'center');
        UtilsSrv.showPopup("No se ha cargado correctamente el mapa",1000);
        toActivePoint();
        return;

      }

      if(!isDateAndHour()){
        // $cordovaToast.show('Debe colocar una fecha y hora', 'short', 'center');
        UtilsSrv.showPopup("Debe colocar una fecha y hora",1000);
        toActivePoint();
        return;
      }

      var deltaY  = e.gesture.deltaY;

      check(deltaY);

    }

    $scope.dragSlide = function(e){
      if(!enableSlideScroll){
        return;
      }
      var newX = lastXSlide + e.gesture.deltaX;
      moveSlide(newX+"px",0,0);
    }

    $scope.onReleaseSlide = function(e){

      if(!enableSlideScroll){
        return;
      }
      lastXSlide += e.gesture.deltaX;
      if(lastXSlide > 0){
        moveSlide(0,0,0);
        lastXSlide = 0;
      }else if(lastXSlide < limitXLeft){
        moveSlide(limitXLeft+"px",0,0);
        lastXSlide = limitXLeft;
      }else{
        moveSlide(lastXSlide+"px",0,0);
      }
    }

    $scope.barClick = function(){

      if(typeof google == 'undefined'){
        // $cordovaToast.show('No se ha cargado correctamente el mapa', 'short', 'center');
        UtilsSrv.showPopup("No se ha cargado correctamente el mapa",1000);
        return;
      }

      enableAnimation();
      if(active){
        verifyDateAndHour();
      }else{
        toActivePoint();
        active= true;
      }
    }

    /*This is becaues I could not find a way to call a directive method from controller*/
    $rootScope.activeFromController = function(){
      toActivePoint();
    }

    $scope.selectSport = function(id){
      removeActiveButtons();
      activeButton(id);
      // focusHackInput();
    }


    $scope.getDatePicker = function(type){
      var options = {
        date: new Date(),
        mode: type, // or 'time'
        minDate: new Date(),
        allowOldDates: false,
        allowFutureDates: true,
        doneButtonLabel: 'DONE',
        doneButtonColor: '#1467EB',
        cancelButtonLabel: 'CANCEL',
        cancelButtonColor: '#000000'
      };
      document.addEventListener("deviceready", function () {

        $cordovaDatePicker.show(options).then(function(date){
          if(type == 'date'){
            var day = date.getDate();
            var month = date.getMonth() + 1;
            var year = date.getFullYear();

            $scope.data.day = day+"/"+month+"/"+year;
          }else{
            var hours = date.getHours();
            var minutes = date.getMinutes();
            $scope.data.hour = hours + ":" + minutes;
          }

        });

      }, false);
    }

    // getTypes();
    tryToLoad();

    // focusHackInput();
    toActivePoint();

  }]);