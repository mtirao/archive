directives.directive("starRating", [
	'$rootScope',
	function($rootScope) {
		return {
			restrict : "EA",
			templateUrl : "templates/directives/star-rating.html",
			scope : {
				ratingValue : "=stars",
				canvote: "=canvote"
			},
			link : 
			// [
			// 	'scope',
			// 	'elem',
			// 	'attrs',
				function(scope, elem, attrs) {

					scope.$watch('ratingValue', function(newValue, oldValue) {
						if (newValue !== oldValue) {

							for (var i = 0; i < 5; i++) {
								scope.stars[i].filled = false;
							};

							for (var i = 0; i < Math.round(newValue); i++) {
								scope.stars[i].filled = true;
							};
						}
					}, true);

					scope.dragEnd = function(event){
						$rootScope.enableMenu = true;
					};

					scope.dragStar = function(event,d){
						if (scope.canvote !== undefined && scope.canvote !== false){
							$rootScope.enableMenu = false;
							var w = elem[0].clientWidth;
							var left = elem[0].getBoundingClientRect().left;
							var leftTouch = event.gesture.center.pageX;

							var diff = leftTouch - left;
							var perc = (diff*100)/w;
							var stars = Math.ceil(perc/20);

							if(stars > 5){
								stars = 5;
							}
							if(stars < 0){
								stars = 0;
							}
							clearStars();
							for (var i = 0; i < stars; i++) {
								scope.stars[i].filled = true;
							};
							scope.ratingValue = stars;
						}
					};

					function updateStars() {
						scope.stars = [];
						for (var i = 0; i < 5; i++) {
							scope.stars.push({
								filled : i < scope.ratingValue
							});
						}
					};

					function clearStars(){
						for (var i = 0; i < scope.stars.length; i++) {
							scope.stars[i].filled = false;
						};
					};

					scope.vote = function(index){
						if (scope.canvote !== undefined && scope.canvote !== false){
							var cantStars = index+1;
							scope.ratingValue = cantStars;
							clearStars();
							for (var i = 0; i < cantStars; i++) {
								scope.stars[i].filled = true;
							};
						}
					};

					updateStars();

				}
				// ]
		};
	}])
