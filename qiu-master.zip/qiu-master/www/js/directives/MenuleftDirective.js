directives.directive('menuLeft', [
  '$rootScope',
  '$ionicGesture',
  function($rootScope, $ionicGesture) {
    return {
      restrict: 'E',
      controller: 'menuLeftCtrl',
      templateUrl: 'templates/directives/menu-left.html',
      link: [
        '$scope',
        '$element',
        '$attr',
        'ctrl',
        function($scope, $element, $attr, ctrl) {
          // $scope.openProfile = function(){
          //   ctrl.openProfile();
          // }
        }]
    }
  }]);

controllers.controller('menuLeftCtrl', [
  '$scope',
  '$state',
  '$rootScope',
  '$element',
  '$attrs',
  '$ionicGesture',
  '$document',
  '$cordovaDialogs',
  'UserSvc',
  '$cordovaPush',
  'UtilsSrv',
  '$ionicPopup',
  function($scope,$state,$rootScope,$element, $attrs, $ionicGesture, $document, $cordovaDialogs,UserSvc,$cordovaPush,UtilsSrv,$ionicPopup) {
    var el = $element[0];
    var w = el.offsetWidth;

    $scope.user = {};

    var actualW = w;
    var active = false;

    var startRange = w-w*0.15;
    var initialOnActive = w*0.05;
    var deltaToOpenClose = w*0.35;

    var toOriginalPoint = function(){
      ionic.requestAnimationFrame(function() {
        el.style.transform = el.style.webkitTransform = 'translate3d('+w+'px, 0, 0)';
      });
      actualW = w;
      active = false;
    }

    var toActivePoint = function(){
      ionic.requestAnimationFrame(function() {
        el.style.transform = el.style.webkitTransform = 'translate3d('+initialOnActive+'px, 0, 0)';
      });
      active = true;
      // focusHackInput();
      actualW = initialOnActive;
    }

    var enableAnimation = function() {
      $element.addClass('animate');
    };

    var disableAnimation = function() {
      $element.removeClass('animate');
    };

    var moveMenu = function(x){

      if(!$rootScope.enableMenu){
        return;
      }

      ionic.requestAnimationFrame(function() {
        el.style.transform = el.style.webkitTransform = 'translate3d('+x+'px, 0 , 0)';
      });
    }

    $scope.openProfile = function(){
      // focusHackInput();
      enableAnimation();
      toActivePoint();
    }

    $ionicGesture.on('dragright', function(e) {
      
      disableAnimation();
      if(active){
        var deltaX  = e.gesture.deltaX;
        var x = actualW+deltaX;
        moveMenu(x);
      }
    }, $document);
    $ionicGesture.on('dragleft', function(e) {


      disableAnimation();
      var start = e.gesture.startEvent.center.pageX;
      if(!active){

        if($state.current.name === 'tab.reservations'){
          return;
        }

        if(start > (startRange)){
          var deltaX  = e.gesture.deltaX;
          var x = actualW+deltaX;
          moveMenu(x);
        }
      }
    }, $document);
    $ionicGesture.on('dragend', function(e) {

      var start = e.gesture.startEvent.center.pageX;
      var deltaX = e.gesture.deltaX;
      enableAnimation();
      if(active){
        if(deltaX > deltaToOpenClose){
          toOriginalPoint();
        }else{
          toActivePoint();
        }

      }else{

        if($state.current.name === 'tab.reservations'){
          return;
        }
        
        if( (start > startRange) && (-deltaX > deltaToOpenClose)){
          toActivePoint();
        }else{
          toOriginalPoint();
        }
      }

    }, $document);

    $rootScope.refreshMenu = function(name,email,phone,idFacebook,rate,votes){
      $scope.user.name = name;
      $scope.user.email = email;
      $scope.user.phone = phone;
      $scope.user.rate = rate;
      $scope.user.votes = votes;
      // UserSvc.getLeaderboardData().then(function(data){
      //   if(data.code !==200){
      //     return;
      //   }

      //   $scope.user.rate = data.result.points;
      //   $scope.user.votes = data.result.votes;

      // });
      $scope.user.image = "http://graph.facebook.com/"+idFacebook+"/picture?width=300&height=300";
    }

    // focusHackInput();
    toOriginalPoint();
    $scope.user = UserSvc.getUser();

    $scope.signOut = function(){
      toOriginalPoint();
      var confirmPopup = $ionicPopup.confirm({
        title: 'Cerrar sesi\u00f3n',
        template: '¿Desea cerrar sesi\u00f3n?'
      });
      confirmPopup.then(function(res) {
        if(res) {
          facebookConnectPlugin.logout(function(){
            $cordovaPush.unregister({}).then(function(result) {
              // Success!
              window.localStorage.clear();
              $state.go("login");
            }, function(err) {
              // Error
              window.localStorage.clear();
              $state.go("login");
            });
          }, function(){

          });
        }
      });
    }

    $scope.newData = {};

    $scope.editPhone = function(){

      toOriginalPoint();

      var myPopup = $ionicPopup.show({
        template: '<span style="float:left;width: 50%;text-align: right;">+54 9 261&nbsp;&nbsp;</span><span style="float:left;width: 50%;"> <input type="phone" ng-model="newData.phone"></span>',
        title: 'Cambiar Telefono',
        subTitle: '',
        scope: $scope,
        buttons: [
          { text: 'Cancelar' },
          {
            text: '<b>Modificar</b>',
            type: 'button-positive',
            onTap: function(e) {
              if($scope.newData.phone == '' || $scope.newData.phone == undefined){
                UtilsSrv.showPopup('Debe colocar un telefono valido',1500);
              }else{
                UserSvc.savePhone($scope.newData.phone).then(function(data){
                  if(data.code !== 200){
                    UtilsSrv.showPopup('No pudo modificarse el telefono, por favor intentelo nuevamente',1500);
                    return;
                  }

                  UtilsSrv.showPopup('Se ha modificado el telefono correctamente',1500);
                  window.localStorage["phone"] = $scope.newData.phone;
                  $scope.user.phone = $scope.newData.phone;

                },function(err){
                })
              }
            }
          }
        ]
      });

    };

    $rootScope.toOriginalPointFromRoot = function(){
      toOriginalPoint();
    };

    $scope.editAddress = function(){

      toOriginalPoint();

      var myPopup = $ionicPopup.show({
        template: '<input type="text" ng-model="newData.address">',
        title: 'Cambiar Direccion',
        subTitle: 'subtitulo...',
        scope: $scope,
        buttons: [
          { text: 'Cancelar' },
          {
            text: '<b>Modificar</b>',
            type: 'button-positive',
            onTap: function(e) {
              if($scope.newData.address == '' || $scope.newData.address == undefined){
                UtilsSrv.showPopup('Debe colocar una direccion',1500);
              }
            }
          }
        ]
      });
    }
  }])

