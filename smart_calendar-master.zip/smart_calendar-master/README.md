# SmartCalendar

Application to help students and professors to manage their course. It also allow to add the notes of the exams and calculate the average
of  the notes for each semester. Is it not finish yet(some feature are not ready or not added yet), but works it  and is available on 
AppStore.
