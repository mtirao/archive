# craftbeer-app
Esta applicacion es es un proyecto de automatizacion de produccion de cerveza artensanal.
Esta app seria Frontend para que el Brewmaster pueda armar las recestas y enviarlas al servicio
que eventualmente contralara y supervisara la produccion.
Actualmente, la UI no esta completa, pero tiene la consulta los ABM de la receta, solamente por lo que es un trabajo en proceso.
En el mismo github se puede encontrar el resto de los servicio/apps del cual se compone el proyecto completo(cualquier repo que se llame 
craftbeer* forma parte de este proyecto.).



