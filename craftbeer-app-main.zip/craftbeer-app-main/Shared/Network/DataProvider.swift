//
//  DataProvider.swift
//  Craftbeer
//
//  Created by Marcos Tirao on 25/10/2020.
//

import Foundation


enum DataProvider: String {
    case server = "http://localhost:3000"
}
