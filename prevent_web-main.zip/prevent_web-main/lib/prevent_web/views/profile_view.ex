defmodule PreventWeb.ProfileView do
  use PreventWeb, :view
end
