defmodule PreventWeb.LayoutView do
  use PreventWeb, :view
end
