defmodule PreventWeb.ClinicView do
  use PreventWeb, :view
end
