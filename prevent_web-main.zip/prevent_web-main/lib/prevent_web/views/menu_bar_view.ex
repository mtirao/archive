defmodule PreventWeb.MenuBarView do
  use PreventWeb, :view

end
