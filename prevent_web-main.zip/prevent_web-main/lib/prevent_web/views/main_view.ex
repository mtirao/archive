defmodule PreventWeb.MainView do
  use PreventWeb, :view
end
