defmodule PreventWeb.CalendarView do
  use PreventWeb, :view
end
