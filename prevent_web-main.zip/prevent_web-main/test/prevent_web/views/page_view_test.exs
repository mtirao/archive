defmodule PreventWeb.PageViewTest do
  use PreventWeb.ConnCase, async: true
end
