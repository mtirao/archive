defmodule CraftbeerUiWeb.PageViewTest do
  use CraftbeerUiWeb.ConnCase, async: true
end
