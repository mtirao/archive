defmodule CraftbeerUiWeb.LayoutView do
  use CraftbeerUiWeb, :view
end
