defmodule CraftbeerUiWeb.PageView do
  use CraftbeerUiWeb, :view
end
