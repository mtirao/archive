defmodule CraftbeerFirmware do
  @moduledoc """
  Documentation for CraftbeerFirmware.
  """

  @doc """
  Hello world.

  ## Examples

      iex> CraftbeerFirmware.hello
      :world

  """
  def hello do
    :world
  end
end
