smart_bff
=====

An OTP application

Build
-----

    $ rebar3 compile
