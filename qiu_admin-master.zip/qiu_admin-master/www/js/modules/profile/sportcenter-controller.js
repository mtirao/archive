controllers.controller('SportcenterCtrl', [
  '$scope',
  '$ionicPopup',
  'ConfigSvc',
  '$window',
  '$timeout',
  'AnalyticsSvc',
  'UtilsSvc',
  'SportcenterSvc',
  function($scope, $ionicPopup, ConfigSvc, $window, $timeout,AnalyticsSvc,UtilsSvc, SportcenterSvc){

    AnalyticsSvc.trackView("Sportcenter View");

    // ==== Variables.
    // ==========================================================

    var myMap, marker, latLng;

    function initMap(){
        
        var coordinates = {coordinates: {lat: -34.6037886, lng: -58.3890462}};
        $scope.config = coordinates;

        $scope.config.coordinates.lat = -34.6037886;
        $scope.config.coordinates.lng = -58.3890462;

        var mapId = document.getElementById('mapid');
        myMap = new google.maps.Map(mapId, {
            zoom: $scope.config.zoom,
            mapTypeControl: true,
            center: new google.maps.LatLng($scope.config.coordinates.lat, $scope.config.coordinates.lng),
            mapTypeId: google.maps.MapTypeId.ROADMAP
        });
        var image = {
          url: 'img/icon-map-pin-red.png',
          // This marker is 20 pixels wide by 32 pixels high.
          size: new google.maps.Size(64, 64),
          // The origin for this image is (0, 0).
          origin: new google.maps.Point(0, 0),
          // The anchor for this image is the base of the flagpole at (0, 32).
          anchor: new google.maps.Point(32, 64)
        };

        marker = new google.maps.Marker({
            position: new google.maps.LatLng($scope.config.coordinates.lat, $scope.config.coordinates.lng),
            icon: image,
            map: myMap,
            draggable: false,
            animation: google.maps.Animation.DROP
        });

        google.maps.event.addDomListener(myMap, 'click', function(ev){
            // Stop propagation
            ev.cancelBubble = true;
            ev.stopPropagation && ev.stopPropagation();
            ev.preventDefault && ev.preventDefault();
            ev.stop();

            // Set marker and center map
            latLng = new google.maps.LatLng(ev.latLng.lat(), ev.latLng.lng());
            marker.setPosition(latLng);
            myMap.setCenter(latLng);

            return false;
        });
    }

    google.maps.event.addDomListener(window, 'load', initMap);

    /*function loadMapScript() {
        var script = document.createElement('script');
        script.className = 'gm_script';
        script.type = 'text/javascript';
        script.src = 'https://maps.googleapis.com/maps/api/js?key=AIzaSyB16sGmIekuGIvYOfNoW9T44377IU2d2Es&callback=initMap';
        document.body.appendChild(script);
    }*/

    $scope.height = parseInt($window.innerHeight * 0.28) + 'px';
    noSending();
    

    // ==== Hours.
    // ==========================================================

    $scope.hours = [];
    for(var i=10; i<=23; i++){
        if(i<10) $scope.hours.push('0' + i + ':00');
        else $scope.hours.push(i + ':00');
    }


    // ==== Info.
    // ==========================================================

    $scope.config = {};

     /* ==== Create a new field.
    ===================================================== */

    $scope.newField = function(){

        AnalyticsSvc.trackEvent("Ground","New","ShowPopup",1);
        $scope.data = {};

        var template = '<div class="mb-10"><label for="tn_name">Nombre</label><input id="tn_name" type="text" ng-model="data.name" /></div>';
        template += '<div><label for="tn_types">Tipo</label><select for="tn_types" ng-model="data.type" ng-options="obj._id as obj.name for obj in types"></select></div>';

        $ionicPopup.show({
            template: template,
            title: 'Cancha',
            subTitle: 'Crear',
            scope: $scope,
            buttons: [
                {
                    text: 'Cancelar',
                    onTap: function(e){
                        return null;
                    }
                },
                {
                    text: 'Crear',
                    type: 'button-positive',
                    onTap: function(e){
                        if(!$scope.data.name || !$scope.data.type){
                            UtilsSvc.showPopup("Completar los campos",2000);
                            e.preventDefault();
                        }
                        else{
                            return {
                                'name': $scope.data.name,
                                'type': $scope.data.type
                            };
                        }
                    }
                }
            ]
        })
        .then(function(response){
            if(response){
                FieldsSvc.insert(response.name, response.type).then(
                    function(data){
                      UtilsSvc.showPopup(data,2000);
                      AnalyticsSvc.trackEvent("Ground","Insert","Success",1);
                    },
                    function(error){
                      UtilsSvc.showPopup(error,2000);
                      AnalyticsSvc.trackEvent("Ground","Insert","Error",0);
                    }
                );
            }
        });
    };

    $scope.changePassword = function(){

      AnalyticsSvc.trackEvent("Perfil","Change Password","ShowPopup",1);
        $scope.data = {};

        var template = '<div class="mb-10"><label for="tn_name">Clave actual</label><input id="tn_password" type="password" ng-model="data.password" /></div>';
        template += '<div class="mb-10"><label for="tn_name">Nueva clave</label><input id="tn_newPassword" type="password" ng-model="data.newPassword" /></div>';
        template += '<div class="mb-10"><label for="tn_name">Confirme nueva clave</label><input id="tn_newPassword1" type="password" ng-model="data.newPassword1" /></div>';

        $ionicPopup.show({
            template: template,
            title: 'Agregar Cancha',
            subTitle: '',
            scope: $scope,
            buttons: [
                {
                    text: 'Cancelar',
                    onTap: function(e){
                        return null;
                    }
                },
                {
                    text: 'Guardar',
                    type: 'button-positive',
                    onTap: function(e){

                        if(!$scope.data.password || !$scope.data.newPassword1 || !$scope.data.newPassword){
                            UtilsSvc.showPopup("Completar los campos",2000);
                            e.preventDefault();
                        }
                        else{
                            if($scope.data.newPassword === $scope.data.newPassword1) {
                                return {
                                    'name': $scope.data.name,
                                    'type': $scope.data.type
                                };
                            }else {
                                UtilsSvc.showPopup("Nueva clave y su confirmacion debe ser iguales",2000);
                                e.preventDefault();
                            }
                        }
                    }
                }
            ]
        })
        .then(function(response){
            if(response){
                var config = {
                    password : $scope.data.password,
                    newPassword : $scope.data.newPassword,
                    newPassword1 : $scope.data.newPassword1
                }

                ConfigSvc.changePassword(config).then(
                    function(data){
                      UtilsSvc.showPopup(data,2000);
                      AnalyticsSvc.trackEvent("Ground","Insert","Success",1);
                    },
                    function(error){
                      UtilsSvc.showPopup(error,2000);
                      AnalyticsSvc.trackEvent("Ground","Insert","Error",0);
                    }
                );
            }
        });
    };

    SportcenterSvc.get().then(
        function(data){
            $scope.config = data;
            //initMap();
        }
    );


    // ==== Save.
    // ==========================================================

    function validate(){

        if(!$scope.config.name){
            UtilsSvc.showPopup("Completar nombre",2000);
            return false;
        }
        if(!$scope.config.address){
            UtilsSvc.showPopup("Completar direccion",2000);
            return false;
        }
        if(!$scope.config.mobile){
            UtilsSvc.showPopup("Completar teléfono",2000);
            return false;
        }
        if(!$scope.config.about){
            UtilsSvc.showPopup("Completar descripción",2000);
            return false;
        }

        if(!$scope.config.email) {
            UtilsSvc.showPopup("Completar email",2000);  
            return false; 
        }else {
            var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            if(!re.test($scope.config.email)) {
                UtilsSvc.showPopup("Completar email con una direccion válida",2000);
                return false;
            }
        }

        return true;
    }

    function sending(){
        $scope.button = 'Guardando..';
        $scope.sending = true;
    }

    function noSending(){
        $scope.button = 'Guardar';
        $scope.sending = false;
    }

    $scope.updateConfig = function(){

        if(!validate())
            return;

        var openAt = $scope.config.openAt.split(":")[0];
        var closeAt = $scope.config.endAt.split(":")[0];

        var update = {
            name: $scope.config.name,
            address: $scope.config.address,
            mobile: $scope.config.mobile,
            about: $scope.config.about,
            latitude: -32.896126,
            longitude: -68.834392,
            openAt : openAt,
            closeAt :  closeAt,
            email : $scope.config.email,
            emailverify: $scope.config.emailverify,
            mobileverify: $scope.config.mobileverify,
            feerequired: $scope.config.feerequired,
            status: "new"
        };

        sending();

        SportcenterSvc.update(update).then(
            function(data){
                UtilsSvc.showPopup("Guardado",2000);
                noSending();
                AnalyticsSvc.trackEvent("Sportcenter","Update","Success",1);
            },
            function(error){
                UtilsSvc.showPopup(error,2000);
                AnalyticsSvc.trackEvent("Sportcenter","Update","Error",0);
                noSending();
            }
        );
    };


    // ==== Google Maps.
    // ==========================================================

    $scope.$on('$ionicView.enter', function(){

        if(Object.keys($scope.config).length > 0)
            google.maps.event.trigger(myMap, 'resize');
        
        google.maps.event.addDomListener(window, 'load', initMap);
    });

    

}]);
