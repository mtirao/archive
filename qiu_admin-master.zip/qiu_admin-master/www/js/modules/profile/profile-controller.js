controllers.controller('ProfileCtrl', [
    '$scope',
    '$ionicPopup',
    'ConfigSvc',
    '$window',
    '$timeout',
    'AnalyticsSvc',
    'UtilsSvc',
    function($scope, $ionicPopup, ConfigSvc, $window, $timeout,AnalyticsSvc,UtilsSvc){

        AnalyticsSvc.trackView("Profile View");

        // ==== Variables.
        // ==========================================================

        var myMap, marker, latLng;

        $scope.height = parseInt($window.innerHeight * 0.28) + 'px';
        noSending();


        // ==== Hours.
        // ==========================================================

        $scope.hours = [];
        for(var i=10; i<=23; i++){
            if(i<10) $scope.hours.push('0' + i + ':00');
            else $scope.hours.push(i + ':00');
        }


        // ==== Info.
        // ==========================================================

        $scope.config = {};

        /* ==== Create a new field.
        ===================================================== */

        $scope.changePassword = function(){

            AnalyticsSvc.trackEvent("Perfil","Change Password","ShowPopup",1);
            $scope.data = {};

            var template = '<div class="mb-10"><label for="tn_name">Clave actual</label><input id="tn_password" type="password" ng-model="data.password" /></div>';
            template += '<div class="mb-10"><label for="tn_name">Nueva clave</label><input id="tn_newPassword" type="password" ng-model="data.newPassword" /></div>';
            template += '<div class="mb-10"><label for="tn_name">Confirme nueva clave</label><input id="tn_newPassword1" type="password" ng-model="data.newPassword1" /></div>';

            $ionicPopup.show({
                template: template,
                title: 'Cambio de Clave',
                subTitle: '',
                scope: $scope,
                buttons: [
                    {
                        text: 'Cancelar',
                        onTap: function(e){
                            return null;
                        }
                    },
                    {
                        text: 'Guardar',
                        type: 'button-positive',
                        onTap: function(e){

                            if(!$scope.data.password || !$scope.data.newPassword1 || !$scope.data.newPassword){
                                UtilsSvc.showPopup("Completar los campos",2000);
                                e.preventDefault();
                            }
                            else{
                                if($scope.data.newPassword === $scope.data.newPassword1) {
                                    return {
                                        'name': $scope.data.name,
                                        'type': $scope.data.type
                                    };
                                }else {
                                    UtilsSvc.showPopup("Nueva clave y su confirmacion debe ser iguales",2000);
                                    e.preventDefault();
                                }
                            }
                        }
                    }
                ]
            })
            .then(function(response){
                if(response){
                    var config = {
                        password : $scope.data.password,
                        newPassword : $scope.data.newPassword,
                        newPassword1 : $scope.data.newPassword1
                    }

                    ConfigSvc.changePassword(config).then(
                        function(data){
                        UtilsSvc.showPopup(data,2000);
                        AnalyticsSvc.trackEvent("Ground","Insert","Success",1);
                        },
                        function(error){
                        UtilsSvc.showPopup(error,2000);
                        AnalyticsSvc.trackEvent("Ground","Insert","Error",0);
                        }
                    );
                }
            });
        };

        ConfigSvc.get().then(
            function(data){
                $scope.config = data;
            }
        );


        // ==== Save.
        // ==========================================================

        function validate(){

            if(!$scope.config.name){
                UtilsSvc.showPopup("Completar nombre",2000);
                return false;
            }
            if(!$scope.config.address){
                UtilsSvc.showPopup("Completar direccion",2000);
                return false;
            }
            if(!$scope.config.phone){
                UtilsSvc.showPopup("Completar teléfono",2000);
                return false;
            }
            if(!$scope.config.description){
                UtilsSvc.showPopup("Completar descripción",2000);
                return false;
            }

            if(!$scope.config.contact) {
                UtilsSvc.showPopup("Completar email",2000);  
                return false; 
            }else {
                var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                if(!re.test($scope.config.contact)) {
                    UtilsSvc.showPopup("Completar email con una direccion válida",2000);
                    return false;
                }
            }

            return true;
        }

        function sending(){
            $scope.button = 'Guardando..';
            $scope.sending = true;
        }

        function noSending(){
            $scope.button = 'Guardar';
            $scope.sending = false;
        }

        $scope.updateConfig = function(){

            if(!validate())
                return;

            var update = {
                name: $scope.config.name,
                address: $scope.config.address,
                mobile: $scope.config.phone,
                about: $scope.config.description,
                email: $scope.config.contact
            };

            sending();

            ConfigSvc.update(update).then(
                function(data){
                    UtilsSvc.showPopup("Guardado",2000);
                    noSending();
                    AnalyticsSvc.trackEvent("Profile","Update","Success",1);
                },
                function(error){
                    UtilsSvc.showPopup(error,2000);
                    AnalyticsSvc.trackEvent("Profile","Update","Error",0);
                    noSending();
                }
            );
        };
            
        $scope.$on('$ionicView.enter', function(){
        });

}]);
