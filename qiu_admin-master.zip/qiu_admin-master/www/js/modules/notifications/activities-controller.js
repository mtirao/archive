
controllers.controller('ActivitiesCtrl', [
  '$scope',
  '$state',
  '$ionicPopup',
  '$ionicListDelegate',
  '$ionicLoading',
  'AnalyticsSvc',
  'UtilsSvc',
  'TurnsSvc',
  function ($scope, $state, $ionicPopup, $ionicListDelegate, $ionicLoading, AnalyticsSvc,UtilsSvc, TurnsSvc){

    AnalyticsSvc.trackView("Ground View");

    if(!window.cordova || !window.cordova.plugins){

    }

    /* ==== Get all fields.
    ===================================================== */

    $ionicLoading.show({template: 'Cargando...'});

    TurnsSvc.getOtherTurn().then(
        function(data){
            $ionicLoading.hide();
            for(var i=0; i < data.length; i++) {
                var date = new Date(data[i].from);
                data[i].date = date.toLocaleString();
            }
            $scope.items = data;
        },
        function(error){
            $ionicLoading.hide();
            $scope.items = null;
            UtilsSvc.showPopup(error,2000);
        }
    );

    $scope.activityDetail = function(id) {
        $state.selectedActivity = id;
        $state.go('app.activitiesDetail', id);
        console.log(id);
    }


    /* ==== Remove a field.
    ===================================================== */

    $scope.remove = function(id, position){
        $ionicListDelegate.closeOptionButtons();

        AnalyticsSvc.trackEvent("Ground","Delete","OpenPopup",1);
        var confirmPopup = $ionicPopup.confirm({
            title: 'Confirmar',
            template: '¿Está seguro que desea eliminar esta Notificacion?'
        });

        confirmPopup.then(function(res){
            if(res){
                NotificationsSvc.delete(id, position).then(
                    function(data){
                        UtilsSvc.showPopup(data,2000);
                        AnalyticsSvc.trackEvent("Ground","Delete","success",1);
                        $scope.items.splice(parseInt(position), 1);
                    },
                    function(error){
                        UtilsSvc.showPopup(error,2000);
                        AnalyticsSvc.trackEvent("Ground","Delete","Error",0);
                    }
                );
            }
        });
    };

    /* ==== Send new message a field.
    ===================================================== */

    $scope.new = function(){

        AnalyticsSvc.trackEvent("Ground","New","ShowPopup",1);
          $scope.data = {};

          var template = '<div class="mb-10"><label for="tn_name">Asunto</label><input id="tn_name" type="text" ng-model="data.title" /></div>';
          template += '<div class="mb-10"><label for="tn_name">Mensaje</label><input id="tn_name" type="text" ng-model="data.message" /></div>';


          $ionicPopup.show({
              template: template,
              title: 'Enviar Mensaje',
              subTitle: '',
              scope: $scope,
              buttons: [
                  {
                      text: 'Cancelar',
                      onTap: function(e){
                          return null;
                      }
                  },
                  {
                      text: 'Enviar',
                      type: 'button-positive',
                      onTap: function(e){
                          if(!$scope.data.title || !$scope.data.message){
                              UtilsSvc.showPopup("Completar los campos",2000);
                              e.preventDefault();
                          }
                          else{
                              return {
                                'title': $scope.data.title,
                                'message': $scope.data.message
                              };
                          }
                      }
                  }
              ]
          })
          .then(function(response){
              if(response){
                  NotificationsSvc.insert(response.title, response.message).then(
                      function(data){
                        UtilsSvc.showPopup(data,2000);
                        AnalyticsSvc.trackEvent("Ground","Insert","Success",1);
                      },
                      function(error){
                        UtilsSvc.showPopup(error,2000);
                        AnalyticsSvc.trackEvent("Ground","Insert","Error",0);
                      }
                  );
              }
          });
      };

}])


/* ==== Directive.
===================================================== */

.directive('closeOption', [
    '$ionicGesture',
    '$ionicListDelegate',
    function ($ionicGesture, $ionicListDelegate){
    return {
        restrict: 'A',
        link: function(scope, elem, attrs){
            $ionicGesture.on(
                'touch',
                function(e){
                    $ionicListDelegate.closeOptionButtons();
                },
                elem
            );
        }
    };
}]);
