
controllers.controller('ActivityDetailCtrl', [
  '$scope',
  '$state',
  '$ionicPopup',
  '$ionicListDelegate',
  '$ionicLoading',
  '$window',
  'AnalyticsSvc',
  'UtilsSvc',
  'TurnsSvc',
  function ($scope, $state, $ionicPopup, $ionicListDelegate, $ionicLoading, $window, AnalyticsSvc,UtilsSvc, TurnsSvc){

    AnalyticsSvc.trackView("Activity Detail View");

    // ==== Variables.
    // ==========================================================

    var myMap, marker, latLng;

    $scope.height = parseInt($window.innerHeight * 0.28) + 'px';

     /* ==== Create a new field.
    ===================================================== */

    $scope.$on('$ionicView.enter', function() {

        TurnsSvc.getTurn($state.selectedActivity).then(function(data){

            var lat = data.sportcenter.location[0];
            var lng = data.sportcenter.location[1];


            loadMap(lat, lng);

            var date = new Date(data.from);

            var dateFormat = date.toLocaleString();

            $scope.turn = {
                name: data.sportcenter.name,
                address: data.sportcenter.address,
                phone: data.sportcenter.mobile,
                email: data.sportcenter.email,
                date:  dateFormat
            };

            /*var geoOptions = {timeout: 10000, enableHighAccuracy: true};

            $cordovaGeolocation.getCurrentPosition(geoOptions).then(function(position){

                loadMap(position.coords.latitude, position.coords.longitude);

            }, function(error){
            console.log("Could not get location");
            });*/


        }).catch(function(error) {

        });


    });


    // ==== Google Maps.
    // ==========================================================
    function loadMap(lat, lon){
        var latLng = new google.maps.LatLng(lat,lon);
        lastCenter = latLng;

        var mapOptions = {
            center: latLng,
            zoom: 13,
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            disableDefaultUI: true,
            draggable: true
        };
        map = new google.maps.Map(document.getElementById("google-map"),mapOptions);

        firstCenter = map.getCenter();

        var marker = new google.maps.Marker({
            map: map,
            animation: google.maps.Animation.DROP,
            position: latLng
        });


        //$scope.config.coordinates.lat = lat;
        //$scope.config.coordinates.lng = lon;

        var infoWindow = new google.maps.InfoWindow({
            content: "Here I am!"
        });

        google.maps.event.addDomListener(marker, 'click', function () {
            infoWindow.open($scope.map, marker);
        });

        mapaInit = true;
        /*var image = {
          url: 'img/icon-map-pin-red.png',
          // This marker is 20 pixels wide by 32 pixels high.
          size: new google.maps.Size(64, 64),
          // The origin for this image is (0, 0).
          origin: new google.maps.Point(0, 0),
          // The anchor for this image is the base of the flagpole at (0, 32).
          anchor: new google.maps.Point(32, 64)
        };

        marker = new google.maps.Marker({
            position: new google.maps.LatLng(lat, lng),
            icon: image,
            map: myMap,
            draggable: false,
            animation: google.maps.Animation.DROP
        });*/

        google.maps.event.addDomListener(map, 'click', function(ev){
            // Stop propagation
            ev.cancelBubble = true;
            ev.stopPropagation && ev.stopPropagation();
            ev.preventDefault && ev.preventDefault();
            ev.stop();

            // Set marker and center map
            latLng = new google.maps.LatLng(ev.latLng.lat(), ev.latLng.lng());
            marker.setPosition(latLng);
            map.setCenter(latLng);

            return false;
        });
    }


}]);
