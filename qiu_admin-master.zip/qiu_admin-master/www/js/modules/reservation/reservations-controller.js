controllers.controller('ReservationsCtrl', [
    '$scope',
    '$state',
    '$compile',
    '$ionicPopup',
    '$cordovaGeolocation',
    'SportcenterSvc',
    '$window',
    '$timeout',
    'AnalyticsSvc',
    'UtilsSvc',
    'FieldsSvc',
    'TurnsSvc',
    'SportcenterSvc',
    'LocalStorageSvc',
    '$ionicModal',
    function($scope, $state, $compile, $ionicPopup, $cordovaGeolocation, ConfigSvc, $window, $timeout,AnalyticsSvc,UtilsSvc, FieldsSvc, TurnsSvc, SportcenterSvc, LocalStorageSvc,$ionicModal) {

        AnalyticsSvc.trackView("Map View");

        var mapaInit = false;
        var lastCenter;

        $scope.dateReservation = "";

        var map;
        $scope.markers = [];

        $scope.modalinfo = {};

        var lastDate;
        var lastHour;
        var lastType;

        var firstCenter;

        $scope.hours = [];

        var sportcenter = LocalStorageSvc.getObject('sportcenter');

        for(var i=10; i<=23; i++){
            if(i<10) $scope.hours.push('0' + i + ':00');
            else $scope.hours.push(i + ':00');
        }


        $scope.sports = [];

        FieldsSvc.types().then(
            function(data){
                console.log(data);
                $scope.sports = data;
            },
            function(error){
                UtilsSvc.showPopup(error,2000);
            }
        );

        var options = {timeout: 10000, enableHighAccuracy: true};

        $ionicModal.fromTemplateUrl('modalViewTurn.html', {
            scope: $scope,
            animation: 'slide-in-up'
        }).then(function(modal){
            $scope.modalViewTurn = modal;
        }).catch(function(error) {
            console.log(error)
        });


        $scope.showOtherTurns = function() {
            $state.go('app.activities');
        }

        $scope.selectSport = function(id){
            removeActiveButtons();
            activeButton(id);
        // focusHackInput();
        }


        var removeActiveButtons = function(){
            for (var i = 0; i < $scope.sports.length; i++) {
                $scope.sports[i].active = false;
            };
        };

        var activeButton = function(id){
            for (var i = 0; i < $scope.sports.length; i++) {
                if($scope.sports[i]._id == id){
                $scope.sports[i].active = true;
                break;
                }
            };
        };

        $scope.getDatePicker = function(type){
            var options = {
                date: new Date(),
                mode: type, // or 'time'
                minDate: new Date(),
                allowOldDates: false,
                allowFutureDates: true,
                doneButtonLabel: 'DONE',
                doneButtonColor: '#1467EB',
                cancelButtonLabel: 'CANCEL',
                cancelButtonColor: '#000000'
            }
        };


        $scope.$on('$ionicView.enter', function() {

            var geoOptions = {timeout: 10000, enableHighAccuracy: true};

            initialize();

            $cordovaGeolocation.getCurrentPosition(geoOptions).then(function(position){

                addCurrentLocationMarker(position.coords.latitude, position.coords.longitude);

            }, function(error){

                //initialize with default in case location couldn't be get
                console.log("Could not get location");
            });

            });

            function existsPhone(){
                return (window.localStorage["phone"] !== "" && window.localStorage["phone"] !== undefined);
            }


            function addCurrentLocationMarker(lat,lon) {
                var latLng = new google.maps.LatLng(lat,lon);
                lastCenter = latLng;

                map = $scope.map = map;
                var marker = new google.maps.Marker({
                    map: map,
                    animation: google.maps.Animation.DROP,
                    position: latLng
                });

                var infoWindow = new google.maps.InfoWindow({
                    content: "Ud. Se encuentra aquí"
                });

                google.maps.event.addDomListener(marker, 'click', function () {
                    infoWindow.open($scope.map, marker);
                });

            }

            function initialize() {

                var latLng = new google.maps.LatLng(-34.5950346,-58.448026);
                var mapOptions = {
                    center: latLng,
                    zoom: 13,
                    mapTypeId: google.maps.MapTypeId.ROADMAP,
                    disableDefaultUI: true,
                    draggable: true
                };

                map = new google.maps.Map(document.getElementById("reservation-google-map"),mapOptions);
                $scope.map = map;

                firstCenter = map.getCenter();

                map.addListener('dragend', function(e) {
                    var dist = getDistance(firstCenter,map.getCenter());
                    lastCenter = map.getCenter();
                    if(dist > 0){// metros
                    // $rootScope.findTurnsByDateAndHour(lastDate,lastHour,lastType);
                    firstCenter = map.getCenter();
                    }
                });

                mapaInit = true;

                SportcenterSvc.getOthers().then( function(data){

                    var infoWindow = new google.maps.InfoWindow;

                    for (i = 0; i < data.length; i++) {

                        var sportcenter = data[i];

                        var location = sportcenter.location;

                        $scope.markers[i] = new google.maps.Marker({
                            map: map,
                            animation: google.maps.Animation.DROP,
                            icon: 'img/icon-map-pin-green.png',
                            position: new google.maps.LatLng(location[0],location[1]),
                            title: sportcenter.name,
                            id: sportcenter._id,
                            status: sportcenter.status
                        });

                        if(sportcenter.status == "new") {
                            $scope.markers[i].icon = 'img/icon-map-pin-red.png';
                        }else if(sportcenter.status == "in progress") {
                            $scope.markers[i].icon = 'img/icon-map-pin-yellow.png';
                        }

                        google.maps.event.addListener($scope.markers[ i ], 'click', function() {
                            var marker = this;

                            var contentString = "<button class='button button-clear button-positive' \
                                        ng-click=\"clickInfoWindow('"+marker.id+"','"+marker.status+"','"+marker.title+"')\">"
                            +marker.title+"</button>";

                            var compiled = $compile(contentString)($scope);

                            infoWindow.setContent( compiled[0] );

                            if(marker.status == "confirmed" || marker.status == "in progress") {
                                infoWindow.open(map, marker);
                            }
                        });

                    }

                },function(error){
                    UtilsSvc.showPopup(error,2000);
                })

            }

            $scope.closeModalViewTurn = function(){
                $scope.modalViewTurn.hide();
            };

            $scope.saveTurn = function() {
                console.log("Click on Save");
                $scope.modalViewTurn.hide();

                $scope.newTurn.date = new Date();



                console.log($scope.newTurn);


                var confirmPopup = $ionicPopup.confirm({
                    title: 'Confirmacion',
                    template: 'Para que su reserva este confirmada tendra que pagar un delanto, en el predio. Continuar?'
                });

                confirmPopup.then(function(res){
                    TurnsSvc.addTurn($scope.newTurn).then(
                        function(data){
                            UtilsSvc.showPopup("Su reserva fue tomada. Sujeta a confirmacion",2000);
                            AnalyticsSvc.trackEvent("Ground","Insert","Success",1);
                        },function(error){
                            UtilsSvc.showPopup("Su reserva no fue registrada",2000);
                            AnalyticsSvc.trackEvent("Ground","Insert","Error",0);
                        }
                    );
                });

            }

            function showTurnPopUp(sportcenter, title) {

                var today = new Date();
                var minDate = today.getFullYear() + "-" + (today.getMonth() + 1) + "-" + today.getDate();

                $scope.newTurn = {sportcenter: sportcenter};

                $scope.modalViewTurn.field = title

                $scope.modalViewTurn.show();

            }

        function addTurn(sportcenter, status, title){

            AnalyticsSvc.trackEvent("Ground","New","ShowPopup",1);
            $scope.data = {};

            $scope.data.date = new Date();

            var time = new Date();
            time.setSeconds(0);
            time.setMilliseconds(0)

            var minute = time.getMinutes() - 30;

            if( minute < 0) {
                time.setMinutes(0);
            }else {
                time.setMinutes(30)
            }
            $scope.data.time = time;

            var profile = LocalStorageSvc.getObject('profile');

            if(!profile) {
            ConfigSvc.get().then(
                function(data){
                    $scope.data.name = data.name;
                    $scope.data.phone = data.phone;
                    showTurnPopUp(sportcenter, title);
                }
            );
            }else {
            $scope.data.name = profile.name;
            $scope.data.phone = profile.phone;
            showTurnPopUp(sportcenter, title);
            }

        };



        $scope.clickInfoWindow = function(idAdmin, state, name){

            if(state == "in progress") {
                UtilsSvc.showPopup("Esta en progreso de alta, no puede tomar reservas aun.",2000);
            }else {
                addTurn(idAdmin, state, name);
            }
        /*var date = getObjectDate();
        if(state == 3){
            $scope.openModal(idAdmin);
            return;
        }
        $ionicLoading.show({
            template: 'Verificando cancha...'
        });
        UserSvc.checkTurnsByDate(date).then(function(data){
            $ionicLoading.hide();
            if(!data){
            UtilsSrv.showPopup("Hubo un error, por favor verifique su conexion a internet",2000);
            return;
            }

            if(data.code !== 200){

            // $cordovaToast.show('Hubo un error', 'short', 'center');
            UtilsSrv.showPopup('Hubo un error',1500);
            return;
            }

            if(data.result.error){
            // $cordovaToast.show(data.result.error, 'short', 'center');
            UtilsSrv.showPopup(data.result.error,1500);
            return;
            }

            if(data.result.groundsReserved > 0){
            // $cordovaToast.show('Ya tiene una reserva en un cancha para esa fecha y hora', 'short', 'center');
            UtilsSrv.showPopup('Ya tiene una reserva en un cancha para esa fecha y hora',1500);
            return;
            }


            if(state !== 3){
            lastCenter = map.getCenter();

            // var day = lastDate.split("/")[0];
            // var month = lastDate.split("/")[1];
            // var year = lastDate.split("/")[2];
            // var from = new Date(parseInt(year),parseInt(month)-1,parseInt(day),parseInt(lastHour),0,0,0);
            var from = getObjectDate();
            // var to = new Date(parseInt(year),parseInt(month)-1,parseInt(day),parseInt(lastHour)+1,0,0,0);
            var to = getObjectDate(1);


            if(!existsPhone()){
                $state.go("tab.confirmation",
                    {'idAdmin':idAdmin,
                    'idGround':idGround,
                    'name':window.localStorage["name"],
                    'from':from,
                    'to':to,
                    'typeId':lastType
                    });
                return;
            }

            var name = window.localStorage["name"];
            var phone = window.localStorage["phone"];

            TurnSrv.createHeaderTurn(idAdmin,idGround,name,phone,from,to).then(function(data){

                if(data.code !== 200){
                // handle error
                return;

                }

                // $state.go("tab.invitefriends",
                //   {'idAdmin':idAdmin,
                //   'idGround':idGround,
                //   'name': window.localStorage["name"],
                //   'phone': window.localStorage["phone"],
                //   'from':from,
                //   'to':to,
                //   'typeId':lastType
                // });
                // $state.go("tab.invitefriends",{"idAdmin":data.result._id});

                $state.go("tab.invitefriends",{"idTurn":data.result._id});

            },function(err){
                // $cordovaToast.show("Hubo un error y no pudo crearse el turno por favor intentelo nuevamente","short","center");
                UtilsSrv.showPopup("Hubo un error y no pudo crearse el turno por favor intentelo nuevamente",1500);
            });

            }

        },function (err){
            $ionicLoading.hide();
            // $cordovaToast.show("Hubo un error y no pudo crearse el turno por favor intentelo nuevamente","short","center");
            UtilsSrv.showPopup("Hubo un error y no pudo crearse el turno por favor intentelo nuevamente",1500);
        });
        */
        };


        //TODO: Review and delete if necessary

        function resize(){
            google.maps.event.trigger(map, 'resize');
            map.setCenter(lastCenter);
        }

        var rad = function(x) {
            return x * Math.PI / 180;
        };

        var getDistance = function(p1, p2) {
            var R = 6378137; // Earth’s mean radius in meter
            var dLat = rad(p2.lat() - p1.lat());
            var dLong = rad(p2.lng() - p1.lng());
            var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(rad(p1.lat())) * Math.cos(rad(p2.lat())) *
                Math.sin(dLong / 2) * Math.sin(dLong / 2);
            var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
            var d = R * c;
            return d; // returns the distance in meter
        };


        function formatHour(lastHour){
            var newHour;
            if(parseInt(lastHour) < 10){
                newHour = "0"+lastHour+":00";
            }else{
                newHour = lastHour+":00";
            }
            return newHour;
        }

        $scope.openModal = function(idAdmin) {
            AdminSrv.getAdmin(idAdmin).then(function(data){
                if(data.code !== 200){
                // $cordovaToast.show('No pudo obtenerse la informacion de la cancha', 'short', 'center');
                UtilsSrv.showPopup('No pudo obtenerse la informacion de la cancha',1500);
                return;
                }
                $scope.modalinfo.name = data.result.name;
                $scope.modalinfo.address = data.result.address;
                $scope.modalinfo.hour = formatHour(lastHour);

            });
            $scope.modal.show();
        };

        $scope.closeModal = function() {
            $scope.modal.hide();
        };

        $scope.inviteFriends = function(){
            $scope.modal.hide();
        //$rootScope.activeFromController();
        }

        //Cleanup the modal when we're done with it!
        $scope.$on('$destroy', function() {
            $scope.modal.remove();
        });
        // Execute action on hide modal
        $scope.$on('modal.hidden', function() {
        // Execute action
        });
        // Execute action on remove modal
        $scope.$on('modal.removed', function() {
        // Execute action
        });


        function cleanAllMarkers(){
            for (var i = 0; i < $scope.markers.length; i++) {
                $scope.markers[i].setMap(null);
            }
            $scope.markers = [];
        }

        function getObjectDate(plusHours){
            if (typeof plusHours === 'undefined') { plusHours = 0; }
            var day = lastDate.split("/")[0];
            var month = lastDate.split("/")[1];
            var year = lastDate.split("/")[2];
            var date = new Date(parseInt(year),parseInt(month)-1,parseInt(day),parseInt(lastHour)+plusHours,0,0,0);
            return date;
        }




        function removeMarker(idMarker){
            for (var i = 0; i < $scope.markers.length; i++) {
                if($scope.markers[i].idAdmin == idMarker){
                $scope.markers[i].setMap(null);
                $scope.markers.splice(i, 1);
                break;
                }
            };
        }

        function closeAllInfoWindows(){
            for (var i = 0; i < $scope.markers.length; i++) {
                $scope.markers[i].infowindow.close();
            };
        }

        function checkState(marker,newState,oldState){

            if(newState !== oldState){
                marker.setIcon(getIcon(newState));
                marker.state = newState;
                marker.infowindow.close();
                google.maps.event.clearListeners(marker, 'click');
                addClickListener(marker);
            }

        };

        function removeIfNotExists(markers){
            var toRemove = [];
            for (var i = 0; i < $scope.markers.length; i++) {
                var exists = false;

                for (var j = 0; j < markers.length; j++) {

                if(markers[j] == null){
                    continue;
                }

                if($scope.markers[i].idAdmin == markers[j]._id){
                    exists = true;
                    break;
                }
                };
                if(!exists){
                toRemove.push($scope.markers[i].idAdmin);
                }
            };
            if(toRemove.length > 0){
                for (var i = 0; i < toRemove.length; i++) {
                removeMarker(toRemove[i]);
                };
            }
        };

        function checkMarkers(newMarkers){

            removeIfNotExists(newMarkers);

            for (var i = 0; i < newMarkers.length; i++) {

                if(newMarkers[i] == null){
                continue;
                }

                var exists = false;
                for (var j = 0; j < $scope.markers.length; j++) {
                if(newMarkers[i]._id == $scope.markers[j].idAdmin){
                    checkState($scope.markers[j],newMarkers[i].state,$scope.markers[j].state);
                    exists = true;
                    break;
                }
                };

                if(!exists){
                addMarker(newMarkers[i]);
                }

            };

        }

        function getTurnsByLocationAndDate(day,hour,location,typeId){
            TurnSrv.getTurnsByLocationAndDate(day,hour,location,typeId).then(function(data){
                if(data.code !== 200){
                cleanAllMarkers();
                return;
                }

                // window.localStorage["lastLat"] = location.lat;
                // window.localStorage["lastLng"] = location.lng;

                $scope.dateReservation = day.split("/")[0]+"/"+day.split("/")[1]+" "+hour+"hs" ;


                lastDate = day;
                lastHour = hour;
                lastType = typeId;
                var newMarkers = data.result.object;
                // cleanAllMarkers();

                if(newMarkers.length == 0){
                // handle when there is no grounds
                cleanAllMarkers();
                // $cordovaToast.show("No se encontraron canchas en esta zona","short","center");
                }else{
                // addMarkers(newMarkers);
                    checkMarkers(newMarkers);
                }

            });
        }

}]);
