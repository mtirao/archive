controllers.controller('CalendarDayCtrl',[
    '$rootScope',
    '$scope',
    '$state',
    '$stateParams',
    '$ionicScrollDelegate',
    '$ionicModal',
    '$ionicPopup',
    '$ionicLoading',
    '$window',
    'ArraySvc',
    'TurnsSvc',
    'HoursSvc',
    'FieldsSvc',
    'LocalStorageSvc',
    'DateSvc',
    'AnalyticsSvc',
    'UtilsSvc',
    function($rootScope, $scope, $state, $stateParams, $ionicScrollDelegate, $ionicModal, $ionicPopup, $ionicLoading, $window, ArraySvc, TurnsSvc, HoursSvc, FieldsSvc, LocalStorageSvc, DateSvc,AnalyticsSvc,UtilsSvc){

        AnalyticsSvc.trackView("Calendar Date View");

        if(!window.cordova || !window.cordova.plugins){

        }

        var months  = ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'];

        var selectedDate = new Date();

        if($state.selectedDate) {
            selectedDate = $state.selectedDate.date;
        }

        if(LocalStorageSvc.getObject('sportcenter')) {
            $rootScope.sportcenter = true;
        }


        var date    =  [selectedDate.getFullYear(), (selectedDate.getMonth()+1), selectedDate.getDate()];

        var dateAll = date[0] + '-' + ((date[1] < 10) ? ('0' + date[1]) : date[1]) + '-' + ((date[2] < 10) ? ('0' + date[2]) : date[2]);
        var current = date[0] + ((date[1] < 10) ? ('0'+date[1]) : date[1]) + ((date[2] < 10) ? ('0' + date[2]) : date[2]);

        var aux = new Date();
        var today = aux.getFullYear().toString() + ((aux.getMonth()+1 < 10) ? '0 ' + (aux.getMonth()+1) : (aux.getMonth()+1).toString()) + ((aux.getDate() < 10) ? ('0' + aux.getDate()) : aux.getDate().toString());

        var widthAux;


        /* ==== On enter.
        ===================================================== */

        $scope.$on('$ionicView.enter', function(){
            getTurns();
        });


        /* ==== Scopes.
        ===================================================== */

        //$scope.isOldTurn = (current < today) ? true : false;
        $scope.isOldTurn = false;
        $scope.loading = true;
        $scope.fields = [];
        $scope.events = [];

        $scope.messageState = "";

        $scope.$on('events', function(ev, message){
            $scope.events = message.turns;
            myApply();
            calculateTop();
            calculateLeft();
            calculateHeight();
        });

        $scope.isOldTurn = (current < today) ? true : false;

        $scope.fields = [];
        $scope.events = [];



        var sportcenter = LocalStorageSvc.getObject('sportcenter');

        $scope.hours        = HoursSvc.get(sportcenter);

        $scope.hoursList    = HoursSvc.get(sportcenter);

        $scope.actually     = (current === today)?'HOY':months[parseInt(date[1])-1] + ' ' + date[2];
        $scope.timertop     = 0;
        $scope.timerleft    = 0;
        $scope.daysToShow   = [new Date()];

        $scope.getNumber = function(num){
            return new Array(num);
        };

        $scope.gotScrolled = function(){
            myApply();
        };

        $scope.goMonthCalendar = function(){
            $state.go('app.turnsMonth');
        };


        /* ==== Toogle rows.
        ===================================================== */

        $scope.groups   = (LocalStorageSvc.exist('dayCalendarConfig')) ? LocalStorageSvc.getObject('dayCalendarConfig') : [];
        $scope.range    = [null, null];
        $scope.selectedPosition = -1;
        $scope.selected = false;

        $scope.hideRow = function(x){
        $scope.selectedPosition = x;

        if($scope.range[0] == null){
            $scope.range[0] = x;
            $scope.selected = true;
        }
        else{
            $scope.range[1] = x;
            $scope.selected = false;
            $scope.range.sort(function(a, b){return a-b});

            var items = [];

            // Add minimize rows
            for(var i=$scope.range[0]; i<=$scope.range[1]; i++)
            items.push(i);

            // Gruops minimized
            $scope.groups.push({
            position: $scope.range[0],
            items: items
            });

            // Clean range
            $scope.range = [null, null];

            // Calculate
            calculateTop();
            calculateLeft();
            calculateHeight();
            AnalyticsSvc.trackEvent("Calendar","Day","Collapse",1);
        }
        };

        $scope.hide = function(x){
        for(var j=0; j<$scope.groups.length; j++)
            for(var k=0; k<$scope.groups[j].items.length; k++)
            if($scope.groups[j].items[k] == x){
                LocalStorageSvc.setObject('dayCalendarConfig', $scope.groups);
                return true;
            }

        return false;
        };

        $scope.show = function(x){
        maximize(x);
        LocalStorageSvc.setObject('dayCalendarConfig', $scope.groups);
        AnalyticsSvc.trackEvent("Calendar","Day","UnCollapse",1);
        };

        $scope.showMaximize = function(x){
            for(var j=0; j<$scope.groups.length; j++)
                if($scope.groups[j].position == x)
                    return true;
            return false;
        };

        /**
         * Open collapesed hours
         * @param position
         */
        function maximize(position){
            for(var j=0; j<$scope.groups.length; j++)
                if($scope.groups[j].position == position){
                    $scope.groups.splice(j, 1);
                    calculateTop();
                    calculateLeft();
                    calculateHeight();
                    return;
                }
        }

        /**
         * Calculate top position
         */
        function calculateTop(){
        var rowHide       = 0,
            rowsMaximize  = 0,
            position      = 0,
            headerHeight  = document.getElementById('calendarHead').offsetHeight,
            cellHeight    = document.getElementsByClassName('calendarCell')[0].offsetHeight;

        for(var i=0; i<$scope.events.length; i++){
            position      = $scope.events[i].startPosition;
            rowsMaximize  = countHigher(allMaximize(), position);
            rowHide       = countHigher(allMinimized(), position);

            $scope.events[i].top = position*cellHeight + headerHeight - rowHide*cellHeight + rowsMaximize*29;

            rowHide       = 0;
            rowsMaximize  = 0;
        }
        }

        /**
         * Calculate top position events
         */
        function calculateTopEvents(events){
        var rowHide       = 0,
            rowsMaximize  = 0,
            position      = 0,
            headerHeight  = document.getElementById('calendarHead').offsetHeight,
            cellHeight    = document.getElementsByClassName('calendarCell')[0].offsetHeight;

        for(var i=0; i<events.length; i++){
            position      = events[i].startPosition;
            rowsMaximize  = countHigher(allMaximize(), position);
            rowHide       = countHigher(allMinimized(), position);

            events[i].top = position*cellHeight + headerHeight - rowHide*cellHeight + rowsMaximize*29;

            rowHide       = 0;
            rowsMaximize  = 0;
        }
        return events;
        }

        /**
         * Calculate Left Position
         */
        function calculateLeft(){
        var headCell      = document.getElementsByClassName('calendarTHCell')[0].offsetWidth;

        for(var i=0; i<$scope.events.length; i++)
            $scope.events[i].left = headCell + $scope.events[i].positionField * $scope.width;
        }

        /**
         * Calculate Left Position
         */
        function calculateLeftEvents(events){
        var headCell      = document.getElementsByClassName('calendarTHCell')[0].offsetWidth;

        for(var i=0; i<events.length; i++){
            events[i].left = headCell + events[i].positionField * $scope.width;
        }
        return events;
        }

        /**
         * Calculate Height POsition
         */
        function calculateHeightEvents(events){
        var cellHeight    = document.getElementsByClassName('calendarCell')[0].offsetHeight;

        for(var i=0; i<events.length; i++){
            var mfh = mediumsForHeight(events[i].startPosition, events[i].endPosition);

            var height = (events[i].endPosition - events[i].startPosition) * cellHeight;
            var middle = mfh.k * cellHeight;
            var yelloRow = (mfh.widthLast) ? 0 : 29;

            if(middle > 0) events[i].height = height - middle + yelloRow;
            else events[i].height = height;

            if(events[i].starthour === '23:00'){
            events[i].height = 30;
            }
        }
        return events;
        }
        /**
         * Calculate Height POsition
         */
        function calculateHeight(){
        var cellHeight    = document.getElementsByClassName('calendarCell')[0].offsetHeight;

        for(var i=0; i<$scope.events.length; i++){
            var mfh = mediumsForHeight($scope.events[i].startPosition, $scope.events[i].endPosition);

            var height = ($scope.events[i].endPosition - $scope.events[i].startPosition) * cellHeight;
            var middle = mfh.k * cellHeight;
            var yelloRow = (mfh.widthLast) ? 0 : 29;

            if(middle > 0) $scope.events[i].height = height - middle + yelloRow;
            else $scope.events[i].height = height;

            if($scope.events[i].starthour === '23:00'){
            $scope.events[i].height = 30;
            }
        }
        }

        function countHigher(array, x){
        var result = 0;

        for(var j=0; j<array.length; j++)
            if(x > array[j])
            result++;

        return result;
        }

        function mediumsForHeight(a, b){
        var m = allMinimized();
        var n = [];
        var k = 0;

        for(var j=a; j<b; j++)
            n.push(j);

        for(var j=0; j<n.length; j++)
            if(m.indexOf(n[j]) > -1)
            k++;

        return {
            k: k,
            widthLast: (m.indexOf(b-1) > -1) ? true : false
        };
        }

        function allMinimized(){
        var result = [];

        for(var j=0; j<$scope.groups.length; j++)
            for(var k=0; k<$scope.groups[j].items.length; k++)
            result.push($scope.groups[j].items[k]);

        return result.sort();
        }

        function allMaximize(){
        var result = [];

        for(var j=0; j<$scope.groups.length; j++)
            result.push($scope.groups[j].position);

        return result.sort();
        }

        function end(a, b){
            var p = -1;
            var aux = [];
            var array = [];

            if(b == null){
                $scope.modalNewTurn.end = $scope.hoursList;
            }else{
                for(var i=a+1; i<=b; i++)
                array.push($scope.hoursList[i]);
            }

            return array;
        }


        /* ==== New turn.
        ===================================================== */

        $ionicModal.fromTemplateUrl('modalNewTurn.html', {
        scope: $scope,
        animation: 'slide-in-up'
        })
        .then(function(modal){
            $scope.modalNewTurn = modal;
            AnalyticsSvc.trackEvent("Calendar","Day","TurnPopup",1);
        });

        $scope.openModalNewTurn = function(x, y){

            $scope.modalNewTurn.phone = '';
            $scope.modalNewTurn.idField = FieldsSvc.getId(x);
            $scope.modalNewTurn.field = FieldsSvc.getName(x);

            $scope.modalNewTurn.start = $scope.hours[y];

            $scope.modalNewTurn.end = end(y, maxEnd(x, $scope.hours[y]));
            $scope.modalNewTurn.endSelect = $scope.modalNewTurn.end[0];

            $scope.modalNewTurn.addTurn = function(){
                if(!$scope.modalNewTurn.client){
                    UtilsSvc.showPopup("Completar cliente",2000);
                    return;
                }

                if(!$scope.modalNewTurn.phone){
                    UtilsSvc.showPopup("Completar teléfono",2000);
                return;
                }

                var start = $scope.modalNewTurn.start.split(':');
                var end = $scope.modalNewTurn.endSelect.split(':');

                var _start = new Date(date[0], date[1]-1, date[2], start[0], start[1], 0, 0);
                var _end = new Date(date[0], date[1]-1, date[2], end[0], end[1], 0, 0);

                $ionicLoading.show({template: 'Enviando..'});


                var turnObj = {
                    idGround:$scope.modalNewTurn.idField,
                    from:_start,
                    to: _end,
                    phone:$scope.modalNewTurn.phone,
                    name:$scope.modalNewTurn.client,
                    isSticky: $scope.modalNewTurn.isSticky,
                    sportcenter: LocalStorageSvc.getObject('sportcenter')._id,
                    status: "confirmed"
                };



                TurnsSvc.addTurn(turnObj).then(
                    function(data){
                        $ionicLoading.hide();
                        getTurns();

                        UtilsSvc.showPopup("Turno creado",2000);
                        AnalyticsSvc.trackEvent("Calendar","Turn","Success",1);
                    },
                    function(error){
                        $ionicLoading.hide();
                        UtilsSvc.showPopup("Error. Intente de nuevo",2000);
                        AnalyticsSvc.trackEvent("Calendar","Turn","Error",1);
                    }
                );

            $scope.closeModalNewTurn();
        };

            $scope.modalNewTurn.show();
        };

        $scope.closeModalNewTurn = function(){
            $scope.modalNewTurn.hide();
            $scope.modalNewTurn.client = '';
        };

        function maxEnd(positionField, hour){
            var aux = [];
            var tmp, response;

            // Turns per field
            for(var i=0; i<$scope.events.length; i++){
                if($scope.events[i].positionField == positionField)
                aux.push($scope.events[i]);
            }

            // Ordening turns per start hour
            for(var i=1; i<aux.length; i++){
                for(var j=0; j<aux.length - 1; j++){
                if(aux[j].from > aux[j+1].from){
                    tmp = aux[j];
                    aux[j] = aux[j+1];
                    aux[j+1] = tmp;
                }
            }
        }

        // Select next end hour
        hour = parseInt(hour.replace(':', ''));

        tmp = null;

        for(var i=0; i<aux.length; i++){
            if(aux[i].from > hour){
            tmp = aux[i].from;
            break;
            }
        }

        // Select index of hour
        if(tmp == null){
            response = $scope.hoursList.length-1;
        }else{
            if(tmp == 1000 || tmp == 2000) tmp = tmp.toString().replace('000', '0:00');
            else if(tmp > 999) tmp = tmp.toString().replace('00', ':00');
            else tmp = '0' + tmp.toString().replace('00', ':00');
            response = HoursSvc.getPositionForList(tmp,hour);
        }
        return response;
        }


        /* ==== View turn.
        ===================================================== */

        $ionicModal.fromTemplateUrl('modalViewTurn.html', {
            scope: $scope,
            animation: 'slide-in-up'
        }).then(function(modal){
            $scope.modalViewTurn = modal;
        });

        function getFieldsName(ground) {
            for(i = 0; i < $scope.fields.length; i++) {
                if($scope.fields[i]._id == ground) {
                    return $scope.fields[i].name;
                }
            }

            return "";
        }

        $scope.openModalViewTurn = function(position){

            $scope.modalViewTurn.day = $scope.actually;
            $scope.modalViewTurn.field = getFieldsName($scope.events[position].ground);
            $scope.modalViewTurn.start = $scope.events[position].starthour;
            $scope.modalViewTurn.end = $scope.events[position].endhour;
            $scope.modalViewTurn.client = $scope.events[position].eventname;
            $scope.modalViewTurn.phone = $scope.events[position].phone;

            var popupMessage = "";

            if($scope.events[position].status == "confirmed") {
                $scope.modalViewTurn.buttonTitle = "Cancelar"
                popupMessage = "cancelar";
            }else {
                $scope.modalViewTurn.buttonTitle = "Confirmar";
                popupMessage = "confirmar";
            }
           

            AnalyticsSvc.trackEvent("Calendar","Turn","Show",1);

            $scope.modalViewTurn.cancelTurn = function(){
                var confirmPopup = $ionicPopup.confirm({
                title: 'Confirmar',
                template: '¿Está seguro que desea ' + popupMessage + ' este turno?'
            });

            confirmPopup.then(function(res){
                if(res){
                    if($scope.events[position].status == "confirmed") {
                        TurnsSvc.cancelTurn($scope.events[position].id).then(
                            function(response){
                                getTurns();
                                AnalyticsSvc.trackEvent("Calendar","Turn","Delete",1);
                            }
                        );
                    }else {
                        TurnsSvc.confirmTurn($scope.events[position].id).then(
                            function(response){
                                getTurns();
                                AnalyticsSvc.trackEvent("Calendar","Turn","Delete",1);
                            }
                        );
                    }

                    $scope.closeModalViewTurn();
                    UtilsSvc.showPopup("Turno cancelado",2000);
                }
            });
        };

            $scope.modalViewTurn.show();
            myApply();
        };

        $scope.closeModalViewTurn = function(){
            $scope.modalViewTurn.hide();
        };


        /* ==== Apply.
        ===================================================== */

        function myApply(){
            if($scope.$root && $scope.$root.$$phase != '$apply' && $scope.$root.$$phase != '$digest')
                $scope.$apply();
        }

        /**
         * Render events by fields one by one
         * @param  {Array} fields list of fields
         * @param  {Number} idField id field wich starts to cout
         * @param  {Date} date
         * @param  {Numbre} totalFields Length of fiels
         * @return {*}
         */
        function getEventsByField(fields,idField,date,totalFields){
            FieldsSvc.getEventsByField(fields[idField]._id,date).then(function(data){

            var newData = [];
            for(var i=0; i<data.length; i++){
                var startDate = new Date((data[i].from));
                var endDate = new Date((data[i].to));
                var end = HoursSvc.getPosition(UtilsSvc.strExtendedHourFromDate(endDate));
                var color = 'rgba(0, 157, 151, 0.75)';
                if(data[i].isSticky){
                    color = "#008800";
                }else if(data[i].createdFrom == 2){
                    color = "#FF8A66";
                }

                var turnObject = {
                    position: i,
                    id: data[i].id,
                    ground: data[i].ground,
                    idGround: data[i].ground._id,
                    positionField: idField,
                    eventname: data[i].userName,
                    phone: data[i].phone,
                    from: parseInt(UtilsSvc.strExtendedHourFromDate(startDate).replace(':','')),
                    starthour: UtilsSvc.strExtendedHourFromDate(startDate),
                    startPosition: HoursSvc.getPosition(UtilsSvc.strExtendedHourFromDate(startDate)),
                    endhour: UtilsSvc.strExtendedHourFromDate(endDate),
                    endPosition: (end  == null) ? 24 : end,
                    color: color,
                };
                newData.push(turnObject);
                FieldsSvc.addEventToField(turnObject,idField);
            }

            newData = calculateTopEvents(newData);
            newData = calculateLeftEvents(newData);
            newData = calculateHeightEvents(newData);

            $scope.fields[idField].events = newData;
            $scope.fields[idField].loaded = true;
            for (var i = 0; i < newData.length; i++) {
                $scope.events.push(newData[i]);
            };

            idField = idField+1;
            if(idField == totalFields){
                $scope.messageState = "";
                return;
            }
            getEventsByField(fields,idField,date,totalFields);
        },function(err){
            UtilsSvc.showPopup(err,2000);
        });
        }

        /* ==== View turn.
        ===================================================== */

        function getTurns(){

            $scope.messageState = "Cargando...";
            FieldsSvc.getAll(dateAll).then(
                function(grounds){
                    $scope.fields = grounds;
                    $ionicLoading.hide();
                    $scope.$broadcast('scroll.refreshComplete');
                    $scope.loading = false;
                    calculateWidth();
                    $scope.messageState = "";
                },
                function(error){
                    $ionicLoading.hide();
                    $scope.$broadcast('scroll.refreshComplete');
                    $scope.loading = false;
                    $scope.messageState = "";
                    UtilsSvc.showPopup(error,2000);
                }
            );
        }

        $scope.doRefresh = function(){
            getTurns();
        }

        function calculateWidth(){
        widthAux = ($window.innerWidth - 45) / $scope.fields.length;
        $scope.width = parseInt((widthAux > 40) ? widthAux : 40);
        switch ($scope.fields.length){
            case 1:
            //$scope.width-= 0;
            break;
            case 2:
            //$scope.width-= 3;
            break;
            case 3:
            //$scope.width-= 1;
            break;
            case 4:
            //$scope.width-= 1.5;
            break;
            case 5:
            //$scope.width-= 1;
            break;
            case 6:
            //$scope.width-= 0.5;
            break;
            case 7:
            $scope.width-= 1;
            break;
            case 8:
            //$scope.width-= 0;
            break;
            default:
            break;
        }
        $scope.widthScreen = $window.innerWidth;
        }

        $scope.goForward = function _GoForward(){
            var prevDay = $stateParams.date.split('-');
            var nextDate = sumaFecha(1,new Date(prevDay[0],prevDay[1]-1,prevDay[2]));
            $state.go(
                'app.turnsDay',
                {date: nextDate}
            );
        };


        $scope.goBack = function _goBack(){
            var prevDay = $stateParams.date.split('-');
            var nextDate = sumaFecha(-1,new Date(prevDay[0],prevDay[1]-1,prevDay[2]));
            $state.go(
                'app.turnsDay',
                {date: nextDate}
            );
        };




        /**
         * Suma 1 dia a una fecha
         * @param fecha
         * @returns {string}
         */
        function sumaFecha(day,fecha){
            var datePlus1 = fecha.getTime();
            var miliseconds = datePlus1+ (86400000 * day);
            var newDate = new Date(miliseconds);
            var anno=newDate.getFullYear();
            var mes= newDate.getMonth()+1;
            var dia= newDate.getDate();
            mes = (mes < 10) ? ("0" + mes) : mes;
            dia = (dia < 10) ? ("0" + dia) : dia;
            var fechaFinal = anno+"-"+mes+"-"+dia;
            return (fechaFinal);
        }

  }]);
