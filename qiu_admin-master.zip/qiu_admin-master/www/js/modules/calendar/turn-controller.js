controllers.controller('TurnCtrl', [
  '$scope',
  '$stateParams',
  'AnalyticsSvc',
  'TurnsSvc',
  function($scope, $stateParams,AnalyticsSvc,TurnsSvc){

  AnalyticsSvc.trackView("Turn Detail");

  var idTurn = $stateParams.idTurn;

  $scope.turn = {};

  TurnsSvc.getTurn(idTurn).then(function(data){
    if(data.code !== 200){
      return;
    }

    $scope.turn = data.result;
    var d = new Date(data.result.date.from);
    $scope.turn.hour = d.getDate()+"/"+(d.getMonth()+1)+" - "+d.getHours()+" hs";

  },function(err){
    console.log(err);
  });

  // $scope.day = '2015-10-26';
  // $scope.field = 'Cancha de 5';
  // $scope.start = '18:00';
  // $scope.end = '19:00';
  // $scope.client = 'Pepito';
  // $scope.phone = 123456789;

}]);
