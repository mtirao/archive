controllers.controller('CalendarCtrl', [
    '$rootScope',
    '$scope',
    '$state',
    'DateSvc',
    'MonthSvc',
    'AnalyticsSvc',
    'UtilsSvc',
    'LocalStorageSvc',
    function ($rootScope, $scope, $state, DateSvc, MonthSvc, AnalyticsSvc,UtilsSvc,LocalStorageSvc){


        AnalyticsSvc.trackView("Month Calendar View");

        //UtilsSvc.showPopup("Complete los campos",2000);

        if(!window.cordova || !window.cordova.plugins){

        }

        if(LocalStorageSvc.getObject('sportcenter')) {
            $rootScope.sportcenter = true;
        }

        $scope.options = {
            defaultDate: new Date(),
            disableAllPastDay: false,
            dayNamesLength: 2,
            mondayIsFirstDay: false,
            disabledDates: [],
            eventClick: function(date){
            goDay(date);
            AnalyticsSvc.trackEvent("Calendar","Month","EventClick",1);
            },
            dateClick: function(date){
            goDay(date);
            AnalyticsSvc.trackEvent("Calendar","Month","DateClick",1);
            },
            changeMonth: function(month, year){
            $scope.events = monthTurns(year + '-' + month.index);
            AnalyticsSvc.trackEvent("Calendar","Month","ChangeMonth",1);
            }
        };

        $scope.events = [];

        monthTurns(DateSvc.currentYearMonth());

        function goDay(date){

            $state.selectedDate = date

            $state.go(
                'app.turnsDay',
                {date: DateSvc.toString(date)}
            );
        }

        function monthTurns(date){
            MonthSvc.getTurnMonth(date).then(
                function(data){
                    $scope.events = data;
                },
                function(error){
                    UtilsSvc.showPopup(error,2000);
                    $scope.events = [];
                }
            );
        }

}]);
