
controllers.controller('GroundCtrl', [
  '$scope',
  '$ionicPopup',
  '$ionicListDelegate',
  '$ionicLoading',
  'FieldsSvc',
  'AnalyticsSvc',
  'UtilsSvc',
  function ($scope, $ionicPopup, $ionicListDelegate, $ionicLoading, FieldsSvc,AnalyticsSvc,UtilsSvc){

    AnalyticsSvc.trackView("Ground View");

    if(!window.cordova || !window.cordova.plugins){

    }


    $scope.types = [];

    FieldsSvc.types().then(
        function(data){
            console.log(data);
            $scope.types = data.types;
        },
        function(error){
            UtilsSvc.showPopup(error,2000);
        }
    );


    /* ==== Get all fields.
    ===================================================== */

    $ionicLoading.show({template: 'Cargando...'});

    FieldsSvc.getAll().then(
        function(data){
            $ionicLoading.hide();
            $scope.items = data;
        },
        function(error){
            $ionicLoading.hide();
            $scope.items = null;
            UtilsSvc.showPopup(error,2000);
        }
    );


    /* ==== Create a new field.
    ===================================================== */

    $scope.new = function(){

        AnalyticsSvc.trackEvent("Ground","New","ShowPopup",1);
        $scope.data = {};

        var template = '<div class="mb-10"><label for="tn_name">Nombre</label><input id="tn_name" type="text" ng-model="data.name" /></div>';
        template += '<div><label for="tn_types">Tipo</label><select for="tn_types" ng-model="data.type" ng-options="obj._id as obj.name for obj in types"></select></div>';

        $ionicPopup.show({
            template: template,
            title: 'Cancha',
            subTitle: 'Crear',
            scope: $scope,
            buttons: [
                {
                    text: 'Cancelar',
                    onTap: function(e){
                        return null;
                    }
                },
                {
                    text: 'Crear',
                    type: 'button-positive',
                    onTap: function(e){
                        if(!$scope.data.name || !$scope.data.type){
                            UtilsSvc.showPopup("Completar los campos",2000);
                            e.preventDefault();
                        }
                        else{
                            return {
                                'name': $scope.data.name,
                                'type': $scope.data.type
                            };
                        }
                    }
                }
            ]
        })
        .then(function(response){
            if(response){
                FieldsSvc.insert(response.name, response.type).then(
                    function(data){
                      UtilsSvc.showPopup(data,2000);
                      AnalyticsSvc.trackEvent("Ground","Insert","Success",1);
                    },
                    function(error){
                      UtilsSvc.showPopup(error,2000);
                      AnalyticsSvc.trackEvent("Ground","Insert","Error",0);
                    }
                );
            }
        });
    };

    /* ==== Edit a field.
    ===================================================== */

    $scope.edit = function(id, name, position){
        $ionicListDelegate.closeOptionButtons();

        $scope.data = {
            name: name,
            //type: $scope.items[position].type._id
        };

        var template = '<div class="mb-10"><label for="tn_name">Nombre</label><input id="tn_name" type="text" ng-model="data.name" /></div>';
        template += '<div><label for="tn_types">Tipo</label><select for="tn_types" ng-model="data.type" ng-options="obj._id as obj.name for obj in types"></select></div>';
        template += '<div class="mb-10"><label for="tn_name">Precio</label><input id="tn_name" type="text" ng-model="data.price" /></div>';
        template += '<div class="mb-10"><label for="tn_name">Reserva</label><input id="tn_name" type="text" ng-model="data.fee" /></div>';

        AnalyticsSvc.trackEvent("Ground","Edit","ShowPopup",1);

        $ionicPopup.show({
            template: template,
            title: 'Cancha',
            subTitle: 'Editar',
            scope: $scope,
            buttons: [
                {
                    text: 'Cancelar',
                    onTap: function(){
                        return null;
                    }
                },
                {
                    text: 'Guardar',
                    type: 'button-positive',
                    onTap: function(e){
                        if(!$scope.data.name || !$scope.data.type){
                            UtilsSvc.showPopup("Completar los campos",2000);
                            e.preventDefault();
                        }
                        else{
                            return {
                                'name': $scope.data.name,
                                'type': $scope.data.type,
                                'fee' : $scope.data.fee,
                                'price' : $scope.data.price
                            };
                        }
                    }
                }
            ]
        })
        .then(function(response){
            if(response != null){
                FieldsSvc.update(id, response.name, response.type, response.fee, response.price).then(
                    function(data){
                        UtilsSvc.showPopup(data,2000);
                      AnalyticsSvc.trackEvent("Ground","Edit","Success",1);
                    },
                    function(error){
                        UtilsSvc.showPopup(error,2000);
                      AnalyticsSvc.trackEvent("Ground","Edit","Error",0);
                    }
                );
            }
        });
    };

    /* ==== Remove a field.
    ===================================================== */

    $scope.remove = function(id, position){
        $ionicListDelegate.closeOptionButtons();

        AnalyticsSvc.trackEvent("Ground","Delete","OpenPopup",1);
        var confirmPopup = $ionicPopup.confirm({
            title: 'Confirmar',
            template: '¿Está seguro que desea eliminar esta cancha?'
        });

        confirmPopup.then(function(res){
            if(res){
                FieldsSvc.delete(id, position).then(
                    function(data){
                        UtilsSvc.showPopup(data,2000);
                      AnalyticsSvc.trackEvent("Ground","Delete","success",1);
                    },
                    function(error){
                        UtilsSvc.showPopup(error,2000);
                      AnalyticsSvc.trackEvent("Ground","Delete","Error",0);
                    }
                );
            }
        });
    };

    /* ===================================================== */

    $scope.moveItem = function(item, fromIndex, toIndex){
        $scope.items.splice(fromIndex, 1);
        $scope.items.splice(toIndex, 0, item);
    };
}])


/* ==== Directive.
===================================================== */

.directive('closeOption', [
    '$ionicGesture',
    '$ionicListDelegate',
    function ($ionicGesture, $ionicListDelegate){
    return {
        restrict: 'A',
        link: function(scope, elem, attrs){
            $ionicGesture.on(
                'touch',
                function(e){
                    $ionicListDelegate.closeOptionButtons();
                },
                elem
            );
        }
    };
}]);
