controllers.controller('AccessCtrl', [
  '$scope',
  '$rootScope',
  '$state',
  '$cordovaNetwork',
  'ConnectSvc',
  'AnalyticsSvc',
  'AccessSvc',
  'PushSvc',
  'UtilsSvc',
  'SportcenterSvc',
  function ($scope, $rootScope, $state, $cordovaNetwork, ConnectSvc,AnalyticsSvc,AccessSvc,PushSvc,UtilsSvc, SportcenterSvc){

    $scope.user = {};
    noSending();

    // $scope.buttons = {
    //   watchPassword: function(){
    //   console.log("aca");
    //   $scope.typePass = "text";

    //   }
    // };

    $scope.typePass = "password";

    AnalyticsSvc.trackView("Login View");
    /* ==== Login.
     ===================================================== */

    $scope.login = function(){

      if(!window.cordova || !window.cordova.plugins){
        access();
        return;
      }

      var cont = false;

      if (typeof($cordovaNetwork) !== 'undefined' ) {
        console.log("Cordova network undefined");
        cont = true;
      }else {
        cont = $cordovaNetwork.isOnline()
      }

      debugger;

      if(cont){
        if(!$scope.user.email || !$scope.user.password){
          UtilsSvc.showPopup("Complete los campos",2000);
          AnalyticsSvc.trackEvent("Access","Login","ConnectValidate",0);
        }else if($scope.user.email.length < 7){
          UtilsSvc.showPopup("Email corto (mín 7)",2000);
          AnalyticsSvc.trackEvent("Access","Login","ConnectValidate",0);
        }else if($scope.user.password.length < 6){
          UtilsSvc.showPopup("Clave corta (mín 6)",2000);
          AnalyticsSvc.trackEvent("Access","Login","ConnectValidate",0);
        }else{
          access();
        }
      }
      else
        UtilsSvc.showPopup("No hay conexión a internet",2000);
    };


    /* ==== Call service to access.
     ===================================================== */

    function access(){

      console.log("Login function5");

      sending();

      ConnectSvc.login($scope.user.phone, $scope.user.password).then(

        function(user){

            if(!user.token) {
                AnalyticsSvc.trackEvent("Access","Login","Error",0);
                return;
            }

            $rootScope.admin = ( user.roles != "admin" );

            AnalyticsSvc.setUserId(user.token);

            var today = new Date();

            noSending();

            AccessSvc.updateDevice(function(){
                PushSvc.register();
            });

            if(user.roles == "admin") {

                $state.go('app.sportcenterAdmin');
            }else {
                SportcenterSvc.get().then(function(data){
                    $rootScope.sportcenter = true;
                    $state.go(
                        'app.turnsDay',
                        { 'date': today.getFullYear() + '-' + (today.getMonth()+1) + '-' + today.getDate() }
                    );

                }).catch(function(error){

                    $state.go('app.reservations');
                })
            }

            AnalyticsSvc.trackEvent("Access","Login","ConnectSuccess",1);
        },
        function(error){
          noSending();
          UtilsSvc.showPopup(error,2000);
          AnalyticsSvc.trackEvent("Access","Login","ConnectError",0);
        }
      );
    }


    /* ==== Sending.
     ===================================================== */

    function noSending(){
      $scope.sending = false;
      $scope.button = 'Acceder';
    }

    function sending(){
      $scope.sending = true;
      $scope.button = 'conectando..';
    }

    $scope.watchPassword = function(){
      if($scope.typePass == "password"){
        $scope.typePass = "text";
        $scope.activatedButton = true;
      }else{
        $scope.typePass = "password";
        $scope.activatedButton = false;
      }

    }

  }]);
