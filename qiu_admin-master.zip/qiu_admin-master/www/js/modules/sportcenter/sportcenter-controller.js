controllers.controller('SportcenterCtrl', [
    '$scope',
    '$rootScope',
    '$ionicPopup',
    '$cordovaGeolocation',
    'SportcenterSvc',
    'ConfigSvc',
    '$window',
    '$timeout',
    'AnalyticsSvc',
    'UtilsSvc',
    'FieldsSvc',
    'LocalStorageSvc',
  function($scope, $rootScope, $ionicPopup, $cordovaGeolocation, SportcenterSvc, ConfigSvc, $window, $timeout,AnalyticsSvc,UtilsSvc, FieldsSvc, LocalStorageSvc){

    AnalyticsSvc.trackView("Sportcenter View");

    // ==== Variables.
    // ==========================================================

    var myMap, marker, latLng;

    $scope.height = parseInt($window.innerHeight * 0.28) + 'px';
    noSending();

    if(LocalStorageSvc.getObject('sportcenter')) {
        $rootScope.sportcenter = true;
    }


    // ==== Hours.
    // ==========================================================

    $scope.hours = [];
    for(var i=10; i<=23; i++){
        if(i<10) $scope.hours.push('0' + i + ':00');
        else $scope.hours.push(i + ':00');
    }


    $scope.types = [];

    FieldsSvc.types().then(
        function(data){
            console.log(data);
            $scope.types = data.types;
        },
        function(error){
            UtilsSvc.showPopup(error,2000);
        }
    );

    // ==== Info.
    // ==========================================================

    $scope.config = {};

     /* ==== Create a new field.
    ===================================================== */

    $scope.$on('$ionicView.enter', function() {

        if($scope.config.coordinates) {
            loadMap($scope.config.coordinates.lat, $scope.config.coordinates.lng);
        }else{

            var geoOptions = {timeout: 10000, enableHighAccuracy: true};

            SportcenterSvc.get().then(
                function(data){
                    $rootScope.admin = true;
                    $scope.config = data;

                    loadMap(data.coordinates.lat, data.coordinates.lng);

                }
            ).catch(function(error){

                $cordovaGeolocation.getCurrentPosition(geoOptions).then(function(position){

                    updateMap(position.coords.latitude, position.coords.longitude);
                    
                }, function(error){
                    console.log("Could not get location");
                    var lat = -34.6037502;
                    var lon = -58.3904428
                    updateMap(lat, lon);

                });

            })

        }
    });

    function updateMap(lat, lng) {
        
        loadMap(lat, lng);

        if($rootScope.admin && $rootScope.admin != true) {
            SportcenterSvc.getById($rootScope.sportcenterId).then(function(data){

                LocalStorageSvc.setObject('sportcenter', data);

                data.openAt = data.openAt + ":00";
                data.closeAt = data.closeAt + ":00";
                data.phone = data.mobile;

                $scope.config = data;


                addLocationMarker(data.location[0], data.location[1], data.name, data.status);

            }).catch(function(error) {
                UtilsSvc.showPopup("Sportcenter invalido",2000);
            })
        }
    }


    // ==== Save.
    // ==========================================================

    function validate(){

        if(!$scope.config.name){
            UtilsSvc.showPopup("Completar nombre",2000);
            return false;
        }
        if(!$scope.config.address){
            UtilsSvc.showPopup("Completar direccion",2000);
            return false;
        }
        if(!$scope.config.phone){
            UtilsSvc.showPopup("Completar teléfono",2000);
            return false;
        }
        if(!$scope.config.about){
            UtilsSvc.showPopup("Completar descripción",2000);
            return false;
        }

        if(!$scope.config.email) {
            UtilsSvc.showPopup("Completar email",2000);
            return false;
        }else {
            var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            if(!re.test($scope.config.email)) {
                UtilsSvc.showPopup("Completar email con una direccion válida",2000);
                return false;
            }
        }

        return true;
    }

    function sending(){
        $scope.button = 'Guardando..';
        $scope.sending = true;
    }

    function noSending(){
        $scope.button = 'Guardar';
        $scope.sending = false;
    }

    $scope.updateConfig = function(){

        var status = "new";
        if(!$rootScope.admin) {
            status = "confirmed";
        }else if(!validate()) {
            return;
        }

        var update = {
            name: $scope.config.name,
            address: $scope.config.address,
            phone: $scope.config.phone,
            description: $scope.config.about,
            location: [$scope.config.coordinates.lat, $scope.config.coordinates.lng],
            openAt : $scope.config.openAt,
            closeAt :  $scope.config.closeAt,
            email : $scope.config.email,
            status: status,
            login: LocalStorageSvc.getObject('user').token
        };

        sending();

        
        SportcenterSvc.update(update).then(
            function(data){
                UtilsSvc.showPopup("Guardado",2000);
                $rootScope.sportcenter = true;
                noSending();
                AnalyticsSvc.trackEvent("Profile","Update","Success",1);
            },
            function(error){
                UtilsSvc.showPopup(error,2000);
                AnalyticsSvc.trackEvent("Profile","Update","Error",0);
                noSending();
            }
        );
       
    };


    // ==== Google Maps.
    // ==========================================================
    function loadMap(lat, lon){
        var latLng = new google.maps.LatLng(lat,lon);
        lastCenter = latLng;

        var mapOptions = {
            center: latLng,
            zoom: 13,
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            disableDefaultUI: true,
            draggable: true
        };
        $scope.map = new google.maps.Map(document.getElementById("google-map"),mapOptions);

        firstCenter = $scope.map.getCenter();

        var marker = new google.maps.Marker({
            map: $scope.map,
            animation: google.maps.Animation.DROP,
            position: latLng
        });

        $scope.config.coordinates = {lat : lat, lng: lon};

        //$scope.config.coordinates.lat = lat;
        //$scope.config.coordinates.lng = lon;

        var infoWindow = new google.maps.InfoWindow({
            content: "Here I am!"
        });

        google.maps.event.addDomListener(marker, 'click', function () {
            infoWindow.open($scope.map, marker);
        });

        mapaInit = true;

        google.maps.event.addDomListener($scope.map, 'click', function(ev){
            // Stop propagation
            ev.cancelBubble = true;
            ev.stopPropagation && ev.stopPropagation();
            ev.preventDefault && ev.preventDefault();
            ev.stop();

            // Set marker and center map
            latLng = new google.maps.LatLng(ev.latLng.lat(), ev.latLng.lng());
            marker.setPosition(latLng);
            $scope.config.coordinates.lat = ev.latLng.lat();
            $scope.config.coordinates.lng = ev.latLng.lng();

            return false;
        });
    }


    function addLocationMarker(lat,lon, name, status) {
        var latLng = new google.maps.LatLng(lat,lon);
        lastCenter = latLng;

        $scope.config.coordinates = {lat: lat, lng: lon};


        var marker = new google.maps.Marker({
            map: $scope.map,
            animation: google.maps.Animation.DROP,
            position: latLng,
            icon: 'img/icon-map-pin-green.png',
        });

        if(status == "new") {
            marker.icon = 'img/icon-map-pin-red.png';
        }else if(status == "in progress") {
            marker.icon = 'img/icon-map-pin-yellow.png';
        }

        var infoWindow = new google.maps.InfoWindow({
            content: name
        });

        google.maps.event.addDomListener(marker, 'click', function () {
            infoWindow.open($scope.map, marker);
        });

        $scope.map.setCenter(latLng);
    }


    /* ==== Create a new field.
    ===================================================== */

    $scope.new = function(){

        AnalyticsSvc.trackEvent("Ground","New","ShowPopup",1);
          $scope.data = {};

          var template = '<div class="mb-10"><label for="tn_name">Nombre</label><input id="tn_name" type="text" ng-model="data.name" /></div>';
          template += '<div><label for="tn_types">Tipo</label><select for="tn_types" ng-model="data.type" ng-options="obj._id as obj.name for obj in types"></select></div>';
          template += '<div class="mb-10"><label for="tn_name">Precio</label><input id="tn_name" type="text" ng-model="data.price" /></div>';
          template += '<div class="mb-10"><label for="tn_name">Reserva</label><input id="tn_name" type="text" ng-model="data.fee" /></div>';

          $ionicPopup.show({
              template: template,
              title: 'Cancha',
              subTitle: 'Crear',
              scope: $scope,
              buttons: [
                  {
                      text: 'Cancelar',
                      onTap: function(e){
                          return null;
                      }
                  },
                  {
                      text: 'Crear',
                      type: 'button-positive',
                      onTap: function(e){
                          if(!$scope.data.name || !$scope.data.type){
                              UtilsSvc.showPopup("Completar los campos",2000);
                              e.preventDefault();
                          }
                          else{
                              return {
                                  'name': $scope.data.name,
                                  'type': $scope.data.type,
                                  'fee' : $scope.data.fee,
                                  'price' : $scope.data.price
                              };
                          }
                      }
                  }
              ]
          })
          .then(function(response){
              if(response){
                  FieldsSvc.insert(response.name, response.type, response.fee, response.price).then(
                      function(data){
                        $rootScope.sportcenter = true;
                        UtilsSvc.showPopup(data,2000);
                        AnalyticsSvc.trackEvent("Ground","Insert","Success",1);
                      },
                      function(error){
                        UtilsSvc.showPopup(error,2000);
                        AnalyticsSvc.trackEvent("Ground","Insert","Error",0);
                      }
                  );
              }
          });
      };

}]);
