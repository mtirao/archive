controllers.controller('SportcenterAdminCtrl', [
    '$scope',
    '$rootScope',
    '$state',
    'SportcenterSvc',
    'AnalyticsSvc',
    'UtilsSvc',

  function($scope, $rootScope, $state, SportcenterSvc, AnalyticsSvc, UtilsSvc){

    AnalyticsSvc.trackView("Sportcenter Admin View");

    SportcenterSvc.getAll().then(
        function(data){
            var items = [];

            for(var i = 0; i < data.length; i++) {
                var item = data[i];
                if(item.status == "confirmed") {
                    item.icon = "ion-ios-football";
                }else {
                    item.icon = "";
                }
                items.push(item);
            }
            $scope.items = items;
        },
        function(error){
            $scope.items = null;
            UtilsSvc.showPopup(error,2000);
        }
    );

    $scope.edit = function(id, name, position){

        $rootScope.admin = false;
        $rootScope.sportcenterId = id;
        $state.go('app.sportcenter');

    }


}]);
