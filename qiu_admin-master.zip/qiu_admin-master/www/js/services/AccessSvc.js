services.factory('AccessSvc', [
  "$http",
  "$q",
  "ENV",
  function($http,$q,ENV) {

    var access = {};

    /**
     * Get user by device id
     * @returns {*}
     */
    access.updateDevice = function(cb){
        var deferred = $q.defer();

        var isIOS = ionic.Platform.isIOS();
        var isAndroid = ionic.Platform.isAndroid();
        var platform = "";

        if(isAndroid){
          platform = "android";
        }else if(isIOS){
          platform = "ios";
        }else {
          platform = "web";
        }



        if(!window.localStorage["user"]){
          cb();
          deferred.reject('Error');
          return deferred.promise;
        }

        var idAdmin = JSON.parse(window.localStorage["user"]).token;

        $http.put(ENV.http + '/api/v2/profile/' + idAdmin, {
          "device":platform
        })
        .success(function(data){
            cb();
            deferred.resolve(data);
        })
        .error(function(err){
            deferred.reject('Error');
        });

        return deferred.promise;
    };

    return access;
  }]);
