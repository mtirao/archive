services.factory('ConnectSvc', function($http, $q, ENV, LocalStorageSvc, ConfigSvc){

    var response = {};

    response.login = function(phone, password){
        var deferred = $q.defer();

        $http({
            method: 'POST',
            url: ENV.http + '/api/v2/authorize',
            data: {
                phone: phone,
                password: password
            }
        })
        .success(function(data){
                LocalStorageSvc.set('logged', 'yes');
                LocalStorageSvc.setObject('user', {
                    'token': data.token
                });

                ConfigSvc.update({});

                deferred.resolve(data);
        })
        .error(function(data){
            if(data.error) {
                deferred.reject(data.error);
            }else {
                deferred.reject("Network Error");
            }
        });

        return deferred.promise;
    };

    return response;

});
