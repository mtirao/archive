services.factory('NotificationsSvc', [
'$rootScope', '$q', 'ENV', '$http', 'LocalStorageSvc', 'HoursSvc', 'TurnsSvc', 'UtilsSvc','$timeout',
    function($rootScope, $q, ENV, $http, LocalStorageSvc, HoursSvc, TurnsSvc, UtilsSvc,$timeout) {

    var fields = [];
    var returnObj = {};
    var events = [];

    var n = 0;


    /* ==== Get all Notifications.
    ===================================================== */

    returnObj.getAll = function(date){
        events = [];
        var deferred = $q.defer();
        TurnsSvc.turns = [];
        var promiseTimeout = $timeout(function(){
            deferred.reject("Timed out");
        }, 7500);

        $http({
            method: 'GET',
            url: ENV.http + '/api/v2/message/' + LocalStorageSvc.getObject('user').token
        })
        .success(function(data){

            $timeout.cancel(promiseTimeout);
            deferred.resolve(data);
        })
        .error(function () {
            $timeout.cancel(promiseTimeout);
            deferred.reject('Error');
        });

        return deferred.promise;
    };

    /* ==== Insert field.
    ===================================================== */

    returnObj.insert = function(title, message){
        var deferred = $q.defer();

        $http({
            method: 'POST',
            url: ENV.http + '/api/v2/message',
            data: {

                from: LocalStorageSvc.getObject('sportcenter')._id,
                to: "support",
                type : "message",
                status: "new",
                title: title,
                message : message,
            }
        })
        .success(function(data){

            returnObj.getAll();

            deferred.resolve('Mensaje enviado');
        })
        .error(function (data) {
            deferred.reject(data.error);
        });

        return deferred.promise;
    };


    /* ==== Delete field.
    ===================================================== */

    returnObj.delete = function(id, position){
        var deferred = $q.defer();

        $http({
            method: 'DELETE',
            url: ENV.http + '/api/v2/message/' + id
        })
        .success(function (data) {
            deferred.resolve('Mensaje eliminado');
        })
        .error(function (error) {
            deferred.reject(error);
        });

        return deferred.promise;
    };


    /* ==== Update field.
    ===================================================== */

    returnObj.update = function(id, name, typeId, feeVal, priceVal){
        var deferred = $q.defer();

        $http({
            method: 'PUT',
            url: ENV.http + '/api/V2/ground/' + id,
            data: {
                groundId: id,
                ground: {
                    name: name,
                    type: typeId,
                    fee: feeVal,
                    price: priceVal
                }
            }
        })
        .success(function(data){


            returnObj.getAll().then(
                function () {
                    deferred.resolve('Cancha editada');
                },
                function (data) {
                    deferred.reject(data.error);
                }
            );
    })
        .error(function (data) {
            deferred.reject(data.error);
        });

        return deferred.promise;
    };




    /* ==== Response.
    ===================================================== */

    return returnObj;

}]);
