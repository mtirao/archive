services.factory('TurnsSvc', [
    '$q', 'ENV', 'LocalStorageSvc', '$http','$timeout',
    function($q, ENV, LocalStorageSvc, $http,$timeout){

    var returnObj = {};
    returnObj.turns = [];

    function convertDate(date, time) {
        var convertedDate = new Date();

        convertedDate.setFullYear(date.getFullYear(), date.getMonth(), date.getDate())
        convertedDate.setUTCHours(time.getUTCHours());
        convertedDate.setUTCMinutes(time.getUTCMinutes());
        convertedDate.setUTCSeconds(0);
        convertedDate.setUTCMilliseconds(0);

        return convertedDate;
    }

    /* ==== GET.
     ===================================================== */
    returnObj.getForDate = function(idGround, date){
        var turns = [];
        var deferred = $q.defer();

        var promiseTimeout = $timeout(function(){
            deferred.reject("Timed out");
        },7500);

        $http({
            method: 'GET',
            url: ENV.http + '/api/v2/turn/sportcenter/' + LocalStorageSvc.getObject('user').token + '?groundId=' + idGround + '&date=' + date
        })
        .success(function(data){


            for(var i=0; i<data.length; i++){
                var parseTurnObject = {
                    id: data[i]._id,
                    ground: data[i].ground,
                    userName: data[i].name,
                    phone: data[i].phone,
                    from: data[i].from,
                    to: data[i].to,
                    status: data[i].status,
                    isSticky: data[i].isSticky
                };
                turns.push(parseTurnObject);
            }
            $timeout.cancel(promiseTimeout);
            deferred.resolve(turns);
        })
        .error(function(){
            $timeout.cancel(promiseTimeout);
            deferred.reject('Error');
        });

        return deferred.promise;
    };


    /* ==== New.
    ===================================================== */
    returnObj.addTurn = function(turnObj){

        var deferred = $q.defer();

        var from = new Date();
        var to = new Date()

        if(turnObj.date && turnObj.time) {
            from = convertDate(turnObj.date, turnObj.time);
            var from = convertDate(turnObj.date, turnObj.time);
            to.setTime(from.getTime() + 3600000);

        } else {
            from = turnObj.from;
            to = turnObj.to;
        }

        var turn = {

            sportcenter: turnObj.sportcenter,
            name: turnObj.name,
            token: LocalStorageSvc.getObject('user').token,
            phone: turnObj.phone,
            sticky: false,
            from: from.toISOString(),
            to: to.toISOString(),
            type: turnObj.type,
            ground: turnObj.idGround,
            status: turnObj.status
        };


        $http({
            method: 'POST',
            url: ENV.http + '/api/v2/turn/',
            data: turn
        })
        .success(function(data){
            deferred.resolve({
                id: data._id,
                ground: data.ground,
                userName: data.name,
                phone: data.phone,
                from: data.from,
                to: data.to
            });
        })
        .error(function(error){
            deferred.reject(error);
        });

        return deferred.promise;
    };


    /* ==== Cancel.
    ===================================================== */

    returnObj.cancelTurn = function(idTurn){
        var deferred = $q.defer();

        $http({
          method: 'DELETE',
          url: ENV.http + '/api/v2/turn/' + idTurn,
        })
        .success(function(data){
            deferred.resolve('Turno Cancelado');
        })
        .error(function(){
            deferred.reject('Error');
        });

        return deferred.promise;
    };

    returnObj.confirmTurn = function(idTurn){
        var deferred = $q.defer();

        $http({
          method: 'PUT',
          url: ENV.http + '/api/v2/turn/' + idTurn,
          data: {status: "confirmed"}
        })
        .success(function(data){
            deferred.resolve('Turno confirmado');
        })
        .error(function(error){
            deferred.reject('El turno no pudo ser confirmado');
        });

        return deferred.promise;
    };

    /* ==== Get turn.
    ===================================================== */

    returnObj.getTurn = function(turnId){
        var deferred = $q.defer();

        $http({
          method: 'GET',
          url: ENV.http + '/api/v2/turn/' + turnId,
        })
        .success(function(data){
            deferred.resolve(data);
        })
        .error(function(){
            deferred.reject('El turno seleccionado ya no existe.');
        });

        return deferred.promise;
    };

    returnObj.getOtherTurn = function() {
        var deferred = $q.defer();

        $http({
            method: 'GET',
            url: ENV.http + '/api/v2/turn/owner/' + LocalStorageSvc.getObject('user').token + "?sportcenter=" + LocalStorageSvc.getObject('sportcenter')._id,
          })
          .success(function(data){
              if(!data){
                  deferred.reject('Error');
              }else{
                  deferred.resolve(data);
              }
          })
          .error(function(){
              deferred.reject('Error');
          });

          return deferred.promise;

    }


    /* ==== Response.
    ===================================================== */

    return returnObj;

}]);
