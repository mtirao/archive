services.factory('PushSvc', function($state, $ionicPopup, $rootScope, LocalStorageSvc, $ionicHistory, $cordovaPush, ConfigSvc,UtilsSvc){
    
  var response = {};
  var config = {};

  var isIOS = ionic.Platform.isIOS();
  var isAndroid = ionic.Platform.isAndroid();

  if(isAndroid){
    config.senderID = "365814209128";
  }

  if(isIOS){
    config.badge = true;
    config.sound = true;
    config.alert = true;
  }

  var pushNot = {
    register: function registerFn(){
    }
  };

  function saveRegId(regId){

    LocalStorageSvc.set('regId', regId);

    if(LocalStorageSvc.exist('user')){
      ConfigSvc.update({});
    }
  }

  function newTurn(idTurn){

    var confirmPopup = $ionicPopup.confirm({
      title: 'Nuevo',
      template: 'Han creado un turno desde la App, ¡miralo!'
    });

    confirmPopup.then(function(res){
      if(res)
        $state.go('app.turn', {'idTurn': idTurn});
    });
  }

  function bid(){
    // Puja
  }

  response.register = function(){
    $cordovaPush.register(config)
      .then(
      function(result){
        // Success
        if(isIOS){
          saveRegId(result);
        }
      },
      function(error){
        console.log(error);
      }
      );
    };
    
    function saveRegId(regId){
        LocalStorageSvc.set('regId', regId);
        
        if(LocalStorageSvc.exist('user'))
            ConfigSvc.update({});
    }
    
    function newTurn(idTurn){

        // if($ionicHistory.viewHistory().backView == null){
        //     $state.go('app.turn', {'idTurn': idTurn});
        //     return;
        // }
        
        var confirmPopup = $ionicPopup.confirm({
            title: 'Nuevo',
            template: 'Han creado un turno desde la App, ¡miralo!'
        });
        
        confirmPopup.then(function(res){
            if(res)
                $state.go('app.turn', {'idTurn': idTurn});
        });
    }
    
    function bid(){
        // Puja
    }
    
    response.register = function(){
        document.addEventListener("deviceready", function(){            
            // $cordovaPush.register({senderID: "365814209128"})
            $cordovaPush.register(config)
            .then(
                function(result){
                    console.log(result);

                    // Success
                    if(isIOS){
                      saveRegId(result);
                    }
                },
                function(error){
                    console.log(error);
                }
            );
        });
    }

    $rootScope.$on('$cordovaPush:notificationReceived', function(ev, data){

      if(isIOS){
        // if (notification.alert) {
          if(!data || !data.turnId){
            // UtilsSvc.showPopup(data.payload.message,2500);
            return;
          }
          newTurn(data.turnId);
        // }

        return;
      }

      switch(data.event){
        case 'registered':
          if(data.regid) saveRegId(data.regid);
          else console.log('Error register regid..');
          break;

        case 'message':

          if(!data.payload.turnId){
            UtilsSvc.showPopup(data.payload.message,2500);
            return;
          }

          newTurn(data.payload.turnId);
          break;

        case 'error':
          console.log('GCM error: ', data.msg);
          break;

        default:
          console.log('An unknown GCM event has occurred');
          break;
      }
    });

  return response;

});
