services.factory('MonthSvc', function ($q, $http, LocalStorageSvc, ENV, DateSvc){

    var response = {};

    response.getTurnMonth = function(date){
        var deferred = $q.defer();

        $http.get(ENV.http + '/api/v2/turn/sportcenter/' + LocalStorageSvc.getObject('sportcenter')._id + '?ignoreDay=true&date=' + date)
        .success(function (data) {
            deferred.resolve(parseResult(data,date));
        })
        .error(function(error){
            deferred.reject('Error');
        });

        return deferred.promise;
    };

    /**
     * parse result for make points events
     * @param data
     * @param date
     * @returns {Array}
     */
    function parseResult(data,date) {
        if(data.length <= 0){
            return [];
        }
        var events = [];
        for(var i=0; i<data.length; i++) {
          var dateObj = new Date(data[i].from);
          events.push({"date": dateObj});
        }

        return events;
    }


    return response;

});
