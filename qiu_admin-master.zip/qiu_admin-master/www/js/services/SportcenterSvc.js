services.factory('SportcenterSvc', function ($http, $q, ENV, LocalStorageSvc) {

    var response = {};

    response.get = function(){
        var deferred = $q.defer();

        $http.get(ENV.http + '/api/v2/sportcenter/mine/' + LocalStorageSvc.getObject('user').token)
        .success(function(data){
            

            if(data.sportcenters.length <= 0)
                deferred.reject('Error..');
            else{
                var sportcenter = data.sportcenters[0];

                deferred.resolve({
                    'name': (sportcenter.name) ? sportcenter.name : '',
                    'mobile': (sportcenter.mobile) ? sportcenter.mobile : '',
                    'about': (sportcenter.about) ? sportcenter.about : '',
                    'address': (sportcenter.address) ? sportcenter.address : '',
                    'coordinates': {
                        'lng': (sportcenter.longitude)?sportcenter.longitude:-68.834392,
                        'lat': (sportcenter.latitude)?sportcenter.latitude:-32.896126
                    },
                    'zoom': 16,
                    'email' : (sportcenter.email) ? sportcenter.email : '',
                    'openAt' : (sportcenter.openAt) ? (sportcenter.openAt + ":00" ): '9:00',
                    'endAt' : (sportcenter.endAt) ? (sportcenter.endAt + ":00"): '22:00',
                    'emailverify' : (sportcenter.emailverify) ? sportcenter.emailverify : false,
                    'mobileverify' : (sportcenter.mobileverify) ? sportcenter.mobileverify : false,
                    'feerequired' : (sportcenter.feerequired) ? sportcenter.feerequired : false
                });
            }
        })
        .error(function(){
            deferred.reject('Error');
        });

        return deferred.promise;
    };

    response.update = function(config){
        var deferred = $q.defer();

        config.pushId = LocalStorageSvc.get('regId');
        config.token = LocalStorageSvc.getObject('user').token

        $http.put(ENV.http + '/api/v2/sportcenter/' + LocalStorageSvc.getObject('user').token, config)
        .success(function(data){
            if(data.result !== "ok") deferred.reject('Error..');
            else deferred.resolve();
        })
        .error(function(){
            deferred.reject('Error');
        });

        return deferred.promise;
    };

    response.getAll = function(){
        var deferred = $q.defer();

        $http.get(ENV.http + '/api/v2/sportcenter/all' )
        .success(function(data){

            if(!data)
                deferred.reject(data.error);
            else{

                deferred.resolve(data);
            }
        })
        .error(function(){
            deferred.reject('Error');
        });

        return deferred.promise;
    };

    response.getById = function(id) {

        var deferred = $q.defer();

        $http.get(ENV.http + '/api/v2/sportcenter/byId/' + id )
        .success(function(data){

            if(!data)
                deferred.reject(data.error);
            else{

                deferred.resolve(data);
            }
        })
        .error(function(){
            deferred.reject('Error');
        });

        return deferred.promise;
    }

    return response;
});
