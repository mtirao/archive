services.factory('ConfigSvc', function ($http, $q, ENV, LocalStorageSvc) {

    var response = {};

    response.get = function(){
        var deferred = $q.defer();

        $http.get(ENV.http + '/api/v2/profile/' + LocalStorageSvc.getObject('user').token)
        .success(function(data){

            if(!data)
                deferred.reject(data.error);
            else{

                LocalStorageSvc.setObject('profile', data);

                deferred.resolve({
                    'name': (data.name) ? data.name : '',
                    'phone': (data.mobile) ? data.mobile : '',
                    'description': (data.about) ? data.about : '',
                    'address': (data.address) ? data.address : '',
                    'contact' : (data.email) ? data.email : '',
                });
            }
        })
        .error(function(){
            deferred.reject('Error');
        });

        return deferred.promise;
    };

    response.update = function(config){
        var deferred = $q.defer();

        config.pushId = LocalStorageSvc.get('regId');
        config.token = LocalStorageSvc.getObject('user').token

        $http.put(ENV.http + '/api/v2/profile/' + LocalStorageSvc.getObject('user').token, config)
        .success(function(data){
           deferred.resolve();
        })
        .error(function(error){
            deferred.reject('Su perfil no pudo ser guardado');
        });

        return deferred.promise;
    };

    response.changePassword = function(config) {
        var deferred = $q.defer();

        var user = LocalStorageSvc.getObject('user');

        var query = {
            token: user.token,
            oldPassword: config.password,
            newPassword: config.newPassword,
            newPassword1: config.newPassword1
        }

        $http.put(ENV.http + '/api/v2/authorize', query)
        .success(function(data){
            deferred.resolve('Su clave se ha actualizado');
        })
        .error(function(){
            deferred.reject('Error cambiando la clave. La clave no fue modificada');
        });

        return deferred.promise;
    }

    return response;
});
