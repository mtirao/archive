services.factory('ClientSettingsSvc', function() {
    return {
        clientSetting_startHour: 0,
        clientSetting_endHour: 23,
        clientSetting_usehalfhour: true
    };
});
