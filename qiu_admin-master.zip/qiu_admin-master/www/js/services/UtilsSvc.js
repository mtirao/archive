services
  .factory('UtilsSvc',["$ionicLoading", "$timeout",function($ionicLoading,$timeout){
    var response = {};

    response.strExtendedHourFromDate = function(date){
      if('0' + date.getHours() != '00'){
        return ('0' + date.getHours()).slice(-2) + ':' + ('0' + date.getMinutes()).slice(-2);
      }
      else{
        return ('0' + date.getHours()+24).slice(-2) + ':' + ('0' + date.getMinutes()).slice(-2);
      }
    };

    response.showPopup = function(message,time){
      time = time || 1500;
      $ionicLoading.show({template:message});
      $timeout(function(){
        $ionicLoading.hide();
      },time);
    };

    return response;
  }])

  .factory('ArraySvc', function(){
    var response = {};

    response.substraction = function(a, b){
      var c = [];

      for(var i=0; i<a.length; i++){
        if(b.indexOf(a[i]) == -1)
          c.push(a[i]);
      }

      return c;
    };

    return response;
  })

  .factory('DateSvc', function(){
    var response = {};

    response.toString = function(date){
      var aux = date.year + "-";
      aux += ((date.month < 9) ? ('0' + (date.month+1)) : (date.month+1)) + "-";
      aux += (date.day < 10) ? ('0' + date.day) : date.day;
      return aux;
    };

    response.date = function(date){
      var aux = date.getFullYear() + '-';
      aux += (date.getMonth() < 9) ? ('0' + (date.getMonth()+1)) : (date.getMonth()+1) + "-";
      aux += (date.getDate() < 10) ? ('0' + date.getDate()) : date.getDate();
      return aux;
    };

    response.today = function(){
      var today = new Date();
      var aux = today.getFullYear() + '-';
      aux += (today.getMonth() < 9) ? ('0' + (today.getMonth()+1)) : (today.getMonth()+1) + "-";
      aux += (today.getDate() < 10) ? ('0' + today.getDate()) : today.getDate();
      return aux;
    };

    response.currentYearMonth = function(){
      var today = new Date();
      return today.getFullYear() + '-' + (today.getMonth() + 1);
    };

    return response;
  })

  .factory('LocalStorageSvc', ['$window', function($window){
    var response = {};

    response.set = function set(key, value){
      $window.localStorage[key] = value;
    };
    response.get = function get(key, defaultValue){
      return $window.localStorage[key] || defaultValue;
    };
    response.setObject = function setObject(key, value){
      $window.localStorage[key] = JSON.stringify(value);
    };
    response.getObject = function getObject(key){
      return JSON.parse($window.localStorage[key] || '{}');
    };
    response.clear = function(key){
      $window.localStorage.clear(key);
    };
    response.exist = function(key){
      return ($window.localStorage[key]) ? true : false;
    };

    return response;
  }])

  .factory('HoursSvc', function(ClientSettingsSvc){


    var startHour = ClientSettingsSvc.clientSetting_startHour;
    var endHour = ClientSettingsSvc.clientSetting_endHour;
    var usehalfhour = ClientSettingsSvc.clientSetting_usehalfhour;

    var response = {};

    var hours = [];

    response.get = function(sportcenter){

        var start = sportcenter.openAt;
        var end = sportcenter.closeAt;

        if(hours.length <= 0){

            for(var i=start; i<=end; i++){

                hours.push(('0' + i).slice(-2)  + ':00');

                if(usehalfhour && i < end) {
                    hours.push(('0' + i).slice(-2) + ':30');
                }
            }
        }

        return hours;
    };

    response.getPosition = function(hour){

        if(hour == null){
            return hours.length-1;
        }else{
            for(var i=0; i<=hours.length ; i++){
                if(hours[i] == hour){
                    return i;
                }
            }
        }

        return null;
    };

    response.getPositionForList = function(hour,pickHour){
        if(hour == null){
            return hours.length-1;
        }else{
            for(var i=0; i<=hours.length ; i++){
                if(hours[i] == hour){
                    return i;
                }
            }
        }

        return null;
    };

    return response;
  });
