services.factory('LocationsSvc', function (ClientSettingsSvc){
    
    var startHour = ClientSettingsSvc.clientSetting_startHour;
    var endHour = ClientSettingsSvc.clientSetting_endHour;
    var usehalfhour = ClientSettingsSvc.clientSetting_usehalfhour;
    
    var hours = [];
    
    var locations = [
        {id: 0, name: 'De 5'},
        {id: 1, name: 'De 7'},
        {id: 2, name: 'De 11'},
        {id: 3, name: 'Muy bastante extralargo'},
        {id: 4, name: 'XY'},
        {id: 5, name: 'XX'},
        {id: 5, name: 'Pro'}
    ];
    
    var returnObj = {};
    
    // Get all locations
    returnObj.getAll = function(){
        return locations;
    };
    
    // Get list of hours
    returnObj.getHours = function(){
        if(hours.length == 0){
            for(var i=startHour; i<=endHour; i++){
                hours.push(('0' + i).slice(-2) + ':00');

                if(usehalfhour && i < endHour)
                    hours.push(('0' + i).slice(-2) + ':30');
            }
        }
        
        return hours;
    };
    
    // Get position for Hour
    returnObj.getPositionForHour = function(hour){
        if(hour == null)
            return hours.length-1;
        else
            for(var i=0; i<=hours.length; i++)
                if(hours[i] == hour)
                    return i;

        return null;
    };
    
    // Get location ID for position
    returnObj.getId = function(position){
        return locations[position].id;
    };
    
    // Get location Name for position
    returnObj.getName = function(position){
        return locations[position].name;
    };
    
    // Get postion for location Id
    returnObj.getPosition = function(id){
        id = parseInt(id);
        
        for(var i=0; i<locations.length; i++)
            if(locations[i].id === id)
                return i;
        
        return -1;
    };

    return returnObj;
    
});