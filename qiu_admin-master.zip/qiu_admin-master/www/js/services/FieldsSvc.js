services.factory('FieldsSvc', [
'$rootScope', '$q', 'ENV', '$http', 'LocalStorageSvc', 'HoursSvc', 'TurnsSvc', 'UtilsSvc','$timeout',
    function($rootScope, $q, ENV, $http, LocalStorageSvc, HoursSvc, TurnsSvc, UtilsSvc,$timeout) {

    var fields = [];
    var returnObj = {};
    var events = [];

    var n = 0;


    returnObj.addEventToField = function(turnObject,idField){
        fields[idField].events.push(turnObject);
    };

    /**
     * getEvents by specified fieldID and date
     * @param  {*} fieldId
     * @param  {*} date
     * @return {*}
     */
    returnObj.getEventsByField = function(fieldId,date){
        return TurnsSvc.getForDate(fieldId, date);
    };

    function getEvents(positionField, date, totalGrounds) {
        TurnsSvc.getForDate(fields[positionField].id, date).then(
            function(turns){
                // console.log(turns);
                for(var i=0; i<turns.length; i++){
                    var startDate = new Date((turns[i].from));
                    var endDate = new Date((turns[i].to));
                    var end = HoursSvc.getPosition(UtilsSvc.strExtendedHourFromDate(endDate));
                    var color = "#008800"; //'rgba(0, 157, 151, 0.75)';
                    if(turns[i].status == "new"){
                        color = "#FF8A66";
                    }
                    // var color = (turns[i].isSticky)?"#008800":'rgba(0, 157, 151, 0.75)';

                    var turnObject = {
                        position: i,
                        id: turns[i].id,
                        ground: turns[i].ground,
                        idGround: turns[i].ground._id,
                        positionField: positionField,
                        eventname: turns[i].userName,
                        phone: turns[i].phone,
                        from: parseInt(UtilsSvc.strExtendedHourFromDate(startDate).replace(':','')),
                        starthour: UtilsSvc.strExtendedHourFromDate(startDate),
                        startPosition: HoursSvc.getPosition(UtilsSvc.strExtendedHourFromDate(startDate)),
                        endhour: UtilsSvc.strExtendedHourFromDate(endDate),
                        endPosition: (end  == null) ? 24 : end,
                        color: color,
                        status: turns[i].status
                    };

                    //fields[positionField].events.push(turnObject);
                    events.push(turnObject);
                }

                n++;

                if(n > totalGrounds){
                    $rootScope.$broadcast('events', {turns: events});
                }
            }
        );
    }


    /* ==== Get field.
    ===================================================== */

    returnObj.get = function (position) {
        var deferred = $q.defer();

        if(fields[parseInt(position)] == undefined) deferred.reject('La cancha indicada ya no existe');
        else deferred.resolve(fields[parseInt(position)]);

        return deferred.promise;
    };

    returnObj.getId = function (position) {
        return fields[position].id;
    };

    returnObj.getName = function (position) {
        return fields[position].name;
    };


    /**
     * Get the count of Fields
     * @return {[type]} [description]
     */
    returnObj.getFields = function(){
        var deferred = $q.defer();
        var promiseTimeout = $timeout(function(){
            deferred.reject("Timed out");
        }, 7500);
        $http({
            method: 'GET',
            url: ENV.http + '/api/v2/ground/all/' + LocalStorageSvc.getObject('user').token
        })
        .success(function(data){

            if(!data || data.code !== 200){
                deferred.reject('Error al traer las canchas...');
            }

            for (var i = 0; i < data.result.length; i++) {
                fields[i] = {
                    id: data.result[i]._id,
                    name: data.result[i].name,
                    type: data.result[i].type,
                    events: []
                };
            };

            $timeout.cancel(promiseTimeout);
            deferred.resolve(data);

        })
        .error(function(err){
            $timeout.cancel(promiseTimeout);
            deferred.reject('Error al traer las canchas...');
        });
        return deferred.promise;
    };

    /* ==== Get all fields.
    ===================================================== */

    returnObj.getAll = function(date){
        events = [];
        var deferred = $q.defer();
        TurnsSvc.turns = [];
        var promiseTimeout = $timeout(function(){
            deferred.reject("Timed out");
        }, 7500);
        $http({
            method: 'GET',
            url: ENV.http + '/api/v2/ground/all/' + LocalStorageSvc.getObject('user').token
        })
        .success(function(data){


            n = 0;

            for(var i=0; i<data.grounds.length; i++){
                fields[i] = {
                    id: data.grounds[i]._id,
                    name: data.grounds[i].name,
                    type: data.grounds[i].type,
                };
                getEvents(i, date, data.grounds.length - 1);
            }

            $timeout.cancel(promiseTimeout);
            deferred.resolve(data);
        })
        .error(function () {
            $timeout.cancel(promiseTimeout);
            deferred.reject('Error');
        });

        return deferred.promise;
    };

    /* ==== Insert field.
    ===================================================== */

    returnObj.insert = function(name, typeId, feeVal, priceVal){
        var deferred = $q.defer();

        $http({
            method: 'POST',
            url: ENV.http + '/api/v2/ground/',
            data: {
                name: name,
                type: typeId,
                fee: feeVal,
                price: priceVal,
                status: "new",
                sportcenter: -1,
                token: LocalStorageSvc.getObject('user').token
            }
        })
        .success(function(data){

            returnObj.getAll();

            deferred.resolve('Cancha creada');
        })
        .error(function (data) {
            deferred.reject(data.error);
        });

        return deferred.promise;
    };


    /* ==== Delete field.
    ===================================================== */

    returnObj.delete = function(id, position){
        var deferred = $q.defer();

        $http({
            method: 'POST',
            url: ENV.http + '/api/v2/ground/all/' + LocalStorageSvc.getObject('user').token + '/remove',
            data: {
                ground: id
            }
        })
        .success(function (data) {
            if(data.code !== 200){
                deferred.reject('Error..');
                return;
            }
            fields.splice(parseInt(position), 1);
            deferred.resolve('Cancha eliminada');
        })
        .error(function () {
            deferred.reject('Error');
        });

        return deferred.promise;
    };


    /* ==== Update field.
    ===================================================== */

    returnObj.update = function(id, name, typeId, feeVal, priceVal){
        var deferred = $q.defer();

        $http({
            method: 'POST',
            url: ENV.http + '/api/v2/ground/all' + LocalStorageSvc.getObject('user').token+ '/update',
            data: {
                groundId: id,
                ground: {
                    name: name,
                    type: typeId,
                    fee: feeVal,
                    price: priceVal
                }
            }
        })
        .success(function(data){


            returnObj.getAll().then(
                function () {
                    deferred.resolve('Cancha editada');
                },
                function (data) {
                    deferred.reject(data.error);
                }
            );
    })
        .error(function (data) {
            deferred.reject(data.error);
        });

        return deferred.promise;
    };


    /* ==== Field types.
    ===================================================== */

    returnObj.types = function(){
        var deferred = $q.defer();

        $http({
            method: 'GET',
            url: ENV.http + '/api/v2/type/'
        })
        .success(function(data){
            deferred.resolve(data);
        })
        .error(function (data) {
            deferred.reject(data.error);
        });

        return deferred.promise;
    };


    /* ==== Response.
    ===================================================== */

    return returnObj;

}]);
