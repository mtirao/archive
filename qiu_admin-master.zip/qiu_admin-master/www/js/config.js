environment.constant('ENV', {

    //'socket':'http://localhost/',
    //'http':'http://localhost/'
    'socket': 'http://192.168.2.7:8080/QiuServer',
    'http': 'http://192.168.2.7:8080/QiuServer'
    //'socket':'http://localhost:8080/',
    //'http':'http://localhost:8080/'
    //'socket': 'http://qiupro.com:8080/',
    //'http': 'http://qiupro.com:8080/'
    // 'socket': 'http://qiupro.com:3000/',
    // 'http': 'http://qiupro.com:3000/'
    // 'socket':'http://192.168.1.39:8080/',
    // 'http':'http://192.168.1.39:8080/'
});

QiuAdmin.config(function($translateProvider){

    // --- Translate
    // -----------------------------------------------------

    $translateProvider.translations(
        'es',
        {
            JANUARY: 'Enero',
            FEBRUARY: 'Febrero',
            MARCH: 'Marzo',
            APRIL: 'Abril',
            MAI: 'Mayo',
            JUNE: 'Junio',
            JULY: 'Julio',
            AUGUST: 'Agosto',
            SEPTEMBER: 'Septiembre',
            OCTOBER: 'Octubre',
            NOVEMBER: 'Noviembre',
            DECEMBER: 'Diciembre',
            SUNDAY: 'Domingo',
            MONDAY: 'Lunes',
            TUESDAY: 'Martes',
            WEDNESDAY: 'Miércoles',
            THURSDAY: 'Jueves',
            FRIDAY: 'Viernes',
            SATURDAY: 'Sábado'
        }
    );
    $translateProvider.preferredLanguage('es');
    $translateProvider.useSanitizeValueStrategy('escape');

});
