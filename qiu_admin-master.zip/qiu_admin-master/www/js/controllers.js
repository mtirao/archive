controllers.controller('AppCtrl', function($scope, $state, $ionicPlatform, $ionicPopup, $ionicHistory, LocalStorageSvc, $cordovaAppVersion){

    $ionicPlatform.ready(function(){
          $scope.version = $cordovaAppVersion;
    });

    $scope.exit = function(){
        var confirmPopup = $ionicPopup.confirm({
            title: 'Salir',
            template: '¿Está seguro que desea cerrar su sesión?'
        });

        confirmPopup.then(function(res){
            if(res){
                LocalStorageSvc.clear('logged');
                $ionicHistory.clearCache();
                $state.go('login');
            }
        });
    };

});
