
var QiuAdmin = angular.module('QiuAdmin',
  [
    'ionic',
    'ngCordova',
    'QiuAdmin.controller',
    'QiuAdmin.services',
    'QiuAdmin.enviroment',
    'QiuAdmin.directives',
    'ionic.contrib.drawer',
    'flexcalendar',
    'pascalprecht.translate',
    'ngIOS9UIWebViewPatch'
  ]);

QiuAdmin.run([
  '$rootScope',
  '$ionicPlatform',
  'PushSvc',
  '$cordovaNetwork',
  'AnalyticsSvc',
  'AccessSvc',
  function($rootScope,$ionicPlatform, PushSvc,$cordovaNetwork,AnalyticsSvc,AccessSvc){

    $ionicPlatform.ready(function(){

      $rootScope.connection = {
        "online":true
      };

      /**
       * Flag to know if the google map api is loaded
       * @property mapLoad
       * @type {boolean}
       */
      var mapLoad = false;

      /**
       * This will happen when the user is online
       * @method onOnline
       */
      function onOnline() {
        if(mapLoad)return;
        loadMapScript();
      }

      /**
       * This method is executed when the js of google map is loaded
       * @method mapLoaded
       */
      function mapLoaded(){
        mapLoad = true;
      }

      function isLoaded(){
        return mapLoad;
      }

      window.mapLoaded = mapLoaded;
      window.isLoaded = isLoaded;

      /**
       * This load the javascript of google maps asyncrounsly in order to not delay the init charge.
       *  loadMapScript
       */
      function loadMapScript() {
       /* var script = document.createElement('script');
        script.className = 'gm_script';
        script.type = 'text/javascript';
        script.src = 'https://maps.googleapis.com/maps/api/js?key=AIzaSyB16sGmIekuGIvYOfNoW9T44377IU2d2Es&callback=mapLoaded';
        document.body.appendChild(script);*/
      }
      window.loadMapScript = loadMapScript;

      if(window.cordova && window.cordova.plugins.Keyboard){
        cordova.plugins.Keyboard.hideKeyboardAccessoryBar(false);
        cordova.plugins.Keyboard.disableScroll(true);
      }

      if(window.StatusBar){
        StatusBar.styleLightContent();
      }

      if(navigator.splashscreen){
        navigator.splashscreen.hide();
      }

      AnalyticsSvc.startTrackerWithId("UA-70465373-1");

      var logged = window.localStorage.getItem('logged');
      if(logged === 'yes'){
        AccessSvc.updateDevice(function(){
          PushSvc.register();
        });
      }

      onOnline();
    });

    // listen for Online event
    $rootScope.$on('$cordovaNetwork:online', function(event, networkState){
      $rootScope.connection.online = true;
    });

    // listen for Offline event
    $rootScope.$on('$cordovaNetwork:offline', function(event, networkState){
      $rootScope.connection.online = false;
    });
  }]);

var controllers     =   angular.module('QiuAdmin.controller', []);
var services        =   angular.module('QiuAdmin.services', []);
var environment     =   angular.module('QiuAdmin.enviroment', []);
var directives     =   angular.module('QiuAdmin.directives', []);
