QiuAdmin.config([
  '$stateProvider',
  '$urlRouterProvider',
  function($stateProvider, $urlRouterProvider){

    $stateProvider

      .state('login', {
        url: "/login",
        controller: "AccessCtrl",
        templateUrl: "templates/login.html",
        cache: false
      })

      .state('app', {
        url: '/app',
        abstract: true,
        templateUrl: 'templates/menu.html',
        controller: 'AppCtrl'
      })

      .state('app.turnsDay', {
        url: '/turns-day',
        views: {
          'menuContent': {
            templateUrl: 'templates/turnsPerDay.html',
            controller: 'CalendarDayCtrl'
          }
        },
        cache: false
      })

      .state('app.turnsMonth', {
        url: '/turns-month',
        views: {
          'menuContent': {
            templateUrl: 'templates/turnsPerMonth.html',
            controller: 'CalendarCtrl'
          }
        }
      })

      .state('app.fields', {
        url: '/fields',
        views: {
          'menuContent': {
            templateUrl: 'templates/fields.html',
            controller: 'GroundCtrl'
          }
        }
      })

      .state('app.config', {
        url: '/config',
        views: {
          'menuContent': {
            templateUrl: 'templates/config.html',
            controller: 'ProfileCtrl'
          }
        }
      })
      .state('app.reservations', {
        url: '/reservations',
        views: {
          'menuContent': {
            templateUrl: 'templates/reservations.html',
            controller: 'ReservationsCtrl'
          }
        }
      })
      .state('app.sportcenter', {
        url: '/sportcenter',
        views: {
          'menuContent': {
            templateUrl: 'templates/sportcenter.html',
            controller: 'SportcenterCtrl'
          }
        }
      })
      .state('app.notifications', {
        url: '/notifications',
        views: {
          'menuContent': {
            templateUrl: 'templates/notifications.html',
            controller: 'NotificationsCtrl'
          }
        }
      })
      .state('app.activities', {
        url: '/activities',
        views: {
          'menuContent': {
            templateUrl: 'templates/activities.html',
            controller: 'ActivitiesCtrl'
          }
        }
      }).state('app.activitiesDetail', {
        url: '/activitiesDetail',
        views: {
          'menuContent': {
            templateUrl: 'templates/activity-detail.html',
            controller: 'ActivityDetailCtrl'
          }
        }
      }).state('app.sportcenterAdmin', {
        url: '/sportcenterAdmin',
        views: {
          'menuContent': {
            templateUrl: 'templates/sportcenterAdmin.html',
            controller: 'SportcenterAdminCtrl'
          }
        }
      }).state('app.turn', {
        url: '/turn/:idTurn',
        views: {
          'menuContent': {
            templateUrl: 'templates/turn.html',
            controller: 'TurnCtrl'
          }
        }
      });


    // --- Homepage
    // -----------------------------------------------------

    var logged = window.localStorage.getItem('logged');
    
    if(logged === 'yes'){
      $urlRouterProvider.otherwise(function ($injector) {
        var $state = $injector.get('$state');
        $state.go('app.reservations');
      });
    }
    else{
      $urlRouterProvider.otherwise('/login');
    }

  }]);
