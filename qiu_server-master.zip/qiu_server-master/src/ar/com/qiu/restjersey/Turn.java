package ar.com.qiu.restjersey;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import ar.com.qiu.helpers.AuthorizationHelper;
import ar.com.qiu.helpers.DbHelper;
import ar.com.qiu.helpers.GroundHelper;
import ar.com.qiu.model.GroundModel;
import ar.com.qiu.model.Status;
import ar.com.qiu.model.TurnModel;


@Path("/turn")
public class Turn {
	
	@Path("{turnId}")
	@GET
	@Produces("application/json")
	public Response getTurn(@PathParam("turnId") long turnId) throws JSONException {
		
		JSONObject jsonObject = new JSONObject();
		
		Connection conn = DbHelper.getConnection();
		
		if(conn != null) {
			
			jsonObject = getTurn(conn, turnId);
			
			if(jsonObject != null) {
				return Response.status(200).entity(jsonObject.toString()).build();
			}
			
		}
		
		jsonObject.put("result", "Bad request");
		return Response.status(400).entity(jsonObject.toString()).build();
		
	}
	
	@Path("/sportcenter/{tokenId}")
	@GET
	@Produces("application/json")
	public Response getSportcenterTurn(@PathParam("tokenId") String sportcenterId) throws JSONException {
		
		JSONObject jsonObject = new JSONObject();
		
		Connection conn = DbHelper.getConnection();
		
		if(conn != null) {
			
			jsonObject.put("turns", new ArrayList<String>());
			
			
			/*jsonObject = getTurn(conn, sportcenterId, true);
			
			
			if(jsonObject != null) {
				return Response.status(200).entity(jsonObject.toString()).build();
			}*/
			return Response.status(200).entity(jsonObject.toString()).build();
			
		}
		
		jsonObject.put("result", "Bad request");
		return Response.status(400).entity(jsonObject.toString()).build();
		
	}
	
	@Path("/owner/{token}")
	@GET
	@Produces("application/json")
	public Response getOwnerTurn(@PathParam("token") String token) throws JSONException {
		
		JSONObject jsonObject = new JSONObject();
		
		Connection conn = DbHelper.getConnection();
		
		if(conn != null) {
			
			jsonObject = getTurn(conn, token, false);
			
			
			if(jsonObject != null) {
				return Response.status(200).entity(jsonObject.toString()).build();
			}
			
		}
		
		jsonObject.put("result", "Bad request");
		return Response.status(400).entity(jsonObject.toString()).build();
		
	}
	

	@PUT
	@Produces("application/json")
	@Consumes("application/json")
	public Response updateTurn(String json) throws JSONException {
		JSONObject responseJson = new JSONObject();
		JSONObject requestJson = new JSONObject(json);
		
		Connection conn = DbHelper.getConnection();
		PreparedStatement ps = null;
		
		if(conn != null) {
			try {
				
				String partnerId = requestJson.getString("partner");
				long turnId = requestJson.getLong("id");
				String status = requestJson.getString("status");
				String token = requestJson.getString("token");
				
				token = AuthorizationHelper.validateToken(token);
				
				if(token == null) {
					responseJson.put("error", "Invalid token");
					return Response.status(401).entity(responseJson.toString()).build();
				}
				
				if(partnerId.length() > 0) {
					ps = conn.prepareStatement("UPDATE turn SET status = ? WHERE partner = ?");
					ps.setString(2, partnerId);
				}else {
					ps = conn.prepareStatement("UPDATE turn SET status = ? WHERE id = ?");
					ps.setLong(2, turnId);
				}
				
				ps.setString(1, status);
				
				int count = ps.executeUpdate();
				
				if(count > 0) {
					responseJson.put("result", "ok");
					return Response.status(200).entity(responseJson.toString()).build();
				}
				
			}catch (SQLException e) {
				e.printStackTrace();
			} finally {
				
				if(ps != null) {
					try {
						ps.close();
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
				
			}
		}
		
		
		
		responseJson.put("result", "Bad request");
		return Response.status(400).entity(responseJson.toString()).build();
	}
	
	
	@DELETE
	@Produces("application/json")
	@Consumes("application/json")
	public Response deleteTurn(String json) throws JSONException {
		JSONObject responseJson = new JSONObject();
		JSONObject requestJson = new JSONObject(json);
		
		Connection conn = DbHelper.getConnection();
		PreparedStatement ps = null;
		
		if(conn != null) {
			try {
				
				String partnerId = requestJson.getString("partner");
				long turnId = requestJson.getLong("id");
				String status = Status.DELETED.toString();
				
				String token = requestJson.getString("token");
				
				if(partnerId.length() > 0) {
					ps = conn.prepareStatement("UPDATE turn SET status = ? WHERE partner = ?");
					ps.setString(2, partnerId);
				}else {
					ps = conn.prepareStatement("UPDATE turn SET status = ? WHERE id = ?");
					ps.setLong(2, turnId);
				}
				ps.setString(1, status);
				
				int count = ps.executeUpdate();
				
				if(count > 0) {
					responseJson.put("result", "ok");
					return Response.status(200).entity(responseJson.toString()).build();
				}
				
			}catch (SQLException e) {
				e.printStackTrace();
			} finally {
				
				if(ps != null) {
					try {
						ps.close();
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
				
			}
		}
		
		
		
		responseJson.put("result", "Bad request");
		return Response.status(400).entity(responseJson.toString()).build();
	}
	
	@POST
	@Produces("application/json")
	@Consumes("application/json")
	public Response addTurn(String json) throws JSONException {
		JSONObject responseJson = new JSONObject();
		
		Connection conn = DbHelper.getConnection();
		PreparedStatement ps = null;
		
		if(conn != null) {
			
			JSONObject requestJson = new JSONObject(json);
			
			JSONArray turns = requestJson.getJSONArray("turns");
			
			
			//TODO: Validate token
			
			try {
				
				String turnId = null;
				for(Object obj : turns) {
					JSONObject jsonTurn = (JSONObject) obj; 
					
					TurnModel turn = new TurnModel(jsonTurn);
					
					
					conn.setAutoCommit(false);
					
					if(turn.getGround() != null) {
					
						ps = insert(conn, turn);
						
						int count = ps.executeUpdate();
						
						if(count > 0) {
							turnId = turn.getPartner().toString();
						}
						
					}else {
						List<GroundModel> grounds = GroundHelper.fetchAll(turn.getToken());
						
						for(GroundModel ground: grounds) {
							
							BigInteger id = new BigInteger(String.valueOf(ground.getId()));
							
							turn.setGround(id);
							
							ps = insert(conn, turn);
							int count = ps.executeUpdate();
							if(count > 0) {
								turnId = turn.getPartner().toString();
							}
							
						}
					}
				
				}
				
				conn.commit();
				
				responseJson.put("result", "ok");
				responseJson.put("id", turnId);
				return Response.status(200).entity(responseJson.toString()).build();
				
			} catch (SQLException e) {
				try {
					conn.rollback();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				e.printStackTrace();
			}  finally {
				
				if(ps != null) {
					try {
						
						ps.close();
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
				
			}
			
		}
		
		responseJson.put("result", "Bad request");
		return Response.status(400).entity(responseJson.toString()).build();
	}
	
	private PreparedStatement insert(Connection conn, TurnModel turn) throws SQLException {
		
		PreparedStatement ps = conn.prepareStatement("INSERT INTO turn(sportcenter, ground, type, token, name, phone, time, is_sticky, date, status, partner)"
				+ "VALUES (?,?,?,?,?,?,?,?,?,?,?)");
		
		ps.setLong(1, turn.getSportcenter().longValue());
		ps.setLong(2, turn.getGround().longValue());
		ps.setLong(3, turn.getType().longValue());
		ps.setString(4, turn.getToken());
		ps.setString(5, turn.getName());
		ps.setString(6, turn.getPhone());
		ps.setFloat(7, turn.getTime().floatValue());
		ps.setBoolean(8, turn.isSticky());
		ps.setLong(9, turn.getDate().longValue());
		ps.setString(10, turn.getStatus());
		ps.setString(11, turn.getPartner().toString());
		
		return ps;
	}
	
	private JSONObject getTurn(Connection conn, String _id, boolean isSportcenterId) {
		
		JSONObject jsonObject = new JSONObject();
		PreparedStatement ps = null;
		
		try {
			
			if(isSportcenterId) {
				ps = conn.prepareStatement("SELECT * FROM turn WHERE sportcenter = ? ");
			}else {
				ps = conn.prepareStatement("SELECT * FROM turn WHERE token = ? ");
			}
			
			ps.setString(1, _id);
			
			ResultSet rs = ps.executeQuery();
			
			List<JSONObject> objects = new ArrayList<JSONObject>();
			
			while(rs.next()) {
			    
				String sportcenter = rs.getString("sportcenter");
				String ground = rs.getString("ground");
				String type = rs.getString("type");
				String token = rs.getString("token");
				String name = rs.getString("name");
				String phone = rs.getString("phone");
				float time = rs.getFloat("time");
				String partner = rs.getString("partner");
				boolean sticky = rs.getBoolean("is_sticky");
				//Timestamp createAt = rs.getTimestamp("create_at");
				int date =  rs.getInt("date");
				String status = rs.getString("status");
				long id = rs.getLong("id");
				
				JSONObject turn = new JSONObject();
				
				turn.put("sportcenter", sportcenter);
				turn.put("ground", ground);
				turn.put("type", type);
				turn.put("token", token);
				turn.put("name", name);
				turn.put("phone", phone);
				turn.put("time", time);
				turn.put("partner", partner);
				turn.put("sticky", sticky);
				turn.put("date", date);
				turn.put("status", status);
				turn.put("id", id);
				
				objects.add(turn);
				
			}
			
			jsonObject.put("turns", objects);
			return jsonObject;
			
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			
			if(ps != null) {
				try {
					ps.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
		}
		
		return null;
	}
	
	private JSONObject getTurn(Connection conn, long turnId) {
		
		JSONObject jsonObject = new JSONObject();
		PreparedStatement ps = null;
		
		try {
			ps = conn.prepareStatement("SELECT * FROM turn WHERE id = ? ");
			ps.setLong(1, turnId);
			
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
			    
				String sportcenter = rs.getString("sportcenter");
				String ground = rs.getString("ground");
				String type = rs.getString("type");
				String token = rs.getString("token");
				String name = rs.getString("name");
				String phone = rs.getString("phone");
				float time = rs.getFloat("time");
				String partner = rs.getString("partner");
				boolean sticky = rs.getBoolean("is_sticky");
				//Timestamp createAt = rs.getTimestamp("create_at");
				int date =  rs.getInt("date");
				String status = rs.getString("status");
				long id = rs.getLong("id");
				
				jsonObject.put("sportcenter", sportcenter);
				jsonObject.put("ground", ground);
				jsonObject.put("type", type);
				jsonObject.put("token", token);
				jsonObject.put("name", name);
				jsonObject.put("phone", phone);
				jsonObject.put("time", time);
				jsonObject.put("partner", partner);
				jsonObject.put("sticky", sticky);
				jsonObject.put("date", date);
				jsonObject.put("status", status);
				jsonObject.put("id", id);
				
				return jsonObject;
				
			}
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			
			if(ps != null) {
				try {
					ps.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
		}
		
		return null;
	}
}
