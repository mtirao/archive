package ar.com.qiu.restjersey;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import org.json.JSONObject;

import ar.com.qiu.helpers.DbHelper;
import ar.com.qiu.helpers.JsonHelper;

@Path("/message")
public class Message {
	
	@Path("{messageId}")
	@GET
	@Produces("application/json")
	public Response get(@PathParam("messageId") String messageId) {
		
		JSONObject jsonObject = new JSONObject();
		
		Connection conn = DbHelper.getConnection();
		
		if(conn != null) {
			
			PreparedStatement ps = null;
			
			try {
				ps = conn.prepareStatement("SELECT * FROM message WHERE msg_to = ? ");
				ps.setString(1, messageId);
				
				ResultSet rs = ps.executeQuery();
				
				List<JSONObject> messages = new ArrayList<JSONObject>();
				
				while(rs.next()) {
					
					String from = rs.getString("msg_from");
					String to = rs.getString("msg_to");
					String type = rs.getString("msg_type");
					String status = rs.getString("status");
					String title = rs.getString("title");
					String message = rs.getString("message");
					long id = rs.getLong("id");
					
					JSONObject msg= new JSONObject();
					msg.put("from", from);
					msg.put("to", to);
					msg.put("type", type);
					msg.put("status", status);
					msg.put("title", title);
					msg.put("message", message);
					msg.put("id", id);
					
					messages.add(msg);
				}
				
				jsonObject.put("messages", messages);
				return Response.status(200).entity(jsonObject.toString()).build();
			
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
			
				if(ps != null) {
					try {
						ps.close();
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		}
		
		jsonObject.put("result", "Bad request");
		return Response.status(400).entity(jsonObject.toString()).build();
	}
	
	@POST
	@Produces("application/json")
	@Consumes("application/json")
	public Response add(String json ) {
		
		Response response = updateMessage(json, false);
		return response;
	}
	
	@PUT
	@Produces("application/json")
	@Consumes("application/json")
	public Response update(String json ) {
		
		Response response = updateMessage(json, true);
		return response;
	}
	
	private Response updateMessage(String json, boolean update) {
		
		JSONObject responseJson = new JSONObject();
		JSONObject requestJson = new JSONObject(json);
		
		Connection conn = DbHelper.getConnection();
		PreparedStatement ps = null;
		
		if(conn != null) {
		
			
			try {
				ps = get(conn, requestJson, update);
				
				int count = ps.executeUpdate();
				
				if(count > 0) {
					responseJson.put("result", "ok");
					return Response.status(200).entity(responseJson.toString()).build();
				}
				
			}catch (SQLException e) {
				e.printStackTrace();
			}  finally {
				
				if(ps != null) {
					try {
						ps.close();
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
				
			}
			
		}
		
		responseJson.put("result", "Bad request");
		return Response.status(400).entity(responseJson.toString()).build();
		
	}

	private PreparedStatement get(Connection conn, JSONObject requestJson, boolean update) throws SQLException {
		
		
		String from = JsonHelper.getString(requestJson, "from");
		String to = JsonHelper.getString(requestJson,"to");
		String type = JsonHelper.getString(requestJson,"type");
		String status = JsonHelper.getString(requestJson,"status");
		String title = JsonHelper.getString(requestJson,"title");
		String message = JsonHelper.getString(requestJson, "message");
		
		
		
		PreparedStatement ps = null;
		
		if(!update) {
			ps = conn.prepareStatement("INSERT INTO message(msg_from, msg_to, msg_type, status, title, message) "
				+ "VALUES (?,?,?,?,?,?)");
			
			ps.setString(1, from);
			ps.setString(2, to);
			ps.setString(3, type);
			ps.setString(4, status);
			ps.setString(5, title);
			ps.setString(6, message);
			
		}else {
			
			ps = conn.prepareStatement("UPDATE message SET status = ? WHERE msg_from = ?");
			
			ps.setString(1, status);
			ps.setNString(2, from);
		}
		
		
		return ps;
	}
	
}
