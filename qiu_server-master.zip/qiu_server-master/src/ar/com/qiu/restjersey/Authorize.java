package ar.com.qiu.restjersey;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.UUID;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import org.json.JSONObject;

import ar.com.qiu.helpers.AuthorizationHelper;
import ar.com.qiu.helpers.DbHelper;
import ar.com.qiu.helpers.JsonHelper;
import ar.com.qiu.helpers.ProfileHelper;

@Path("/authorize")
public class Authorize {
	
	@POST
	@Produces("application/json")
	@Consumes("application/json")
	public Response add(String json ) {
		
		JSONObject responseJson = new JSONObject();
		JSONObject requestJson = new JSONObject(json);
		
		
		String email = JsonHelper.getString(requestJson, "email");
		String mobile = JsonHelper.getString(requestJson, "mobile");
		String password = JsonHelper.getString(requestJson, "password");
		String name = JsonHelper.getString(requestJson, "name");
		
		
		String result = null;
		
		boolean emailVerified = false;
		boolean mobileVerified = false;
		
		if (email != null) {
			emailVerified = true;
			result = AuthorizationHelper.tokenByEmail(email, password);
		}else if (mobile != null) {
			mobileVerified = true;
			result = AuthorizationHelper.tokenByMobile(mobile, password);
		}
		
		if(name == null) {
			name = "";
		}
		
		if(password != null ) {
			if(result != null) {
				ProfileHelper.createOrUpdate(result, name, "", "", emailVerified?email:"", mobileVerified?mobile:"", emailVerified, mobileVerified, emailVerified);
				responseJson.put("token", result);
				return Response.status(200).entity(responseJson.toString()).build();
			}else {
				responseJson.put("error", "invalid password");
				return Response.status(401).entity(responseJson.toString()).build();
				
			}
		}else {
			if(result != null) {
				ProfileHelper.createOrUpdate(result, name, "", "", emailVerified?email:"", mobileVerified?mobile:"", emailVerified, mobileVerified, emailVerified);
				responseJson.put("token", result);
				return Response.status(200).entity(responseJson.toString()).build();
			}else {
				result = addUserAuth(email, mobile, password);
				if (result != null) {
					ProfileHelper.createOrUpdate(result, name, "", "", emailVerified?email:"", mobileVerified?mobile:"", emailVerified, mobileVerified, emailVerified);
					responseJson.put("token", result);
					return Response.status(201).entity(responseJson.toString()).build();
				}
			}
		}
		
		responseJson.put("error", "Invalid token");
		return Response.status(500).entity(responseJson.toString()).build();
		
	}
	
	@PUT
	@Produces("application/json")
	@Consumes("application/json")
	public Response update(String json ) {
		JSONObject responseJson = new JSONObject();
		JSONObject requestJson = new JSONObject(json);
		
		
		String token = JsonHelper.getString(requestJson, "token");
		String password = JsonHelper.getString(requestJson, "password");
		
		
		String result = null;
		
		if (token != null) {
			result = AuthorizationHelper.validateToken(token);
		}else {
			responseJson.put("error", "Invalid token");
			return Response.status(400).entity(responseJson.toString()).build();
		}
		
		
		if(password != null ) {
			if(result != null) {
				String tkn = updatePassword(result, password);
				if(tkn != null) {
					responseJson.put("token", tkn);
					return Response.status(200).entity(responseJson.toString()).build();
				}else {
					responseJson.put("error", "Invalid token");
					return Response.status(400).entity(responseJson.toString()).build();
				}
			}
		}else {
			responseJson.put("error", "Request error");
			return Response.status(400).entity(responseJson.toString()).build();
		}
		
		responseJson.put("error", "Invalid token");
		return Response.status(500).entity(responseJson.toString()).build();
	}
	
	private String updatePassword(String token, String password) {
		
		Connection conn = DbHelper.getConnection();
		PreparedStatement ps = null;
		
		if(conn != null) {
		
			try {
				
				ps = conn.prepareStatement("UPDATE user_auth SET password=? WHERE token = ?");
				
				
				ps.setString(1, password);
				ps.setString(2, token);
				
				int count = ps.executeUpdate();
				
				if(count > 0) {
					return token;
				}
				
			}catch (SQLException e) {
				e.printStackTrace();
			}  finally {
				
				if(ps != null) {
					try {
						ps.close();
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
				
			}
			
		}
		
		return null;
		
	}
	
	
	private String addUserAuth(String email, String mobile, String password) {
		
		
		Connection conn = DbHelper.getConnection();
		PreparedStatement ps = null;
		
		if(conn != null) {
		
			try {
				
				UUID uuid = UUID.randomUUID();
				
				ps = conn.prepareStatement("INSERT INTO user_auth(token, email, mobile, password)"
						+ "VALUES (?,?,?,?)");
				
				ps.setString(1, uuid.toString());
				if(email != null) {
					ps.setString(2, email);
				}else {
					ps.setString(2, "");
				}
				
				if(mobile != null) {
					ps.setString(3, mobile);
				}else {
					ps.setString(3, "");
				}
				
				if(password != null) {
					ps.setString(4, password);
				}else {
					ps.setString(4, "");
				}
				
				int count = ps.executeUpdate();
				
				if(count > 0) {
					return uuid.toString();
				}
				
			}catch (SQLException e) {
				e.printStackTrace();
			}  finally {
				
				if(ps != null) {
					try {
						ps.close();
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
				
			}
			
		}
		
		return null;
		
	}
	
	private PreparedStatement addOrUpdate(Connection conn, JSONObject requestJson, boolean update) throws SQLException {
		
		String name = JsonHelper.getString(requestJson, "name");
		String address = JsonHelper.getString(requestJson, "address");
		String mobile = JsonHelper.getString(requestJson, "mobile");
		String email = JsonHelper.getString(requestJson, "email");
		String about = JsonHelper.getString(requestJson, "about");
		String token = JsonHelper.getString(requestJson, "token");
		String device =JsonHelper.getString(requestJson, "device");
		String deviceId = JsonHelper.getString(requestJson, "device_id");
		boolean emailVerified = JsonHelper.getBoolean(requestJson, "email_verified");
		boolean mobileVerified = JsonHelper.getBoolean(requestJson, "mobile_verified");
		boolean feeRequired = JsonHelper.getBoolean(requestJson, "facebook_verified");
		
		PreparedStatement ps = null;
		
		if(!update) {
			ps = conn.prepareStatement("INSERT INTO profile(name, address, mobile, email, about, device, device_id, email_verified, mobile_verified, facebook_verified, token)"
				+ "VALUES (?,?,?,?,?,?,?,?,?,?,?)");
		}else {
			
			ps = conn.prepareStatement("UPDATE profile SET name = ?, address = ?, mobile = ?, about = ?, device = ?, "
					+ "device_id = ?, email_verified = ?, mobile_verified = ?, facebook_verified = ?, token = ? WHERE email = ?");
		}
		
		ps.setString(1, name);
		ps.setString(2, address);
		ps.setString(3, mobile);
		ps.setString(4, about);
		ps.setString(5, device);
		ps.setString(6, deviceId);
		ps.setBoolean(7, emailVerified);
		ps.setBoolean(8, mobileVerified);
		ps.setBoolean(9, feeRequired);
		ps.setString(10, token);
		ps.setString(11, email);
		
		return ps;
		
	}
	
}
