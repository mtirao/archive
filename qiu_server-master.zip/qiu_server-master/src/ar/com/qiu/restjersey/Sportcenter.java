package ar.com.qiu.restjersey;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import org.json.JSONException;
import org.json.JSONObject;

import ar.com.qiu.helpers.DbHelper;
import ar.com.qiu.helpers.JsonHelper;

@Path("/sportcenter")
public class Sportcenter {
	
	@Path("/all/{tokenId}")
	@GET
	@Produces("application/json")
	public Response getAllSportcenter(@PathParam("tokenId") String tokenId) throws JSONException {
		
		Response response = fetch(tokenId, true);
		
		return response;
	}
	
	@Path("/mine/{tokenId}")
	@GET
	@Produces("application/json")
	public Response getMineSportcenter(@PathParam("tokenId") String tokenId) throws JSONException {
		
		Response response = fetch(tokenId, false);
		
		return response;
	}
	
	
	@POST
	@Produces("application/json")
	@Consumes("application/json")
	public Response add(String json ) {
		
		Response response = updateSportcenter(json, null, false);
		return response;
	}
	
	@Path("{tokenId}")
	@PUT
	@Produces("application/json")
	@Consumes("application/json")
	public Response update(@PathParam("tokenId") String tokenId, String json ) {
		
		Response response = updateSportcenter(json, tokenId, true);
		return response;
	}
	
	
	private Response updateSportcenter(String json, String tokenId, boolean update) {
		
		JSONObject responseJson = new JSONObject();
		JSONObject requestJson = new JSONObject(json);
		
		Connection conn = DbHelper.getConnection();
		PreparedStatement ps = null;
		
		if(conn != null) {
		
			
			try {
				if(tokenId != null) {
					requestJson.put("token", tokenId);
				}
				ps = get(conn, requestJson, update);
				
				int count = ps.executeUpdate();
				
				if(count > 0) {
					responseJson.put("result", "ok");
					return Response.status(200).entity(responseJson.toString()).build();
				}
				
			}catch (SQLException e) {
				e.printStackTrace();
			}  finally {
				
				if(ps != null) {
					try {
						ps.close();
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
				
			}
			
		}
		
		responseJson.put("result", "Bad request");
		return Response.status(400).entity(responseJson.toString()).build();
		
	}
	
	private Response fetch(String tokenId, boolean all) {
		
		JSONObject jsonObject = new JSONObject();
		PreparedStatement ps = null;
		Connection conn = DbHelper.getConnection();
		
		try {
			
			if(all) {
				ps = conn.prepareStatement("SELECT * FROM sportcenter WHERE token != ?");
				ps.setString(1, tokenId);
			}else {
				ps = conn.prepareStatement("SELECT * FROM sportcenter WHERE token = ?");
				ps.setString(1, tokenId);
			}
			
			ResultSet rs = ps.executeQuery();
			
			List<JSONObject> objects = new ArrayList<JSONObject>();
			
			while(rs.next()) {
				
				String name = rs.getString("name");
				String address = rs.getString("address");
				String mobile = rs.getString("mobile");
				String email = rs.getString("email");
				String about = rs.getString("about");
				boolean emailVerify = rs.getBoolean("email_verify");
				boolean mobileVerify = rs.getBoolean("mobile_verify");
				boolean feeRequired = rs.getBoolean("fee_required");
				float openAt = rs.getFloat("open_at");
				float closeAt = rs.getFloat("close_at");
				float latitude = rs.getFloat("latitude");
				float longitude = rs.getFloat("longitude");
				String status = rs.getString("status");
				long id = rs.getLong("id");
				
				JSONObject sportcenter = new JSONObject();
				
				sportcenter.put("name", name);
				sportcenter.put("address", address);
				sportcenter.put("mobile", mobile);
				sportcenter.put("email", email);
				sportcenter.put("about", about);
				sportcenter.put("emailverify", emailVerify);
				sportcenter.put("mobileverify", mobileVerify);
				sportcenter.put("feerequired", feeRequired);
				sportcenter.put("openAt", openAt);
				sportcenter.put("closeAt", closeAt);
				sportcenter.put("latitude", latitude);
				sportcenter.put("longitude", longitude);
				sportcenter.put("status", status);
				sportcenter.put("id", id);
				
				objects.add(sportcenter);
				
			}
			
			jsonObject.put("sportcenters", objects);
			
			return Response.status(200).entity(jsonObject.toString()).build();
			
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			
			if(ps != null) {
				try {
					ps.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
		}
		
		jsonObject.put("result", "Bad request");
		return Response.status(400).entity(jsonObject.toString()).build();
		
	}
	
	private PreparedStatement get(Connection conn, JSONObject requestJson, boolean update) throws SQLException {
		
		
		String name = JsonHelper.getString(requestJson, "name");
		String address = JsonHelper.getString(requestJson, "address");
		String mobile = JsonHelper.getString(requestJson, "mobile");
		String email = JsonHelper.getString(requestJson, "email");
		String about = JsonHelper.getString(requestJson, "about");
		String token = JsonHelper.getString(requestJson, "token");
		boolean emailVerify = JsonHelper.getBoolean(requestJson, "emailverify");
		boolean mobileVerify = JsonHelper.getBoolean(requestJson, "mobileverify");
		boolean feeRequired = JsonHelper.getBoolean(requestJson, "feerequired");
		float openAt = JsonHelper.getFloat(requestJson, "openAt");
		float closeAt = JsonHelper.getFloat(requestJson, "closeAt");
		float latitude = JsonHelper.getFloat(requestJson, "latitude");
		float longitude = JsonHelper.getFloat(requestJson, "longitude");
		String status = JsonHelper.getString(requestJson, "status");
		
		PreparedStatement ps = null;
		
		if(!update) {
			ps = conn.prepareStatement("INSERT INTO sportcenter(name, address, mobile, email, about, email_verify, "
					+ "mobile_verify, fee_required, open_at, close_at, latitude, longitude, status, token)"
				+ "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		}else {
			
			ps = conn.prepareStatement("UPDATE sportcenter SET name = ?, address = ?, mobile = ?, email = ?, about = ?, email_verify = ?, "
					+ "mobile_verify = ?, fee_required = ?, open_at = ?, close_at = ?, latitude = ?, longitude = ?, status = ?  WHERE token = ?");
		}
		
		ps.setString(1, name);
		ps.setString(2, address);
		ps.setString(3, mobile);
		ps.setString(4, email);
		ps.setString(5, about);
		ps.setBoolean(6, emailVerify);
		ps.setBoolean(7, mobileVerify);
		ps.setBoolean(8, feeRequired);
		ps.setFloat(9, openAt);
		ps.setFloat(10, closeAt);
		ps.setFloat(11, latitude);
		ps.setFloat(12, longitude);
		ps.setString(13, status);
		ps.setString(14, token);
		
		return ps;
	}
	
}
