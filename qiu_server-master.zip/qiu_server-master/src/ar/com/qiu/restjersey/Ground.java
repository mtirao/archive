package ar.com.qiu.restjersey;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import org.json.JSONException;
import org.json.JSONObject;

import ar.com.qiu.helpers.DbHelper;
import ar.com.qiu.helpers.GroundHelper;
import ar.com.qiu.helpers.JsonHelper;
import ar.com.qiu.model.GroundModel;

@Path("/ground")
public class Ground {
	
	@Path("/all/{tokenId}")
	@GET
	@Produces("application/json")
	public Response getAllSportcenter(@PathParam("tokenId") String tokenId) throws JSONException {
		
		List<GroundModel> grounds = GroundHelper.fetchAll(tokenId);
		
		JSONObject jsonObject = new JSONObject();
		
		jsonObject.put("grounds", grounds);
		return Response.status(200).entity(jsonObject.toString()).build();
	}
	
	@POST
	@Produces("application/json")
	@Consumes("application/json")
	public Response add(String json ) {
		
		Response response = updateGround(json, false);
		return response;
	}
	
	@PUT
	@Produces("application/json")
	@Consumes("application/json")
	public Response update(String json ) {
		
		Response response = updateGround(json, true);
		return response;
	}
	
	private Response updateGround(String json, boolean update) {
		
		JSONObject responseJson = new JSONObject();
		JSONObject requestJson = new JSONObject(json);
		
		Connection conn = DbHelper.getConnection();
		PreparedStatement ps = null;
		
		if(conn != null) {
		
			
			try {
				ps = get(conn, requestJson, update);
				
				int count = ps.executeUpdate();
				
				if(count > 0) {
					responseJson.put("result", "ok");
					return Response.status(200).entity(responseJson.toString()).build();
				}
				
			}catch (SQLException e) {
				e.printStackTrace();
			}  finally {
				
				if(ps != null) {
					try {
						ps.close();
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
				
			}
			
		}
		
		responseJson.put("result", "Bad request");
		return Response.status(400).entity(responseJson.toString()).build();
		
	}

	private PreparedStatement get(Connection conn, JSONObject requestJson, boolean update) throws SQLException {
		
		String name = JsonHelper.getString(requestJson, "name");
		int type = JsonHelper.getInteger(requestJson, "type").intValue();
		long sportcenter = JsonHelper.getInteger(requestJson, "sportcenter").longValue();
		long fee = JsonHelper.getInteger(requestJson, "fee").longValue();
		long price = JsonHelper.getInteger(requestJson, "price").longValue();
		String status = JsonHelper.getString(requestJson, "status");
		String token = JsonHelper.getString(requestJson, "token");
		
		
		PreparedStatement ps = null;
		
		if(!update) {
			ps = conn.prepareStatement("INSERT INTO ground(name, type, sportcenter, fee, price, status, token) "
				+ "VALUES (?,?,?,?,?,?,?)");
		}else {
			
			ps = conn.prepareStatement("UPDATE ground SET name = ?, type = ?, sportcenter = ?, fee = ?, price = ?, status = ? WHERE"
					+ "id = ?" );
		}
		
		ps.setString(1, name);
		ps.setInt(2, type);
		ps.setLong(3, sportcenter);
		ps.setLong(4, fee);
		ps.setLong(5, price);
		ps.setString(6, status);
		
		if(!update) {
			ps.setString(7, token);
		}else {
			long id = JsonHelper.getInteger(requestJson, "id").longValue();
			ps.setLong(7, id);
		}
		
		return ps;
	}
	
}
