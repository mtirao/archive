package ar.com.qiu.restjersey;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import org.json.JSONException;
import org.json.JSONObject;

import ar.com.qiu.helpers.DbHelper;

@Path("/type")
public class Type {
	
	@GET
	@Produces("application/json")
	public Response getAllType() throws JSONException {
			
		JSONObject jsonObject = new JSONObject();
		PreparedStatement ps = null;
		Connection conn = DbHelper.getConnection();
		
		try {
			
			
			ps = conn.prepareStatement("SELECT * FROM sport ORDER BY players DESC");
			
			ResultSet rs = ps.executeQuery();
			
			List<JSONObject> objects = new ArrayList<JSONObject>();
			
			while(rs.next()) {
			        
				String name = rs.getString("name");
				String icon = rs.getString("icon");
				int id = rs.getInt("id");
				int players = rs.getInt("players");

				
				JSONObject type = new JSONObject();
				
				type.put("name", name);
				type.put("icon", icon);
				type.put("players", players);
				type.put("_id", id);
				
				objects.add(type);
				
			}
			
			jsonObject.put("types", objects);
			
			return Response.status(200).entity(jsonObject.toString()).build();
			
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			
			if(ps != null) {
				try {
					ps.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
		}
		
		return null;
	}
		
	
	
	
}
