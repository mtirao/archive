package ar.com.qiu.restjersey;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import org.json.JSONObject;


import ar.com.qiu.helpers.DbHelper;
import ar.com.qiu.helpers.JsonHelper;

@Path("/profile")
public class Profile {
	
	
	@Path("{profileId}")
	@GET
	@Produces("application/json")
	public Response get(@PathParam("profileId") String profileId ) {
		
		JSONObject jsonObject = new JSONObject();
		
		Connection conn = DbHelper.getConnection();
		
		if(conn != null) {
			
			PreparedStatement ps = null;
			
			try {
				ps = conn.prepareStatement("SELECT * FROM profile WHERE token = ? ");
				ps.setString(1, profileId);
				
				ResultSet rs = ps.executeQuery();
				if(rs.next()) {
					
					String name = rs.getString("name");
					String address = rs.getString("address");
					String mobile = rs.getString("mobile");
					String email = rs.getString("email");
					String about = rs.getString("about");
					String token = rs.getString("token");
					String device = rs.getString("device");
					String deviceId = rs.getString("device_id");
					boolean emailVerify = rs.getBoolean("email_verified");
					boolean mobileVerify = rs.getBoolean("mobile_verified");
					boolean feeRequired = rs.getBoolean("facebook_verified");
					
				        
			        jsonObject.put("name", name);
					jsonObject.put("address", address);
					jsonObject.put("mobile", mobile);
					jsonObject.put("email", email);
					jsonObject.put("about", about);
					jsonObject.put("token", token);
					jsonObject.put("device", device);
					jsonObject.put("deviceId", deviceId);
					jsonObject.put("emailVerified", emailVerify);
					jsonObject.put("mobileVerified", mobileVerify);
					jsonObject.put("facebookVerified", feeRequired);
					
					return Response.status(200).entity(jsonObject.toString()).build();
				}
				
				
				
				return Response.status(400).entity(jsonObject.toString()).build();
				
			} catch (SQLException e) {
					e.printStackTrace();
			} finally {
				
				if(ps != null) {
					try {
						ps.close();
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
				
			}
			
		}
		
		jsonObject.put("result", "Bad request");
		return Response.status(400).entity(jsonObject.toString()).build();
	}
	
	@PUT
	@Produces("application/json")
	@Consumes("application/json")
	public Response update(String json ) {
		
		Response response = updateProfile(json, true);
		
		return response;
	}
	
	private Response updateProfile(String json, boolean update) {
		
		JSONObject responseJson = new JSONObject();
		JSONObject requestJson = new JSONObject(json);
		
		Connection conn = DbHelper.getConnection();
		PreparedStatement ps = null;
		
		if(conn != null) {
		
			
			try {
				
				String name = JsonHelper.getString(requestJson, "name");
				String address = JsonHelper.getString(requestJson, "address");
				String mobile = JsonHelper.getString(requestJson, "mobile");
				String email = JsonHelper.getString(requestJson, "email");
				String about = JsonHelper.getString(requestJson, "about");
				String token = JsonHelper.getString(requestJson, "token");
				String device = JsonHelper.getString(requestJson, "device") == null?"": JsonHelper.getString(requestJson, "device");
				String deviceId =  JsonHelper.getString(requestJson, "device_id") == null? "" : JsonHelper.getString(requestJson, "device_id");
				boolean emailVerified = JsonHelper.getBoolean(requestJson, "email_verified");
				boolean mobileVerified = JsonHelper.getBoolean(requestJson, "mobile_verified");
				boolean feeRequired = JsonHelper.getBoolean(requestJson, "facebook_verified");
				
					
				ps = conn.prepareStatement("UPDATE profile SET name = ?, address = ?, mobile = ?, about = ?, device = ?, "
							+ "device_id = ?, email_verified = ?, mobile_verified = ?, facebook_verified = ?, email = ? WHERE token = ?");
				
				
				ps.setString(1, name);
				ps.setString(2, address);
				ps.setString(3, mobile);
				ps.setString(4, about);
				ps.setString(5, device);
				ps.setString(6, deviceId);
				ps.setBoolean(7, emailVerified);
				ps.setBoolean(8, mobileVerified);
				ps.setBoolean(9, feeRequired);
				ps.setString(11, token);
				ps.setString(10, email);
				
				int count = ps.executeUpdate();
				
				if(count > 0) {
					responseJson.put("result", "ok");
					return Response.status(200).entity(responseJson.toString()).build();
				}
				
				
				
			}catch (SQLException e) {
				e.printStackTrace();
			}  finally {
				
				if(ps != null) {
					try {
						ps.close();
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
				
			}
			
		}
		
		responseJson.put("result", "Bad request");
		return Response.status(400).entity(responseJson.toString()).build();
		
	}
	
	
	
}
