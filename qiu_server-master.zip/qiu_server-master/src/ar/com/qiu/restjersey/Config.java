package ar.com.qiu.restjersey;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import org.json.JSONObject;

@Path("/config")
public class Config {
	
	@POST
	@Produces("application/json")
	@Consumes("application/json")
	public Response add(String json ) {
		
		JSONObject responseJson = new JSONObject();
		JSONObject requestJson = new JSONObject(json);
		
		
		responseJson.put("result", "ok");
		return Response.status(200).entity(responseJson.toString()).build();
	}
	
	@PUT
	@Produces("application/json")
	@Consumes("application/json")
	public Response updatePlatform(String json ) {
		
		JSONObject responseJson = new JSONObject();
		JSONObject requestJson = new JSONObject(json);
		
		
		responseJson.put("result", "ok");
		return Response.status(200).entity(responseJson.toString()).build();
	}
	
}
