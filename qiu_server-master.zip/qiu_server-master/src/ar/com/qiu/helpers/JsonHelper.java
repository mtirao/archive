package ar.com.qiu.helpers;

import java.math.BigInteger;

import org.json.JSONException;
import org.json.JSONObject;

public class JsonHelper {
	
	public static String getString(JSONObject json, String field) {
		try {
			return json.getString(field);
		}catch(JSONException e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public static Boolean getBoolean(JSONObject json, String field) {
		try {
			return json.getBoolean(field);
		}catch(JSONException e) {
			e.printStackTrace();
		}
		
		return Boolean.FALSE;
	}
	
	public static BigInteger getInteger(JSONObject json, String field) {
		try {
			return json.getBigInteger(field);
		}catch(JSONException e) {
			e.printStackTrace();
		}
		
		return BigInteger.valueOf(0);
	}
	
	public static Float getFloat(JSONObject json, String field) {
		try {
			return json.getBigDecimal(field).floatValue();
		}catch(JSONException e) {
			e.printStackTrace();
		}
		
		return Float.valueOf(0);
	}
	
}
