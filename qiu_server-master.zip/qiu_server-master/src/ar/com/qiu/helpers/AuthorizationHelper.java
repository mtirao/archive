package ar.com.qiu.helpers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class AuthorizationHelper {
	
	public static String validateToken(String token) {
		
		PreparedStatement ps = null;
		Connection conn = DbHelper.getConnection();
		
		try {
			
			ps = conn.prepareStatement("SELECT * FROM user_auth WHERE token = ?");
			ps.setString(1, token);
			
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()) {
				return rs.getString("token");
			}else {
				return null;
			}
			
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			
			if(ps != null) {
				try {
					ps.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
		}
		
		return null;
	}
	
	public static String tokenByMobile(String mobile, String pass) {
		
		PreparedStatement ps = null;
		Connection conn = DbHelper.getConnection();
		
		try {
			
			ps = conn.prepareStatement("SELECT * FROM user_auth WHERE mobile = ?");
			ps.setString(1, mobile);
			
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()) {	
				if(pass != null) {
					String password = rs.getString("password");
					if(pass.equals(password)) {
						return rs.getString("token");
					}else {
						return null;
					}
				}
				
				return rs.getString("token");
			}else {
				return null;
			}
			
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			
			if(ps != null) {
				try {
					ps.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
		}
		
		return null;
	}

	public static String tokenByEmail(String email, String pass) {
		
		PreparedStatement ps = null;
		Connection conn = DbHelper.getConnection();
		
		try {
			
			ps = conn.prepareStatement("SELECT * FROM user_auth WHERE email = ?");
			ps.setString(1, email);
			
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()) {
				if(pass != null) {
					String password = rs.getString("password");
					if(pass.equals(password)) {
						return rs.getString("token");
					}else {
						return null;
					}
				}
				return rs.getString("token");
			}else {
				return null;
			}
			
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			
			if(ps != null) {
				try {
					ps.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
		}
		
		return null;
	}
	
}
