package ar.com.qiu.helpers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ProfileHelper {
	
	public static int createOrUpdate(String token, String name, String address, String about, String email, String mobile, boolean emailVerified, boolean mobileVerified, boolean facebookVerified) {
		
		PreparedStatement ps = null;
		Connection conn = DbHelper.getConnection();
		
		try {
			
			ps = conn.prepareStatement("SELECT * FROM profile WHERE token = ?");
			ps.setString(1, token);
			
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()) {	
				ps.close();
				
				PreparedStatement update = conn.prepareStatement("UPDATE profile SET name = ?, address = ?, mobile = ?, about = ?, "
						+ "email=?, email_verified = ?, mobile_verified = ?, facebook_verified = ? WHERE token = ?");
				
				update.setString(1, name);
				update.setString(2, address);
				update.setString(3, mobile);
				update.setString(4, about);
				update.setString(5, email);
				update.setBoolean(6, emailVerified);
				update.setBoolean(7, mobileVerified);
				update.setBoolean(8, facebookVerified);
				update.setString(9, token);
				return update.executeUpdate();

				
			}else {
				
				PreparedStatement update = conn.prepareStatement("INSERT INTO profile(name, address, mobile, about, email, email_verified, mobile_verified, facebook_verified, token)"
						+ "VALUES (?,?,?,?,?,?,?,?,?)");
				
				update.setString(1, name);
				update.setString(2, address);
				update.setString(3, mobile);
				update.setString(4, about);
				update.setString(5, email);
				update.setBoolean(6, emailVerified);
				update.setBoolean(7, mobileVerified);
				update.setBoolean(8, facebookVerified);
				update.setString(9, token);
				return update.executeUpdate();
				
			}
			
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			
			if(ps != null) {
				try {
					ps.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
		}
		
		return 0;
		
	}
}
