package ar.com.qiu.helpers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import ar.com.qiu.model.GroundModel;

public class GroundHelper {
	
	
	public static List<GroundModel> fetchAll(String token) {
		
		PreparedStatement ps = null;
		Connection conn = DbHelper.getConnection();
		
		List<GroundModel> grounds = new ArrayList<GroundModel>();
		
		try {
			
			ps = conn.prepareStatement("SELECT * FROM ground WHERE token = ?");
			ps.setString(1, token);
			
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				
				int type = rs.getInt("type");
				String name = rs.getString("name");
				long sportcenter = rs.getLong("sportcenter");
				long fee = rs.getLong("fee");
				long price = rs.getLong("price");
				String status = rs.getString("status");
				long id = rs.getLong("id");
				
				GroundModel ground = new GroundModel(type, name, sportcenter, fee, price, status, id);
				
				grounds.add(ground);
			}
			
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			
			if(ps != null) {
				try {
					ps.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
		}
		
		return grounds;
		
	}
	
}
