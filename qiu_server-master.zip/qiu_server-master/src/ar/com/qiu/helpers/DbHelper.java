package ar.com.qiu.helpers;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.tomcat.jdbc.pool.DataSource;

public class DbHelper {
	
	public static Connection getConnection() {
		
		Connection conn = null;
		try {
			
			InitialContext cxt = new InitialContext();

			DataSource ds = (DataSource) cxt.lookup( "java:/comp/env/jdbc/postgres" );

			if ( ds == null ) {
			   throw new NamingException("Data source not found!");
			}
			
			conn = ds.getConnection();
			
		} catch (NamingException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		
		return conn;
	}
	
}
