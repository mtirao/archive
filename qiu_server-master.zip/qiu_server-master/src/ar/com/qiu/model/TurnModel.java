package ar.com.qiu.model;

import java.math.BigDecimal;
import java.math.BigInteger;

import org.json.JSONObject;

import com.eaio.uuid.UUID;

import ar.com.qiu.helpers.JsonHelper;

public class TurnModel {
	
	private final BigInteger sportcenter;
	private BigInteger ground;
	private final BigInteger type;
	private final String token;
	private final String name;
	private final String phone;
	private final BigDecimal time;
	private final boolean sticky;
	private final BigInteger date;
	private final String status;
	private final UUID partner;
	
	public TurnModel(JSONObject requestJson ) {
		
		sportcenter = JsonHelper.getInteger(requestJson, "sportcenter");
		ground = JsonHelper.getInteger(requestJson, "ground");
		type = JsonHelper.getInteger(requestJson, "type");
		token = JsonHelper.getString(requestJson, "token");
		name = JsonHelper.getString(requestJson, "name");
		phone = JsonHelper.getString(requestJson, "phone");
		time = requestJson.getBigDecimal("time");
		sticky = JsonHelper.getBoolean(requestJson, "is_sticky");
		date =  requestJson.getBigInteger("date");
		status = JsonHelper.getString(requestJson,"status");
		partner = new UUID();
	}

	public BigInteger getSportcenter() {
		return sportcenter;
	}
	
	public void setGround(BigInteger ground) {
		this.ground = ground;
	}

	public BigInteger getGround() {
		return ground;
	}

	public BigInteger getType() {
		return type;
	}

	public String getToken() {
		return token;
	}

	public String getName() {
		return name;
	}

	public String getPhone() {
		return phone;
	}

	public BigDecimal getTime() {
		return time;
	}

	public boolean isSticky() {
		return sticky;
	}

	public BigInteger getDate() {
		return date;
	}

	public String getStatus() {
		return status;
	}

	public UUID getPartner() {
		return partner;
	}
	
}
