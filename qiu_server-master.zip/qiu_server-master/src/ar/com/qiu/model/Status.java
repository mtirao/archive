package ar.com.qiu.model;

public enum Status {
	
	CONFIRMED("confirmed"),
	NEW("new"),
	PAYABLE("payable"),
	PAYED("payed"),
	UNKNOWN("unknown"),
	DELETED("deleted");
	
	private String value;
	
	Status(String value) {
		this.value = value;
	}
	
	@Override
	public String toString() {
		return value;
	}
	
}
