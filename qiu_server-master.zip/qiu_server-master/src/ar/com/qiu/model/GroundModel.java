package ar.com.qiu.model;

public class GroundModel {
	
	private final int type;
	private final String name;
	private final long sportcenter;
	private final long fee;
	private final long price;
	private final String status;
	private final long id;
	
	public GroundModel(int type, String name, long sportcenter, long fee, long price, String status, long id) {
		super();
		this.type = type;
		this.name = name;
		this.sportcenter = sportcenter;
		this.fee = fee;
		this.price = price;
		this.status = status;
		this.id = id;
	}

	public int getType() {
		return type;
	}

	public String getName() {
		return name;
	}

	public long getSportcenter() {
		return sportcenter;
	}

	public long getFee() {
		return fee;
	}

	public long getPrice() {
		return price;
	}

	public String getStatus() {
		return status;
	}
	
	public long getId() {
		return id;
	}
	
    
}
