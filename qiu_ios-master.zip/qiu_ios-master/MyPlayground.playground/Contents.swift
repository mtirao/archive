//: Playground - noun: a place where people can play

import UIKit

public func solution(_ N : Int) -> Int {
    
    var count : [Int] = [0, 0]
    var quotient = N
    
    var gapLength : Int = 0
    
    while(quotient > 1) {
        var rem = quotient % 2
        quotient = quotient / 2
        
        count[rem] += 1
        
        if(count[1] == 2) {
            gapLength = max(gapLength, count[0])
            count[0] = 0
            count[1] = 0
        }
        
    }
    
    return gapLength
}


print(solution(9))
