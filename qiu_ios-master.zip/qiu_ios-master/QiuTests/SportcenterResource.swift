//
//  SportcenterResource.swift
//  QiuTests
//
//  Created by Marcos Tirao on 29/11/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import XCTest

class SportcenterResource: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testExample() {
        
        let expect = expectation(description: "SportcenterResource")
        
        let network = Request()
        
        let sportcenter = SportcenterViewModel(dataProvider: network)
        sportcenter.name = "Prueba"
        sportcenter.address = "Address 1"
        sportcenter.phone = "1111111"
        sportcenter.email = "user@domain.com"
        sportcenter.about = "something about it"
        sportcenter.mobileverify = "true"
        sportcenter.emailverify = "true"
        sportcenter.feerequired = "true"
        
        sportcenter.openAt = "9"
        sportcenter.closeAt = "23"
        sportcenter.latitude = 0.0
        sportcenter.longitude = 0.0

        
        sportcenter.addSportcenter(id: "59b1ab0cab1db42a21f8bf31", completion: {
            expect.fulfill()
        }, error: {(error) -> Void in
            expect.fulfill()
            XCTFail()
        })
        
        waitForExpectations(timeout: 10000) { error in
            
            if let error = error {
                print("Error: \(error.localizedDescription)")
            }
            
            XCTFail()
        }
        
    }
    
    
}
