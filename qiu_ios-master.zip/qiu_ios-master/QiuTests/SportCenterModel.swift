//
//  SportCenterModel.swift
//  QiuTests
//
//  Created by Marcos Tirao on 08/12/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class SportCenterModel: NSObject, SportCenterModelProtocol {
    
    let about = "Something about it"
    let address = "Somewhere"
    let contact = "Impossible"
    let name = "Unamed"
    let phone = "1111111"
    let latitud : Double = 0.0
    let longitude : Double = 0.0
    let openAt : Double = 0.0
    let closeAt : Double = 0.0
    let id = "59e80b699b843d74053a9df1"
    let feerequired = true
    let emailverify = true
    let mobileverify = true
    let isLoad = true
   
    func delete() {
        
    }
    
    func reloadData() {
        
    }
    
}
