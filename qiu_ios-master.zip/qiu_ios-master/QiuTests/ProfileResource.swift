//
//  ProfileResource.swift
//  QiuTests
//
//  Created by Marcos Tirao on 17/11/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import XCTest

class ProfileResource: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    
    
    func testProfile() {
        
        let expect = expectation(description: "ProfileResource")
        
        let dataProvider = Request()
        let profileViewModel = ProfileViewModel(dataProvider: dataProvider)
        
        profileViewModel.profile(token: "eyJhbGciOiJIUzI1NiJ9.TmFO.SuEznsMBQFTX6EnThE3rYRYJTA5U1TCQsJ2TomsQ-gE", completion: {(response) -> Void in
            XCTAssert(response.name == "Marcos Tirao")
            expect.fulfill()
        }, error: { (error) -> Void in

            expect.fulfill()
            print(error! )
            
        })
        
        waitForExpectations(timeout: 10000) { error in
            
            if let error = error {
                print("Error: \(error.localizedDescription)")
            }
            
        }
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
    
}
