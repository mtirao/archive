//
//  AppDelegate.swift
//  QiuTests
//
//  Created by Marcos Tirao on 29/11/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class AppDelegate: NSObject {
    
    var network : Request?
    
    static let sharedInstance = AppDelegate()
        
    private override init() {
        network = Request()
    }
    
    
    
}
