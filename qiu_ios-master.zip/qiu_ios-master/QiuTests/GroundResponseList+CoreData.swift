//
//  GroundResponseList+CoreData.swift
//  QiuTests
//
//  Created by Marcos Tirao on 12/12/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

extension GroundResponseList{
    
    func save() {
        print("Gound saved")
    }

}
