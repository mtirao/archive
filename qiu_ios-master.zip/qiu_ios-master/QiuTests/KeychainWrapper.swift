//
//  KeychainWrapper.swift
//  QiuTests
//
//  Created by Marcos Tirao on 17/11/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class KeychainWrapper: NSObject {
    
    func myObject(forKey: Any) -> Any {
        return "eyJhbGciOiJIUzI1NiJ9.TmFO.SuEznsMBQFTX6EnThE3rYRYJTA5U1TCQsJ2TomsQ-gE"
    }
    
    func mySetObject(object:String, forKey: String) {
        
    }
    
    func writeToKeychain() {
        
    }
}
