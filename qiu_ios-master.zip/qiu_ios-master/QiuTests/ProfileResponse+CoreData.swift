//
//  ProfileResponse.swift
//  QiuTests
//
//  Created by Marcos Tirao on 29/11/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation

extension ProfileResponse {
    
    func save() {
        
        print("Profile saved")
        
    }
    
}
