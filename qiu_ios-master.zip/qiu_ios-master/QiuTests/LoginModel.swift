//
//  LoginModel.swift
//  QiuTests
//
//  Created by Marcos Tirao on 29/11/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class LoginModel {
    
    var token: String = ""
    
    init() {
        load()
    }
    
    func load() {
        
        let keychain = KeychainWrapper()
        if let keychainToken = keychain.myObject(forKey: "v_Data") as? String, keychainToken.count > 0 {
            self.token = keychainToken
        }
        
    }
    
    func delete() {
    
    }
}
