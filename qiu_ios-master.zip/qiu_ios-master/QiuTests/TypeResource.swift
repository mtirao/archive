//
//  TypeResource.swift
//  QiuTests
//
//  Created by Marcos Tirao on 17/11/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import XCTest

class TypeResource: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testTypeResource() {
        
        let expect = expectation(description: "TypeResource")
        
        let dataProvider = Request()
        
        let typeViewModel = TypesViewModel(dataProvider: dataProvider)
        
        typeViewModel.types(completion: {(response) -> Void in
             XCTAssert(response.types.count == 10)
            expect.fulfill()
            
        }, error: { (error) -> Void in
            
           
            expect.fulfill()
            print(error! )
            
        })
        
        waitForExpectations(timeout: 10000) { error in
            
            if let error = error {
                print("Error: \(error.localizedDescription)")
            }
            
        }
    }
   
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
           
        }
    }
    
}
