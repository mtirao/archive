//
//  LoginResource.swift
//  QiuTests
//
//  Created by Marcos Tirao on 28/11/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import XCTest

class LoginResource: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testLoginResource() {
        
        let expect = expectation(description: "LoginResource")
        
        let dataProvider = Request()
        
        let authorized = AuthorizationViewModel(dataProvider: dataProvider)
        
        authorized.authorize(oldPassword: "", newPassword: "password", completion: {(response) -> Void in
            XCTAssert(response.token.count > 0)
            expect.fulfill()
            
        }, error: { (error) -> Void in
            
            expect.fulfill()
            XCTFail()
            
        })
        
        waitForExpectations(timeout: 10000) { error in
            
            if let error = error {
                print("Error: \(error.localizedDescription)")
            }
            
        }
    }
    
    
}
