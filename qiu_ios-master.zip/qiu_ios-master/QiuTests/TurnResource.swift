//
//  TurnResource.swift
//  QiuTests
//
//  Created by Marcos Tirao on 11/12/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import XCTest

class TurnResource: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testTurnBySportcenter() {
        
        let expect = expectation(description: "TurnResource")
        
        let dataProvider = Request()
        
        let turn = TurnViewModel(dataProvider: dataProvider)
        
        turn.turn(completion: {
            expect.fulfill()
        }, error: {(error) -> Void in
            XCTFail()
            
        })
        
        
        waitForExpectations(timeout: 100) { error in
            
            if let error = error {
                print("Error: \(error.localizedDescription)")
            }
            
        }
        
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
    
}
