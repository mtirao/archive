//
//  TurnReponse+CoreData.swift
//  Qiu
//
//  Created by Marcos Tirao on 30/09/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit
import CoreData

extension TurnResponse {
    
    func save() {
        
        let dataController = AppDelegate.dataController!
        
        if !dataController.initalized { 
            return
        }
        
        let request : NSFetchRequest = Turn.fetchRequest()
        request.predicate = NSPredicate(format: "(id == %@)", self._id)
        request.sortDescriptors = [NSSortDescriptor(key: "time", ascending: false)]
        
        
        do {
            let context = dataController.persistentContainer.viewContext
            
            let turn = try context.fetch(request)
            
            if turn.count <= 0 {
                
                let entityDescription = NSEntityDescription.insertNewObject(forEntityName: "Turn", into: context )as! Turn
                
                entityDescription.sportcenter = self.sportcenter?._id
                entityDescription.ground = self.ground?._id
                entityDescription.name = self.name
                entityDescription.phone = self.phone
                entityDescription.time = self.time
                entityDescription.date = self.date
                entityDescription.partner = self.partner
                entityDescription.status = self.status.rawValue
                entityDescription.isstitcky = self.issticky
                entityDescription.id = self._id
                entityDescription.token = self.token
            }else {
                
                turn[0].sportcenter = self.sportcenter?._id
                turn[0].ground = self.ground?._id
                turn[0].name = self.name
                turn[0].phone = self.phone
                turn[0].time = self.time
                turn[0].date = self.date
                turn[0].partner = self.partner
                turn[0].status = self.status.rawValue
                turn[0].isstitcky = self.issticky
                turn[0].id = self._id
                turn[0].token = self.token
            }
            
            context.performAndWait {
                dataController.saveContext()
            }
            
        } catch let error as NSError {
            print("Error in fetch :\(error)")
        }
        
    }
    
}
