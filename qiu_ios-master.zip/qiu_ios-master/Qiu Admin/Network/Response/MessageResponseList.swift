//
//  MessageResponseList.swift
//  Qiu
//
//  Created by Marcos Tirao on 16/12/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation


    
struct MessageResponseList {

    let messages : [MessageResponse]
}


extension MessageResponseList {
    
    init?(json: [Any]?) {
        
        var auxMessage = [MessageResponse]()
        if let message = json {
            for i in message {
                if let messages = MessageResponse(json: i as? [String : Any]) {
                    auxMessage.append(messages)
                }
            }
        }
        
        self.messages = auxMessage
    }
}

