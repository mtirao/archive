//
//  TurnResponse+CoreData.swift
//  Qiu
//
//  Created by Marcos Tirao on 30/09/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation
import CoreData

extension TurnResponseList {
    
    func save() {
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Turn")
        let dataController = AppDelegate.dataController!
        
       
        let context = dataController.persistentContainer.viewContext
        let deleteRequest = NSBatchDeleteRequest( fetchRequest: request)
        context.performAndWait {
            do {
                try context.execute(deleteRequest)
            } catch let error as NSError {
                print("Error in fetch :\(error)")
            }
        }
       
        
        
        for turn in self.turns {
            
            turn.save()
        }
        
    }
    
}
