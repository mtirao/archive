//
//  AuthResponse+CoreData.swift
//  Qiu
//
//  Created by Marcos Tirao on 8/22/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation
import CoreData


extension AuthResponse {

    func save() {
        
        if self.token.count > 0 {
            
            let keychain = KeychainWrapper()
            keychain.mySetObject(self.token, forKey: "v_Data")
            keychain.writeToKeychain()
            Preferences.isLogged = true
        }
        
    }
    
}
