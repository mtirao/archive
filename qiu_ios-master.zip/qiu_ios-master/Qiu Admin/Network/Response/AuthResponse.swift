//
//  Response.swift
//  Qiu
//
//  Created by Marcos Tirao on 8/18/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation
import CoreData

struct AuthResponse {
    let token: String
}


extension AuthResponse {
    
    init?(json: [String: Any]?) {

        if let token = json?["token"] as? String {
            self.token = token
        }else {
            self.token = ""
        }
        
    }
    
}
