//
//  GroundResponse.swift
//  Qiu
//
//  Created by Marcos Tirao on 9/8/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation

struct GroundResponse {

    let name : String
    let type : String
    let center : String
    let fee : Int16
    let price : Int16
    let _id : String
 
}

extension GroundResponse {
    
    init?(json: [String: Any]?) {
        
        
        if let name = json?["name"] as? String {
            self.name = name
        }else {
            self.name = ""
        }
        
        if let type = json?["type"] as? String {
            self.type = type
        }else {
            self.type = ""
        }
        
        if let center = json?["center"] as? String {
            self.center = center
        }else {
            self.center = ""
        }
        
        if let id = json?["_id"] as? String {
            self._id = id
        }else {
            self._id = ""
        }
        
        if let fee = json?["fee"] as? Int16 {
            self.fee = fee
        }else {
            self.fee = 0
        }
        if let price = json?["price"] as? Int16 {
            self.price = price
        }else {
            self.price = 0
        }
    }
    
}
