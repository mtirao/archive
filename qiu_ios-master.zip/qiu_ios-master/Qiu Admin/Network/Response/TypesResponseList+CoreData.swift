//
//  TypesResponse+CoreData.swift
//  Qiu
//
//  Created by Marcos Tirao on 8/22/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit
import CoreData

extension TypesResponseList {
    
    func save() {
        
        let dataController = AppDelegate.dataController!
        
        if !dataController.initalized {
            return
        }
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Types")
        
        let context = dataController.persistentContainer.viewContext
        let deleteRequest = NSBatchDeleteRequest( fetchRequest: request)
        
        context.performAndWait {
            do {
                try context.execute(deleteRequest)
                
                for type in self.types {
                    let entityDescription = NSEntityDescription.insertNewObject(forEntityName: "Types", into: context )as! Types
                    
                    entityDescription.name = type.name
                    entityDescription.players = Int16(type.players)
                    entityDescription.id = type._id
                }
                
                dataController.saveContext()
                
                NotificationController.postNotification(name: Notes.coreDataTypeLoaded.notification, userInfo: nil)
            } catch let error as NSError {
                print("Error in fetch :\(error)")
            }
        }
            
        
    }
}
