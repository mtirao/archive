//
//  TurnModel.swift
//  Qiu
//
//  Created by Marcos Tirao on 30/09/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation

struct TurnResponse {
    
    let sportcenter : SportCenterResponse?
    let ground : GroundResponse?
    let token : String
    let name : String
    let phone : String
    let time : Float
    let date : Int64
    let status : TurnStatus
    let issticky : Bool
    let partner : String
    let _id : String
}

extension TurnResponse {
    
    enum TurnStatus : String {
        case paid = "paid"
        case new = "new"
        case billable = "billable"
        case delete = "deleted"
        case confirmed = "confirmed"
    }
    
    init?(json: [String: Any]?) {
        
        
        self.sportcenter = SportCenterResponse(json: json?["sportcenter"] as? [String : Any])
        self.ground = GroundResponse(json:json?["ground"] as? [String : Any])
        
        
        if let name = json?["name"] as? String {
            self.name = name
        }else {
            self.name = ""
        }
        
        if let phone = json?["phone"] as? String {
            self.phone = phone
        }else {
            self.phone = ""
        }
        
        if let time = json?["time"] {
            self.time = time as! Float //(Theme.isoDateToDate(isoDate: from) as NSDate?) ?? NSDate()
        }else {
            self.time = 0
        }
        
        if let date = json?["date"]{
            self.date = date as! Int64//(Theme.isoDateToDate(isoDate: to) as NSDate?) ?? NSDate()
        }else {
            self.date = 0
        }
        
        if let statusString = json?["status"] as? String, let status = TurnStatus(rawValue:statusString) {
            self.status = status
        }else {
            return nil
        }
        
        if let token = json?["token"] as? String {
            self.token = token
        }else {
            self.token = ""
        }
        
        if let issticky = json?["isSticky"] as? Bool {
            self.issticky = issticky
        }else {
            self.issticky = false
        }
        
        if let partner = json?["partner"] as? String {
            self.partner = partner
        }else {
            self.partner = ""
        }
        
        if let id = json?["_id"] as? String {
            self._id = id
        }else {
            self._id = ""
        }
        
    }
}
