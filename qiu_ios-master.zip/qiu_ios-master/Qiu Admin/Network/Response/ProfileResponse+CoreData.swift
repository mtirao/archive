//
//  ProfileResponse+CoreData.swift
//  Qiu
//
//  Created by Marcos Tirao on 8/30/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation
import CoreData

extension ProfileResponse {
    
    func save() {
        
        let dataController = AppDelegate.dataController!
        
        if !dataController.initalized {
            return
        }
        
        let request : NSFetchRequest = Profile.fetchRequest()
        
        do {
            let context = dataController.persistentContainer.viewContext
            
            let profile = try context.fetch(request)
            
            
            if profile.count <= 0 {
                
                let entityDescription = NSEntityDescription.insertNewObject(forEntityName: "Profile", into: context )as! Profile

                entityDescription.name = self.name
                entityDescription.name = self.name
                entityDescription.email = self.email
                entityDescription.about = self.about
                entityDescription.address = self.address
                entityDescription.mobile = self.mobile
                entityDescription.emailVerified = self.emailVerified
                entityDescription.mobileVerified = self.mobileVerified
                entityDescription.facebookVerified = self.facebookVerified

            }else {
                
                profile[0].name = self.name
                profile[0].email = self.email
                profile[0].about = self.about
                profile[0].address = self.address
                profile[0].mobile = self.mobile
                profile[0].emailVerified = self.emailVerified
                profile[0].mobileVerified = self.mobileVerified
                profile[0].facebookVerified = self.facebookVerified
            }
            
            dataController.saveContext()
            
        } catch let error as NSError {
            print("Error in fetch :\(error)")
        }

        
    }
    
}
