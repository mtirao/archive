//
//  SportCenterResponseList.swift
//  Qiu
//
//  Created by Marcos Tirao on 20/10/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation

struct SportCenterResponseList {
    let sportCenters : [SportCenterResponse]
    
}

extension SportCenterResponseList {
    
    init?(json: [Any]?) {
        
        var auxSportcenter = [SportCenterResponse]()
        if let result = json {
            for i in result {
                if let sportcenter = SportCenterResponse(json: i as? [String : Any]) {
                    auxSportcenter.append(sportcenter)
                }
            }
        }
        
        self.sportCenters = auxSportcenter
    }
}
