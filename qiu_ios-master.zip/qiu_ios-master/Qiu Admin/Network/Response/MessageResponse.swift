//
//  MessageResponse.swift
//  Qiu
//
//  Created by Marcos Tirao on 15/12/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation

struct MessageResponse {

    let from : String
    let to : String
    let type : MessageType
    let status : String
    let title : String
    let message : String
    let createAt: NSDate
    let _id : String
}

extension MessageResponse {
    
    enum MessageType: String {
        case query = "query"
        case notification = "notification"
        case suggestion = "suggestion"
    }
    
    enum MessageRecipient: String {
        case support = "support"
        case development = "development"
        case marketing = "contact"
    }
    
    init?(json: [String: Any]?) {
        
        if let from = json?["from"] as? String {
            self.from = from
        }else {
            self.from = ""
        }
        
        if let to = json?["to"] as? String {
            self.to = to
        }else {
            return nil
        }
        
        if let status = json?["status"] as? String {
            self.status = status
        }else {
            self.status = ""
        }
        
        if let title = json?["title"] as? String {
            self.title = title
        }else {
            self.title = ""
        }
        
        if let message = json?["message"] as? String {
            self.message = message
        }else {
            self.message = ""
        }
        
        if let type = json?["type"] as? String, let messageType = MessageType(rawValue:type) {
            self.type = messageType
        }else {
            return nil
        }
        
        if let id = json?["_id"] as? String {
            self._id = id
        }else {
            self._id = ""
        }
        
        if let from = json?["createAt"] as? String {
            self.createAt = (Theme.isoDateToDate(isoDate: from) as NSDate?) ?? NSDate()
        }else {
            self.createAt = NSDate()
        }
        
    }
    
}



