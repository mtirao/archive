//
//  TypesResponse.swift
//  Qiu
//
//  Created by Marcos Tirao on 8/22/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation

struct TypesResponseList {
    
    let types : [TypeResponse]
}

extension TypesResponseList {
    
    init?(json: [Any]?) {
        
        var auxTypes = [TypeResponse]()
        if let result = json {
            for i in result {
                if let type = TypeResponse(json: i as? [String : Any]) {
                    auxTypes.append(type)
                }
            }
        }
        self.types = auxTypes
    }
    
}
