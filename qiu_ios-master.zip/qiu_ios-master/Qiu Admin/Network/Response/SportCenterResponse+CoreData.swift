//
//  SportCenterResponse+CoreData.swift
//  Qiu
//
//  Created by Marcos Tirao on 9/6/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation
import CoreData

extension SportCenterResponse {

    func save() {
        
       let dataController = AppDelegate.dataController!
        
        if !dataController.initalized {
            return
        }
        
        let request : NSFetchRequest = SportCenter.fetchRequest()
        
        do {
            let context = dataController.persistentContainer.viewContext
            
            let sportCenter = try context.fetch(request)
            
            
            if sportCenter.count <= 0 {
                
                let entityDescription = NSEntityDescription.insertNewObject(forEntityName: "SportCenter", into: context )as! SportCenter
                
                entityDescription.about = self.about
                entityDescription.address = self.address
                entityDescription.email = self.email
                entityDescription.emailverify = self.emailverify
                entityDescription.mobile = self.mobile
                entityDescription.mobileverify = self.mobileverify
                entityDescription.name = self.name
                entityDescription.feerequired = self.feerequired
                entityDescription.latitude = self.latitude
                entityDescription.longitude = self.longitude
                entityDescription.openAt = self.openAt
                entityDescription.closeAt = self.closeAt
                entityDescription.id = self._id
                
            }else {
                
                sportCenter[0].about = self.about
                sportCenter[0].address = self.address
                sportCenter[0].email = self.email
                sportCenter[0].emailverify = self.emailverify
                sportCenter[0].mobile = self.mobile
                sportCenter[0].mobileverify = self.mobileverify
                sportCenter[0].name = self.name
                sportCenter[0].feerequired = self.feerequired
                sportCenter[0].latitude = self.latitude
                sportCenter[0].longitude = self.longitude
                sportCenter[0].openAt = self.openAt
                sportCenter[0].closeAt = self.closeAt
                sportCenter[0].id = self._id
                
            }
            
            dataController.saveContext()
            
        } catch let error as NSError {
            print("Error in fetch :\(error)")
        }
        
        
    }

}
