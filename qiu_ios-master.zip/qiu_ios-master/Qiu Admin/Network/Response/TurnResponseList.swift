//
//  TurnResponseList.swift
//  Qiu
//
//  Created by Marcos Tirao on 30/09/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation

struct TurnResponseList {
    let turns : [TurnResponse]
}

extension TurnResponseList {
    
    init?(json: [Any]?) {
        
        var auxTurn = [TurnResponse]()
        
        if let data = json {
            for i in data{
                if let turn = TurnResponse(json: i as? [String : Any]) {
                    auxTurn.append(turn)
                }
            }
        }
    
        self.turns = auxTurn
    }
}
