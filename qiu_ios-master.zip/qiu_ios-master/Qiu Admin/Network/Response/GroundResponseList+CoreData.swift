//
//  GroundResponseList+CoreData.swift
//  Qiu
//
//  Created by Marcos Tirao on 9/24/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation

extension GroundResponseList {
    
    func save() {
        
        for ground in self.grounds {
            ground.save()
        }
        
    }
    
}
