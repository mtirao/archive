//
//  Type.swift
//  Qiu
//
//  Created by Marcos Tirao on 8/21/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation
import CoreData

struct TypeResponse {
    
    let _id : String
    let name: String
    let players : Int
    
}


extension TypeResponse {
    
    init?(json: [String: Any]?) {
        
        guard let _id = json?["id"] as? Int,
            let name = json?["name"] as? String,
            let players = json?["players"] as? Int else {
                
                return nil
        }
        
        self._id = "\(_id)"
        self.name = name
        self.players = players
    }

}
