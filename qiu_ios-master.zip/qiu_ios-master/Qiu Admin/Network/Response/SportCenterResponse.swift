//
//  SportCenterResponse.swift
//  Qiu
//
//  Created by Marcos Tirao on 9/6/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation

struct SportCenterResponse {
    
    let name : String
    let address : String
    let mobile : String
    let email : String
    let about : String
    let mobileverify : Bool
    let emailverify : Bool
    let feerequired: Bool
    let openAt : Double
    let closeAt : Double
    let latitude : Double
    let longitude : Double
    let _id : String
    let status : String
   
}

extension SportCenterResponse {
    
    init?(json: [String: Any]?) {
        
        if let name = json?["name"] as? String {
            self.name = name
        }else {
            self.name = ""
        }
        
        if let address = json?["address"] as? String {
            self.address = address
        }else {
            self.address = ""
        }
        
        if let mobile = json?["phone"] as? String {
            self.mobile = mobile
        }else {
            self.mobile = ""
        }
        
        if let email = json?["email"] as? String {
            self.email = email
        }else {
            self.email = ""
        }
        
        if let about = json?["description"] as? String {
            self.about = about
        }else {
            self.about = ""
        }
        
        if let mobileverify = json?["mobileverify"] as? Bool {
            self.mobileverify = mobileverify
        }else {
            self.mobileverify = false
        }
        
        if let emailverify = json?["emailverify"] as? Bool {
            self.emailverify = emailverify
        }else {
            self.emailverify = false
        }
        
        if let feerequired = json?["feerequired"] as? Bool {
            self.feerequired = feerequired
        }else {
            self.feerequired = false
        }
        
        if let openAt = json?["openAt"] as? Double {
            self.openAt = openAt
        }else {
            self.openAt = 0
        }
        
        if let closeAt = json?["closeAt"] as? Double {
            self.closeAt = closeAt
        }else {
            self.closeAt = 23
        }
        
        
        
        
        if let latitude = json?["latitude"] as? Double {
            self.latitude = latitude
        }else {
            self.latitude = 0
        }
        
        if let longitude = json?["longitude"] as? Double {
            self.longitude = longitude
        }else {
            self.longitude = 0
        }
        
        if let token = json?["_id"] as? String {
            self._id = token
        }else {
            self._id = ""
        }
        
        if let status = json?["status"] as? String {
            self.status = status
        }else {
            self.status = ""
        }
    }
    
}
