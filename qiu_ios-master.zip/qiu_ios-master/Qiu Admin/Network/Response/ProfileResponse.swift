//
//  ProfileResponse.swift
//  Qiu
//
//  Created by Marcos Tirao on 8/30/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation

struct ProfileResponse {
    
    let name : String
    let address : String
    let mobile : String
    let email : String
    let about : String
    let mobileVerified : Bool
    let emailVerified : Bool
    let facebookVerified : Bool
    
 }


extension ProfileResponse {
    
    init?(json: [String: Any]?) {
        
        if let name = json?["name"] as? String {
            self.name = name
        }else {
            self.name = ""
        }
        
        if let address = json?["address"] as? String {
            self.address = address
        }else {
            self.address = ""
        }
        
        if let mobile = json?["mobile"] as? String {
            self.mobile = mobile
        }else {
            self.mobile = ""
        }
        
        if let email = json?["email"] as? String {
            self.email = email
        }else {
            self.email = ""
        }
        
        if let about = json?["about"] as? String {
            self.about = about
        }else {
            self.about = ""
        }
        
        if let mobileVerified = json?["mobileVerified"] as? Bool {
            self.mobileVerified = mobileVerified
        }else {
            self.mobileVerified = false
        }
        
        if let emailVerified = json?["emailVerified"] as? Bool {
            self.emailVerified = emailVerified
        }else {
            self.emailVerified = false
        }
        
        if let facebookVerified = json?["facebookVerified"] as? Bool {
            self.facebookVerified = facebookVerified
        }else {
            self.facebookVerified = false
        }
    }
}
