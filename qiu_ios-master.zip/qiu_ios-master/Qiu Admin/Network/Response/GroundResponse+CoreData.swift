//
//  GroundResponse+CoreData.swift
//  Qiu
//
//  Created by Marcos Tirao on 9/21/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation
import CoreData

extension GroundResponse{
    
    func save() {
        
        let dataController = AppDelegate.dataController!
        
        if !dataController.initalized {
            return
        }
        
        let request : NSFetchRequest = Ground.fetchRequest()
        request.predicate = NSPredicate(format: "(id == %@)", self._id)
        request.sortDescriptors = [NSSortDescriptor(key: "name", ascending: false)]
        
        
        do {
            let context = dataController.persistentContainer.viewContext
            
            let ground = try context.fetch(request)
            
            if ground.count <= 0 {
                
                let entityDescription = NSEntityDescription.insertNewObject(forEntityName: "Ground", into: context )as! Ground
                
                entityDescription.name = self.name
                entityDescription.type = self.type
                entityDescription.center = self.center
                entityDescription.id = self._id
                entityDescription.fee = self.fee as Int16
                entityDescription.price = self.price as Int16
                
            }else {
                
                ground[0].name = self.name
                ground[0].type = self.type
                ground[0].center = self.center
                ground[0].id = self._id
                ground[0].fee = self.fee as Int16
                ground[0].price = self.price as Int16
            }
            
            context.performAndWait {
                dataController.saveContext()
            }
            
            
        } catch let error as NSError {
            print("Error in fetch :\(error)")
        }
        
    }
    
}
