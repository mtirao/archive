//
//  GroundResponseList.swift
//  Qiu
//
//  Created by Marcos Tirao on 9/24/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation

struct GroundResponseList {
    
    let grounds: [GroundResponse]
    
}

extension GroundResponseList {
    
    init?(json: [Any]) {
        
        var auxGround = [GroundResponse]()
        for i in json {
            if let ground = GroundResponse(json: i as? [String : Any]) {
                auxGround.append(ground)
            }
        }
        
        
        self.grounds = auxGround
    }
}
