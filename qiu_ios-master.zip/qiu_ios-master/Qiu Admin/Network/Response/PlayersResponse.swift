//
//  PlayersRespnse.swift
//  Qiu
//
//  Created by Marcos Tirao on 04/11/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation

struct PlayersResponse {
    let code : Int
    let count : Int
}

extension PlayersResponse {
    init?(json: [String: Any]?) {
        
        var result : [String : Any] = [String : Any]()
        
        if let res = json?["result"] as? [String: Any] {
            result = res
        }else {
            result = json!
        }
        
        if let code = result["code"] as? Int {
            self.code = code
        }else {
            self.code = 400
        }
        
        if let count = result["count"] as? Int {
            self.count = count
        }else {
            self.count = 0
        }
        
    }
}

