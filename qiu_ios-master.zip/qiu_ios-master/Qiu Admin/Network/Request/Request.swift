//
//  Network.swift
//  Reddit
//
//  Created by Marcos Tirao on 4/6/16.
//  Copyright © 2016 Marcos Tirao. All rights reserved.
//

import Foundation
import SystemConfiguration

enum ErrorResponse : Error {
    case unknownError
    case authorizedFailedError
    case serverUnreachableError
    case responseError
    case serializationError
    case networkError
    case requestFailedError
}

enum HTTPMethod: String {
    case POST = "POST"
    case GET = "GET"
    case PUT = "PUT"
    case DELETE = "DELETE"
}

class Request: DataProvider {
    

    //MARK:- Private request    
    private func isConnectedToNetwork() -> Bool {
        
        var zeroAddress = sockaddr_in(sin_len: 0, sin_family: 0, sin_port: 0, sin_addr: in_addr(s_addr: 0), sin_zero: (0, 0, 0, 0, 0, 0, 0, 0))
        zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
        zeroAddress.sin_family = sa_family_t(AF_INET)
        
        guard let defaultRouteReachability = withUnsafePointer(to: &zeroAddress, {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                SCNetworkReachabilityCreateWithAddress(nil, $0)
            }
        }) else {
            return false
        }
        
        var flags: SCNetworkReachabilityFlags = SCNetworkReachabilityFlags(rawValue: 0)
        if SCNetworkReachabilityGetFlags(defaultRouteReachability, &flags) == false {
            return false
        }
        let isReachable = (flags.rawValue & UInt32(kSCNetworkFlagsReachable)) != 0
        let needsConnection = (flags.rawValue & UInt32(kSCNetworkFlagsConnectionRequired)) != 0
        return (isReachable && !needsConnection)        
    }
    
    func makeRequest(url: String, method: HTTPMethod, parameters: RequestProtocol?,  completion:@escaping (Data?) -> Void, error: @escaping (ErrorResponse) -> Void) {
        
        self.makeInternalRequest(url: url, method: method, parameters:parameters,  completion:completion, error: error)?.resume()
        
    }
    
    private func makeInternalRequest(url: String, method: HTTPMethod = .POST, parameters: RequestProtocol?=nil,  completion:@escaping (Data?) -> Void, error: @escaping (ErrorResponse) -> Void) -> URLSessionDataTask?  {
        
        
        var task : URLSessionDataTask? = nil
        
        if let httpUrl = NSURL(string: url, relativeTo: nil) as URL? {
            
            // create post request
            var request : URLRequest = URLRequest(url: httpUrl)
            
            request.timeoutInterval = 30
            
            if method == .POST || method == .PUT || method == .DELETE {
                request = URLRequest(url: httpUrl)
                request.httpMethod = method.rawValue
                
                // insert json data to the request
                request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
                if let postParameters = parameters?.dictionary(),  let jsonData = try? JSONSerialization.data(withJSONObject: postParameters) {
                    request.httpBody = jsonData
                    let json = String(data:request.httpBody!, encoding:.utf8)
                    print("JSON Data: \(json!)")
                }
            }else if method == .GET {
                
                let urlComponents = NSURLComponents(string: url)
                
                if let param = parameters?.dictionary() {
                    var items = [URLQueryItem]()
                    for (key, element) in param {
                        let item = URLQueryItem(name: key, value: element as? String)
                        items.append(item)
                    }
                    urlComponents?.queryItems = items
                }
                
                request = URLRequest(url: urlComponents?.url ?? httpUrl)
                request.httpMethod = "GET"

            }
        
        
            task = URLSession.shared.dataTask(with: request) { data, response, errResponse in
            
                if let err = errResponse {
                    print(err)
                    error(.unknownError)
                } else if let httpResponse = response as? HTTPURLResponse {
                    if httpResponse.statusCode >= 200 || httpResponse.statusCode <= 209 {
                        let json = String(data:data!, encoding:.utf8)
                        print("JSON Data: \(json!)")
                        completion(data)
                    }else {
                        error(.responseError)
                    }
                
                }
            }
            
        }else {
            error(.serverUnreachableError)
        }
        
        if !isConnectedToNetwork() {
            error(.networkError)
            return nil
        }
        
        return task
    }
}
