//
//  MessageRequest.swift
//  Qiu
//
//  Created by Marcos Tirao on 08/04/2018.
//  Copyright © 2018 Marcos Tirao. All rights reserved.
//

import UIKit

class MessageRequest: RequestProtocol {
    
    
    let to:MessageResponse.MessageRecipient
    let title:String
    let message: String
    let type: MessageResponse.MessageType

    var token: String?
    
    init(to: MessageResponse.MessageRecipient, title:String, message: String, type: MessageResponse.MessageType) {
        self.to = to
        self.title = title
        self.message = message
        self.type = type
        
        let loginModel = LoginModel()
        loginModel.load()
        
        if loginModel.token.count > 10 {
            self.token = loginModel.token
        }
        
    }
    
    func dictionary() -> [String : Any] {
        var param : [String : String] = [String: String]()
        
        param["to"] = to.rawValue
        param["title"] = title
        param["message"] = message
        param["type"] = type.rawValue
        
        if(self.token != nil) {
            param["token"] = self.token 
        }
        
        return param
    }
    
}
