//
//  LoginRequest.swift
//  Qiu
//
//  Created by Marcos Tirao on 08/04/2018.
//  Copyright © 2018 Marcos Tirao. All rights reserved.
//

import UIKit

class LoginRequest: RequestProtocol {
    
    let password: String
    let name: String
    let email: String
    let mobile: String
    let token: String
    let oldPassword: String
    
    init(password:String="", name:String="", email:String="", mobile:String="", oldPasswrod:String="") {
        self.password = password
        self.name = name
        self.email = email
        self.mobile = mobile
        self.oldPassword = oldPasswrod
        
        let loginModel = LoginModel()
        loginModel.load()
        
        if loginModel.token.count > 10 {
            self.token = loginModel.token
        }else {
            self.token = ""
        }
        
    }
    
    func dictionary() -> [String : Any] {
        
        var param : [String : String] = [String: String]()
        
        
        if password.count > 0 {
            param["password"] = password
        }
        
        if name.count > 0{
            param["name"] = name
        }
        
        if email.count > 0 {
            param["email"] = email
        }
        
        if mobile.count > 0 {
            param["mobile"] = mobile
        }
        
        if token.count > 0 {
            param["token"] = token
        }
        
        if oldPassword.count > 0 {
            param["old_password"] = oldPassword
        }
        
        return param
    }

}
