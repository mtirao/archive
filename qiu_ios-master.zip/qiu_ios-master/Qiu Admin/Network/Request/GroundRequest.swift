//
//  GroundRequest.swift
//  Qiu
//
//  Created by Marcos Tirao on 08/04/2018.
//  Copyright © 2018 Marcos Tirao. All rights reserved.
//

import UIKit

class GroundRequest: RequestProtocol {
    
    
    var type: String?
    var name: String?
    var price: NSNumber?
    var fee: NSNumber?
    var sportcenter: String?
    
    
    func dictionary() -> [String : Any] {
        
        var parameters : [String: String] = [String: String]()
        
        if type != nil {
            parameters["type"] = type!
        }
        
        if name != nil {
            parameters["name"] = name
        }
        
        if price != nil {
            parameters["price"] = String(price!.int8Value)
        }
        
        if fee != nil {
            parameters["fee"] = String(fee!.int8Value)
        }
        
        if sportcenter != nil {
            parameters["sportcenter"] = sportcenter!
        }
        
        let loginModel = LoginModel()
        loginModel.load()
        if loginModel.token.count > 10 {
            parameters["token"] = loginModel.token
        }
        
        return parameters
    }
}
