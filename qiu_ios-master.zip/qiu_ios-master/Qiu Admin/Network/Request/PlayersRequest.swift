//
//  PlayersRequest.swift
//  Qiu
//
//  Created by Marcos Tirao on 08/04/2018.
//  Copyright © 2018 Marcos Tirao. All rights reserved.
//

import UIKit
import Contacts

class PlayersRequest: RequestProtocol {
    
    
    var turnId:String?
    var contacts: [(selected: Bool, contact: CNContact)]?
    
    func dictionary() -> [String : Any] {
        
        var parameters : [String: Any] = [String: Any]()
        
        var jsonContact : [[String : String]] = [[String : String]]()
        
        if contacts != nil {
            for contact in contacts! {
                if( contact.selected ) {
                    jsonContact.append(contactToJson(contact: contact.contact))
                }
            }
        }
        
        parameters["turnId"] = self.turnId
        parameters["players"] = jsonContact
        
        return parameters
    }
    
    
    private func contactToJson(contact: CNContact) -> [String : String] {
        var json : [String : String] = [String : String]()
        
        let formatter = CNContactFormatter()
        
        json["name"] = formatter.string(from: contact)
        
        let phoneNumbers = contact.phoneNumbers
        for phone in phoneNumbers {
            json["phone"] = phone.value.stringValue
        }
        
        return json
    }
    
}
