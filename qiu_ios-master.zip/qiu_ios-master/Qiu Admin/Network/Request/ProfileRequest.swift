//
//  ProfileRequest.swift
//  Qiu
//
//  Created by Marcos Tirao on 08/04/2018.
//  Copyright © 2018 Marcos Tirao. All rights reserved.
//

import UIKit

class ProfileRequest: RequestProtocol {
    
    var name: String?
    var mobile: String?
    var email: String?
    var about: String?
    var address: String?
    var deviceId: String?
    
    var mobileVerified: Bool = false
    var facebookVerified: Bool = false
    var emailVerified: Bool = false
    
    func dictionary() -> [String : Any] {
        
        var param:[String: String] = [String:String]()
        
        let loginModel = LoginModel()
        loginModel.load()
        
        if loginModel.token.count > 10 {
            param["token"] = loginModel.token
        }
        
        if name != nil {
            param["name"] = name!
        }
        
        if mobile != nil {
            param["mobile"] = mobile!
        }
        
        if email != nil {
            param["email"] = email!
        }
        
        if about != nil {
            param["about"] = about!
        }
        
        if address != nil {
            param["address"] = address!
        }
        
        if deviceId != nil {
            param["deviceid"] = deviceId!
        }

        param["email_verified"] = emailVerified.description
        param["mobile_verified"] = mobileVerified.description
        param["facebook_verified"] = facebookVerified.description
        
        return param
    }
    

}
