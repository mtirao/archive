//
//  RequestProtocol.swift
//  Qiu
//
//  Created by Marcos Tirao on 07/04/2018.
//  Copyright © 2018 Marcos Tirao. All rights reserved.
//

import UIKit

protocol RequestProtocol : class {
    
    func dictionary() -> [String : Any]

}
