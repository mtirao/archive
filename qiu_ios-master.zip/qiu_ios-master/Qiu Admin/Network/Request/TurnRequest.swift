//
//  TurnRequest.swift
//  Qiu
//
//  Created by Marcos Tirao on 08/04/2018.
//  Copyright © 2018 Marcos Tirao. All rights reserved.
//

import UIKit

class TurnRequest: RequestProtocol {
    
    var status : TurnResponse.TurnStatus?
    var sportcenter: String?
    var court: String?
    var name: String?
    var phone: String?
    var time: Float = 0
    var date: Int64 = 0
    var sticky: Bool?
    var type: String?
    var partner: String?
  
    
    func dictionary() -> [String : Any] {
        
        var param: [String: String] = [String:String]()
        
        if sportcenter != nil {
            param["sportcenter"] = sportcenter!
        }
        
        if status != nil {
            param["status"] = status!.rawValue
        }
        
        let loginModel = LoginModel()
        loginModel.load()
        
        if loginModel.token.count > 10 {
            param["token"] = loginModel.token
        }
        
        if sportcenter != nil {
            param["sportcenter"] = self.sportcenter!
        }
        
        if court != nil {
            param["ground"] = self.court!
        }
        
        if name != nil {
            param["name"] = name!
        }
        
        if phone != nil {
            param["phone"] = phone!
        }
        
        param["time"] = "\(time)" //time!
        
        
        param["date"] = "\(date)"
        
        
        if sticky != nil {
            param["sticky"] = "\(sticky!)"
        }
        
        if type != nil {
            param["type"] = type!
        }
        
        if status != nil {
            param["status"] = status!.rawValue
        }
        
        if partner != nil {
            param["partner"] = partner!
        }
        
        return param
        
    }
    
    
    
}
