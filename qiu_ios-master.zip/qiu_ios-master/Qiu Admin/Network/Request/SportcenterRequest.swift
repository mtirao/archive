//
//  SportcenterRequest.swift
//  Qiu
//
//  Created by Marcos Tirao on 08/04/2018.
//  Copyright © 2018 Marcos Tirao. All rights reserved.
//

import UIKit

class SportcenterRequest: RequestProtocol {
    
    var name: String?
    var address: String?
    var phone : String?
    var email : String?
    var about : String?
    var mobileverify : String?
    var emailverify : String?
    var feerequired : String?
    var openAt : CGFloat?
    var closeAt : CGFloat?
    var latitude : Double?
    var longitude : Double?
    var status : String?
    
    
    func dictionary() -> [String : Any] {
        
        var parameters : [String : String] = [String : String]()
        
        if name != nil {
            parameters["name"] = name!
        }
        
        if address != nil {
            parameters["address"] = address
        }
        
        if phone != nil {
            parameters["mobile"] = phone
        }
        
        if email != nil {
            parameters["email"] = email
        }
        
        if about != nil {
            parameters["about"] = about
        }
        
        if mobileverify != nil {
            parameters["mobile_verify"] = mobileverify
        }
        
        if emailverify != nil {
            parameters["email_verify"] = emailverify
        }
        
        if feerequired != nil {
            parameters["fee_required"] = feerequired
        }
        
        
        let loginModel = LoginModel()
        loginModel.load()
        if loginModel.token.count > 10 {
            parameters["token"] = loginModel.token
        }
        
        if openAt != nil {
            parameters["open_at"] = "\(openAt!)"
        }
        
        if closeAt != nil {
            parameters["close_at"] = "\(closeAt!)"
        }
        
        if latitude != nil && longitude != nil {
            parameters["latitude"] = "\(latitude!)"
            parameters["longitude"] = "\(longitude!)"
        }
        
        if status != nil {
            parameters["status"] = "\(status!)"
        }
        
        return parameters
        
    }

    
}
