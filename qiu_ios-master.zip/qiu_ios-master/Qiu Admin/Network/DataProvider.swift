//
//  DataProvider.swift
//  Qiu
//
//  Created by Marcos Tirao on 29/11/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

let environment = "dev"

protocol DataProvider: class {
    
    func makeRequest(url: String, method: HTTPMethod, parameters: RequestProtocol?,  completion:@escaping (Data?) -> Void, error: @escaping (ErrorResponse) -> Void)
}


extension DataProvider {
    
    static func url(resource: String) -> String{
        
        let path = Bundle.main.path(forResource: "Network", ofType: "plist")
        let dict = NSDictionary(contentsOfFile: path!) as! [String : Any]
        
        
        guard let env = dict[environment] as? [String: String] else{
            return ""
        }
        
        if Preferences.serverIp.count > 0 {
            return Preferences.serverIp + env[resource]!
        }
        
        return env["url"]! + env[resource]!
        
    }
    
}
