//
//  AppDelegate.swift
//  Qiu
//
//  Created by Marcos Tirao on 7/26/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit
import CoreData
import CoreLocation
import UserNotifications
//import Fabric
//import Crashlytics
import FBSDKCoreKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate, CLLocationManagerDelegate, UNUserNotificationCenterDelegate {

    var window: UIWindow?
    var locationManager = CLLocationManager()
    
    static var dataController : DataController!
    
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        //Facebook
        FBSDKApplicationDelegate.sharedInstance().application(application, didFinishLaunchingWithOptions: launchOptions)

        //Setting up Crashlytics
        //Fabric.with([Crashlytics.self])
        locationManager.delegate = self
        
        AppDelegate.dataController = DataController()
        
        let request = Request()
        let typesViewModel = TypesViewModel(dataProvider: request)
        
        typesViewModel.types(completion: {(response) -> Void in
            response.save()
            
        }, error: {(error) -> Void in
            print(error?.localizedDescription ?? "Error")
        })
        
        NotificationController.notificationObserver(observer: self, selector: #selector(AppDelegate.endOnboard), name: Notes.endOnboardNotification.notification)
        
        self.window = UIWindow(frame: UIScreen.main.bounds)
        self.window!.backgroundColor = UIColor.white
        
        if CLLocationManager.authorizationStatus() == .authorizedWhenInUse || CLLocationManager.authorizationStatus() == .authorizedAlways {
            DispatchQueue.main.async {
                 self.locationManager.startUpdatingLocation()
            }
        }

        
        if Preferences.onboarded {
            let homeViewController = HomeViewController()
            self.window!.rootViewController = homeViewController
        }else {
            let onboardNavigationController = UINavigationController(rootViewController: Onboard())
            self.window!.rootViewController =  onboardNavigationController
        }
        
        self.window!.makeKeyAndVisible()

        
        UNUserNotificationCenter.current().getNotificationSettings{ (settings) -> Void in
            
            if settings.authorizationStatus == .authorized {
                DispatchQueue.main.async {
                    UIApplication.shared.registerForRemoteNotifications();
                }
            }
        }
        
        
        
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
       
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
       
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        
        Preferences.version = Preferences.version
        FBSDKAppEvents.activateApp()
    }

    func applicationWillTerminate(_ application: UIApplication) {
       
    }
    
    func application(_ application: UIApplication, open url: URL, sourceApplication: String?, annotation: Any) -> Bool {
        let handled = FBSDKApplicationDelegate.sharedInstance().application(application, open: url, sourceApplication: sourceApplication, annotation: annotation)
        return handled;
    }
    
    
    func application(_ app: UIApplication, open url: URL, options: [UIApplicationOpenURLOptionsKey : Any] = [:]) -> Bool {
        let handled = FBSDKApplicationDelegate.sharedInstance().application(app, open: url, options: options)
        return handled;
    }
    
    
    @objc func endOnboard() {
        if !Preferences.onboarded {
            Preferences.onboarded = true
            
            DispatchQueue.main.async {
                let homeViewController = HomeViewController()
                self.window!.rootViewController = homeViewController
            }
        }
    }
 }


//MARK: - Core Location and Push Notification Delegate Methods

extension AppDelegate {
    
    @objc(locationManager:didChangeAuthorizationStatus:) func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        
        if status == .authorizedAlways || status == .authorizedWhenInUse {
            manager.startUpdatingLocation()
            DispatchQueue.main.async {
                self.locationManager.startUpdatingLocation()
            }
            
        }else if CLLocationManager.authorizationStatus() == .denied{
            manager.stopUpdatingLocation()
        }
        
        if status == .notDetermined {
            return
        }
        
        if !Preferences.onboarded {
            if let navigationController = self.window!.rootViewController as? UINavigationController {
                navigationController.pushViewController(OnboardPushNotification(), animated: true)
            }
            DispatchQueue.main.async {
                self.locationManager.startUpdatingLocation()
            }
        }
    }
    
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        let latitude = locations[0].coordinate.latitude
        let longitude = locations[0].coordinate.longitude
        
        Preferences.latitude = latitude
        Preferences.longitude = longitude
        
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error)
    }
    
    
    //Push Notification Delegate method
    
    func application(_ application: UIApplication, didRegister notificationSettings: UNNotificationSettings) {
        application.registerForRemoteNotifications();
        
    }

    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        let deviceTokenString = deviceToken.reduce("", {$0 + String(format: "%02X", $1)})
        
        print("Device Token:", deviceTokenString)
        
        Preferences.deviceToken = deviceTokenString
        
        
        let dataProvider = Request()
        let profileViewModel = ProfileViewModel(dataProvider: dataProvider)
        profileViewModel.deviceId = Preferences.deviceToken
        
        profileViewModel.updateProfile(completion: { (profile) -> Void in
            
            profile.save()
            
        }, error: { (error) -> Void in
            
        })
        
    }
    
    @objc(userNotificationCenter:didReceiveNotificationResponse:withCompletionHandler:)
    public func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        print(response.notification.request.content.userInfo)
    }
    
    @objc(userNotificationCenter:willPresentNotification:withCompletionHandler:)
    public func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        print(notification.request.content.userInfo)
    }
    
}


