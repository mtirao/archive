//
//  OnboardPushNotification.swift
//  Qiu
//
//  Created by Marcos Tirao on 8/16/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit
import UserNotifications

class OnboardPushNotification: Onboard {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        label!.text = "ONBOARD_NOTIFICATION_LINE1".localizable()
        label1!.text = "ONBOARD_NOTIFICATION_LINE2".localizable()
        label2!.text = "ONBOARD_NOTIFICATION_LINE3".localizable()
        button?.setTitle("ENABLE_PUSH_NOTIFICATION".localizable(), for: .normal)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    override func nextAction() {
        button!.backgroundColor = Theme.qiuRed
        
        let center = UNUserNotificationCenter.current()
        center.delegate = UIApplication.shared.delegate as! AppDelegate
        center.requestAuthorization(options:[.badge, .alert, .sound]) { (granted, error) in
            if granted {
                DispatchQueue.main.async {
                    UIApplication.shared.registerForRemoteNotifications();
                }

            }
            NotificationController.postNotification(name: Notes.endOnboardNotification.notification, userInfo: nil)
        }
        
    }

}
