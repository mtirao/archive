//
//  Onboard.swift
//  Qiu
//
//  Created by Marcos Tirao on 8/15/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit
import CoreLocation

class Onboard: UIViewController {
    
    var label: UILabel?
    var label1: UILabel?
    var label2: UILabel?
    
    var button: UIButton?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.isNavigationBarHidden = true

        
        let backgroundImage = UIImageView(image: UIImage(named: "launch-screen-background"))
        self.view.addSubview(backgroundImage)
        backgroundImage.snp.makeConstraints{(make) -> Void in
            make.top.bottom.equalTo(0)
            make.trailing.leading.equalTo(0)
        }
        
        label = UILabel()
        label!.textColor = UIColor.white
        label!.font = UIFont.systemFont(ofSize: 23)
        label!.text = "LINE1_SPORTCENTER_PRESENTATION".localizable()
        self.view.addSubview(label!)
        label!.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(64)
            make.centerX.equalTo(self.view)
        }
        
        label1 = UILabel()
        label1!.textColor = UIColor.white
        label1!.font = UIFont.systemFont(ofSize: 23)
        label1!.text = "LINE2_SPORTCENTER_PRESENTATION".localizable()
        self.view.addSubview(label1!)
        label1!.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(label!.snp.bottom).offset(8)
            make.centerX.equalTo(self.view)
        }
        
        label2 = UILabel()
        label2!.textColor = UIColor.white
        label2!.font = UIFont.systemFont(ofSize: 23)
        label2!.text = "LINE3_SPORTCENTER_PRESENTATION".localizable()
        self.view.addSubview(label2!)
        label2!.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(label1!.snp.bottom).offset(8)
            make.centerX.equalTo(self.view)
        }
        
        label!.alpha = 0.0
        label1!.alpha = 0.0
        label2?.alpha = 0.0
        
        button = UIButton()
        button!.layer.cornerRadius = 25
        button!.addTarget(self, action: #selector(Onboard.touchDown), for: .touchDown)
        button!.addTarget(self, action: #selector(Onboard.nextAction), for: .touchUpInside)
        button?.setTitle("NEXT".localizable(), for: .normal)
        button!.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        button!.titleLabel?.textColor = UIColor.white
        button!.backgroundColor = Theme.qiuRed
        button!.alpha = 0.0
        self.view.addSubview(button!)
        button!.snp.makeConstraints{(make) -> Void in
            make.bottom.equalToSuperview().inset(UIEdgeInsetsMake(0, 0, 24, 0))
            make.trailing.leading.equalToSuperview().inset(UIEdgeInsetsMake(0, 24, 0, 24))
            make.height.equalTo(50)
            
        }

    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        UIView.animate(withDuration: 0.6, animations: {
            self.label?.alpha = 1.0
        }, completion: { (result) -> Void in
            UIView.animate(withDuration: 0.6, animations: {
                self.label1?.alpha = 1.0
            }, completion: { (result) -> Void in
                UIView.animate(withDuration:0.6, animations:{
                    self.label2?.alpha = 1.0
                }, completion:{(result) -> Void in
                    UIView.animate(withDuration: 0.6, animations: {
                        self.button?.alpha = 1.0
                    })
                    
                })
            
            })
        })
        
    }
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    @objc func touchDown() {
        button!.backgroundColor = Theme.qiuRedLight
    }
    
    @objc func nextAction() {
        button!.backgroundColor = Theme.qiuRed
        
        if CLLocationManager.authorizationStatus() == .authorizedWhenInUse || CLLocationManager.authorizationStatus() == .authorizedAlways {
            if let delegate = UIApplication.shared.delegate as? AppDelegate {
                delegate.locationManager.startUpdatingLocation()
            }
            
            self.navigationController?.pushViewController(OnboardPushNotification(), animated: true)
        }else {
            self.navigationController?.pushViewController(OnboardLocation(), animated: true)
        }
    
    }
    
}
