//
//  OnboardLocation.swift
//  Qiu
//
//  Created by Marcos Tirao on 8/15/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit
import CoreLocation

class OnboardLocation: Onboard {

    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        label!.text = "ONBOARD_LOCATION_LINE1".localizable()
        label1!.text = "ONBOARD_LOCATION_LINE2".localizable()
        label2!.text = "ONBOARD_LOCATION_LINE3".localizable()
        button?.setTitle("ENABLE_LOCATION".localizable(), for: .normal)
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func nextAction() {
        button!.backgroundColor = Theme.qiuRed
        
        if CLLocationManager.authorizationStatus() == .notDetermined{
            
            DispatchQueue.main.async {
                if let delegate = UIApplication.shared.delegate as? AppDelegate {
                    delegate.locationManager.requestWhenInUseAuthorization()
                }
            }
            

            
            
        }else {
            self.navigationController?.pushViewController(OnboardPushNotification(), animated: true)
            
            if CLLocationManager.authorizationStatus() == .authorizedWhenInUse || CLLocationManager.authorizationStatus() == .authorizedAlways {
                if let delegate = UIApplication.shared.delegate as? AppDelegate {
                    delegate.locationManager.startUpdatingLocation()
                }
            }

            
        }

    }
}
