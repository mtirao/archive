//
//  Tracking.swift
//  Qiu
//
//  Created by Marcos Tirao on 8/28/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit
//import Crashlytics

enum ViewNames : String {
    case turnView = "Turn View"
    case profileView = "Profile View"
    case notificationView = "Notification View"
    case socialView = "Social View"
    case calendarView = "Calendar View"
    case loginView = "Login View"
    
}

class Tracking: NSObject {
    
    
    
    static func userEnterView(viewName: ViewNames) {
        
        //Answers.logCustomEvent(withName: "User Enter View", customAttributes: ["Name":viewName.rawValue])
    }

    static func userExitView(viewName: ViewNames) {
        
        //Answers.logCustomEvent(withName: "User Exit View", customAttributes: ["Name":viewName.rawValue])
    }
    
}
