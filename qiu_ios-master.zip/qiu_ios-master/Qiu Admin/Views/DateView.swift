//
//  DateView.swift
//  Qiu
//
//  Created by Marcos Tirao on 9/4/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit
import UIFontComplete

class DateView: UIView {

    
    private let plusButton = UIButton(frame: CGRect(x: 0, y: 0, width: 19, height: 19))
    private let dateLabel = UILabel()
    private let label = UILabel()
    private let datePicker = UIDatePicker()
    
    var mode : UIDatePickerMode {
        get {
            return datePicker.datePickerMode
        }
        
        set {
            datePicker.datePickerMode = newValue
        }
    }
    
    private weak var  delegate: DateViewDelegate?
    
    init(frame: CGRect, mode: UIDatePickerMode, text: String, delegate: DateViewDelegate?) {
        
        
        super.init(frame: frame)
        
        self.mode = mode
        self.delegate = delegate
        
        
        
        //OPEN HOURS
        //Button plus-minus sign
        plusButton.setImage(UIImage(named: "plus"), for: .normal)
        plusButton.setImage(UIImage(named: "minus"), for: .selected)
        plusButton.addTarget(self, action: #selector(DateView.openAction), for: .touchUpInside)
        self.addSubview(plusButton)
        plusButton.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(0)
            make.leading.equalTo(Theme.leading)
            make.height.width.equalTo(19)
        }
        
        let label = UILabel()
        self.addSubview(label)
        label.text = text
        label.font = UIFont(name:Font.helveticaNeue.rawValue, size:UIFont.systemFontSize )
        label.textColor = UIColor.gray
        label.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(0)
            make.left.equalTo(plusButton.snp.right).offset(5)
            make.width.equalTo(100)
            make.height.equalTo(20)
        }
        
        dateLabel.font = UIFont(name:Font.helveticaNeue.rawValue, size:UIFont.systemFontSize )
        dateLabel.textAlignment = .right
        dateLabel.textColor = UIColor.gray
        self.addSubview(dateLabel)
        dateLabel.snp.makeConstraints{(make) -> Void in
            make.centerY.equalTo(label.snp.centerY)
            make.trailing.equalTo(Theme.trailing)
            make.width.equalTo(200)
            make.height.equalTo(20)
        }
        
        //Date Picker
        datePicker.date = Date()
        
        
        let currentCalendar = Calendar.current
        let unitFlags = Set<Calendar.Component>([.year, .month, .day, .hour, .minute, .second])
        var comp = currentCalendar.dateComponents(unitFlags, from: datePicker.date)
        
        let min = comp.minute!
        let minutes = min - (min % 30)
        comp.minute = Int(minutes)
        datePicker.date = currentCalendar.date(from: comp)!
        
        
        datePicker.minuteInterval = 30
        self.addSubview(datePicker)
        datePicker.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(dateLabel.snp.bottom).offset(0)
            make.leading.trailing.equalTo(0)
            make.bottom.equalTo(self.snp.bottom)
        }
        datePicker.addTarget(self, action: #selector(DateView.dateSelection(sender:)), for: .valueChanged)
        
        if datePicker.datePickerMode == .time {
            dateLabel.text = Theme.timeShortFormat(date: datePicker.date)
        }else {
            dateLabel.text = Theme.dateShortFormat(date: datePicker.date)
        }
        
        self.layoutIfNeeded()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    @objc func dateSelection(sender: UIDatePicker) {
        if datePicker.datePickerMode == .time {
            dateLabel.text = Theme.timeShortFormat(date: datePicker.date)
        }else {
            dateLabel.text = Theme.dateShortFormat(date: datePicker.date)
        }
    }
    
    @objc func openAction() {
        
        if(plusButton.isSelected) {
            plusButton.isSelected = false
            
            self.datePicker.alpha = 0.0
            UIView.animate(withDuration: 0.3, animations: {() -> Void in
                //self.datePicker.snp.updateConstraints { (make) -> Void in
                //    make.height.equalTo(0)
                //}
                self.snp.updateConstraints{(make) -> Void in
                    make.height.equalTo(40)
                }
                
                self.layoutIfNeeded()
                
            }, completion: {(result) -> Void in
                self.delegate?.didSelectOpen(open: false)
            })
        }else {
            plusButton.isSelected = true
            self.datePicker.alpha = 1.0
            UIView.animate(withDuration: 0.4, animations: {() -> Void in
                self.snp.updateConstraints{(make) -> Void in
                    make.height.equalTo(170)
                }
                self.layoutIfNeeded()
            },  completion: {(result) -> Void in
                self.delegate?.didSelectOpen(open: true)
            })

        }
        
    }

}
