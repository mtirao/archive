//
//  FieldViewController.swift
//  Easy Planner
//
//  Created by Marcos Tirao on 9/9/16.
//  Copyright © 2016 Marcos Tirao. All rights reserved.
//

import UIKit
import SnapKit

enum DataType {
    case currency
    case text
    case number
    case password
    case email
    case multiText
};

class FieldView: UIView, UITextFieldDelegate {
    
    private let editText : UITextField
    private let staticText: UILabel
    private let infoText: UILabel
    private let multiText: UITextView
    
    private let fieldType : DataType
    private let currencyFormat = NumberFormatter()
    
    private var oldText : String = ""
    
    var info : String {
        set  {
            infoText.text = newValue
        }
        
        get {
            return infoText.text ?? ""
        }
    }
    
    var data : String? {
        set(newValue) {
            
            var value = ""
            if newValue != self.placeholder {
                value = newValue ?? ""
            }
            
            switch fieldType {
            case .currency:
                self.editText.text = convertToCurrency(text: value)
                break;
            case .text:
                editText.text = value as String?
                break;
            case .number:
                self.editText.text = convertToNumber(text: value)?.stringValue ?? ""
                break;
            case .password:
                editText.text = value
                break;
            case .email:
                editText.text = value
                break;
            case .multiText:
                multiText.text = value
                break;
            }
           
        }
        
        get {
            var text = ""
            switch fieldType {
            case .currency:
                text = convertFromCurrency(text: editText.text!)
                break;
            case .text:
                text = editText.text!
                break;
            case .number:
                text = convertToNumber(text: editText.text!)?.stringValue ?? ""
                break;
            case .password:
                text = editText.text!
                break;
            case .email:
                text = editText.text!
                break;
            case .multiText:
                text = multiText.text!
                break;
                
            }
            
            if(text == self.placeholder) {
                text = ""
            }
            
            return text
        }
    }
    
    var dataAsNumber : NSNumber {
        get {
            
            var number = NSNumber(value: 0)
            switch fieldType {
            case .currency:
                number = convertToNumber(text: convertFromCurrency(text: editText.text!)) ?? number
                break;
            case .text:
                break;
            case .number:
                number = convertToNumber(text: editText.text!) ?? number
                break;
            case .password:
                break;
            case .email:
                break;
            case .multiText:
                break;
            }
            
            return number
            
        }
    }
    
    var deleteWhenStartEditting = false
    
    var placeholder : String? {
        set {
            self.editText.placeholder = newValue
        }
        
        get {
            return self.editText.placeholder
        }
    }
    
    var labelFont : UIFont? {
        set {
            self.staticText.font = newValue ?? UIFont.systemFont(ofSize: UIFont.systemFontSize)
        }
        
        get {
            return self.staticText.font
        }

    }
    
    var enabled : Bool {
        set {
            self.editText.isEnabled = newValue
        }
        
        get {
            return self.editText.isEnabled
        }
    }
    
    weak var delegate: FieldViewDelegate?
    
    init(frame: CGRect, type: DataType, label: String) {
        
        self.fieldType = type
        
        
        editText = UITextField()
        staticText = UILabel();
        infoText = UILabel();
        multiText = UITextView();
        
        self.editText.font = UIFont.systemFont(ofSize: 14)
        self.staticText.font = UIFont.boldSystemFont(ofSize: 17)
        self.staticText.font = UIFont.boldSystemFont(ofSize: 17)
        self.multiText.font = UIFont.systemFont(ofSize: 12)
        self.infoText.textColor = UIColor.red
        self.infoText.font = UIFont.systemFont(ofSize: 10)
        
        
        super.init(frame: frame)
        
        
        let toolBar = UIToolbar()
        toolBar.sizeToFit()
        let flexiableSpace = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        let doneButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.done, target: self, action: #selector(self.doneAction))
        toolBar.setItems([flexiableSpace, doneButton], animated: false)
        
        
        staticText.text = label
        
        if self.fieldType == .currency || self.fieldType == .number {
            self.editText.keyboardType = .decimalPad
            self.editText.inputAccessoryView = toolBar
        }else if self.fieldType == .email {
            self.editText.keyboardType = .emailAddress
            self.editText.autocapitalizationType = .none
        }
        
        
        if self.fieldType == .password {
            self.editText.isSecureTextEntry = true
        }
        
        self.addSubview(staticText)
        staticText.snp.makeConstraints { (make) -> Void in
            make.height.equalTo(21)
            make.trailing.equalTo(self)
            make.leading.equalTo(self)
            make.top.equalTo(0)
        }
        
        var referenceView : UIView = editText
        if fieldType == .multiText {
            multiText.inputAccessoryView = toolBar
            self.addSubview(multiText)
            multiText.layer.borderWidth = 0.5
            referenceView = multiText
            multiText.snp.makeConstraints{(make) -> Void in
                make.bottom.equalTo(self.snp.bottom).offset(-17)
                make.leading.equalTo(staticText)
                make.trailing.equalTo(0)
                make.top.equalTo(staticText.snp.bottom)
            }
            
        }else {
            self.addSubview(editText)
            editText.snp.makeConstraints{(make) -> Void in
                make.height.equalTo(17)
                make.leading.equalTo(staticText)
                make.trailing.equalTo(0)
                make.top.equalTo(staticText.snp.bottom)
            }
        }
        
        let line = UIView()
        if fieldType != .multiText  {
            line.backgroundColor = UIColor.lightGray
            self.addSubview(line)
            line.snp.makeConstraints{(make) -> Void in
                make.height.equalTo(1)
                make.leading.equalTo(referenceView)
                make.trailing.equalTo(0)
                make.top.equalTo(referenceView.snp.bottom).offset(4)
            }
        }
        
        self.addSubview(infoText)
        infoText.snp.makeConstraints { (make) -> Void in
            make.height.equalTo(15)
            make.leading.equalTo(referenceView)
            make.trailing.equalTo(0)
            
            if fieldType != .multiText  {
                make.top.equalTo(referenceView.snp.bottom).offset(4)
            }
        }

        
        self.editText.delegate = self
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        
        self.fieldType = .text
        
        editText = UITextField()
        staticText = UILabel();
        infoText = UILabel();
        multiText = UITextView();
        
        super.init(coder: aDecoder)
    }
    
    func convertToNumber(text: String) -> NSNumber? {
        let format = NumberFormatter()
        format.numberStyle = .decimal
        if text.count > 0 {
            return format.number(from:text) ?? NSNumber(value: 0)
        }else {
            return nil
        }
    }
    
    func convertToCurrency(text: String) -> String {
        
        let format = NumberFormatter()
        format.numberStyle = .currency
        
        if format.number(from: editText.text!) == nil {
            let number = convertToNumber(text: text)
            if let num = number  {
                return format.string(from: num) ?? "0.00"
            }else {
                return "0.00"
            }
        }
        
        return text
    }
    
    func convertFromCurrency(text: String) -> String {
        
        let format = NumberFormatter()
        format.numberStyle = .currency
        return format.number(from: text)?.stringValue ?? ""
        
    }
    
    @objc func doneAction() {
        
        if self.fieldType == .multiText {
            self.multiText.endEditing(true)
        }else {
            self.editText.endEditing(true)
        }
        
    }
    
    override func resignFirstResponder() -> Bool {
        var result = super.resignFirstResponder()
        
        result = result && self.editText.resignFirstResponder()
        
        return result
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        self.infoText.text = ""
        return true
    }
       
    @objc(textFieldShouldReturn:) func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        
        let subviews = self.superview?.subviews
        let index = (self.superview?.subviews.index(of: self) ?? 0) + 1

        let count = subviews?.count ?? 0
        
        for i in index..<count {
            if let field = subviews?[i] as? FieldView , field.enabled {
                field.editText.becomeFirstResponder()
                self.delegate?.didSelectFirstResponder(frame: field.frame)
                return false
            }
        }
        
        return false
    }

    
    @objc(textFieldDidEndEditing:) func textFieldDidEndEditing(_ textField: UITextField) {
        let format = NumberFormatter()
        format.numberStyle = .currency
        
        switch fieldType {
        case .currency:
            self.editText.text = convertToCurrency(text: textField.text!)
            break;
        case .text:
            break;
        case .number:
            self.editText.text = convertToNumber(text: textField.text!)?.stringValue ?? ""
            break;
        case .password:
            break;
        case .email:
            break;
        case .multiText:
            break;
        }
        
        let newText = self.editText.text ?? ""
        
        if oldText != newText {
            oldText = newText
            self.delegate?.textDidChange(fieldView:self, text: newText)
        }
    }
    
    @objc(textFieldDidBeginEditing:) func textFieldDidBeginEditing(_ textField: UITextField) {
        
        self.oldText = textField.text ?? ""
        
        self.infoText.text = ""
        if self.deleteWhenStartEditting {
            self.editText.text = ""
        }
    }

}

