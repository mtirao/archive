//
//  VerifierView.swift
//  Qiu
//
//  Created by Marcos Tirao on 8/31/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class VerifierView: UIView {

    private let button : UIButton
    private let imageVerifier: UIImageView

    weak var delegate: VerifierDelegate?
    
    var hide : Bool {
        set {
            button.isEnabled = false
        }
        
        get {
            return button.isEnabled
        }
    }
    
    init(frame: CGRect, buttonText: String, buttonTextDisabled: String,  image: UIImage, delegate: VerifierDelegate?) {
        
        
        button = UIButton()
        button.setTitle(buttonText, for: .normal)
        button.setTitle(buttonText, for: .selected)
        button.setTitle(buttonTextDisabled, for: .disabled)
        button.setTitleColor(Theme.qiuGreen, for: .normal)
        
        
        imageVerifier = UIImageView(image: image)
        
        self.delegate = delegate
        
        super.init(frame: frame)
        
        button.addTarget(self, action: #selector(VerifierView.buttonAction), for: .touchUpInside)

        
        self.addSubview(imageVerifier)
        imageVerifier.snp.makeConstraints { (make) -> Void in
            make.height.width.equalTo(32)
            make.leading.equalTo(0)
            make.top.equalTo(0)
        }
        
        self.addSubview(button)
        button.snp.makeConstraints { (make) -> Void in
            make.trailing.equalTo(Theme.trailing)
            make.height.equalTo(21)
            make.centerY.equalTo(imageVerifier.snp.centerY)
        }
        
        let line = UIView()
        line.backgroundColor = UIColor.lightGray
        self.addSubview(line)
        line.snp.makeConstraints{(make) -> Void in
            make.height.equalTo(1)
            make.leading.equalTo(imageVerifier)
            make.trailing.equalTo(0)
            make.top.equalTo(imageVerifier.snp.bottom).offset(4)
        }
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        button = UIButton()
        imageVerifier = UIImageView()
        
        super.init(coder: aDecoder)
    }
    
    @objc func buttonAction() {
        delegate?.didSelectVerified()
    }
    

}
