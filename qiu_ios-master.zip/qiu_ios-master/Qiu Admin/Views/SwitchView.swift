//
//  SwitchView.swift
//  Qiu
//
//  Created by Marcos Tirao on 9/5/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class SwitchView: UIView {
    
    private let staticText: UILabel = UILabel()
    private let optionSwitch: UISwitch = UISwitch()
    
    var state: Bool {
        get {
            return optionSwitch.isOn
        }
        
        set {
            optionSwitch.isOn = newValue
        }
    }
    
    var labelFont : UIFont? {
        set {
            self.staticText.font = newValue ?? UIFont.systemFont(ofSize: UIFont.systemFontSize)
        }
        
        get {
            return self.staticText.font
        }
        
    }
    
    var enabled : Bool {
        set {
            self.optionSwitch.isEnabled = newValue
            self.optionSwitch.isUserInteractionEnabled = newValue
        }
        
        get {
            return self.optionSwitch.isEnabled 
        }
    }

    
    init(frame: CGRect, label: String) {
        
        super.init(frame: frame)
        
        self.addSubview(staticText)
        staticText.text = label
        staticText.snp.makeConstraints { (make) -> Void in
            make.height.equalTo(21)
            make.trailing.equalTo(self)
            make.leading.equalTo(self)
            make.top.equalTo(0)
        }
        
        self.addSubview(optionSwitch)
        optionSwitch.snp.makeConstraints { (make) -> Void in
            make.trailing.equalTo(Theme.trailing)
            make.centerY.equalTo(staticText.snp.centerY)
        }
        
        let line = UIView()
        line.backgroundColor = UIColor.lightGray
        self.addSubview(line)
        line.snp.makeConstraints{(make) -> Void in
            make.height.equalTo(1)
            make.leading.equalTo(staticText)
            make.trailing.equalTo(0)
            make.top.equalTo(staticText.snp.bottom).offset(10)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
}
