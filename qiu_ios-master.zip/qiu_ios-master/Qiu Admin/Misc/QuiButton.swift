//
//  QuiButton.swift
//  Qiu
//
//  Created by Marcos Tirao on 8/23/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class QuiButton: UIButton {

    var originalButtonText: String?
    var originalButtonImage : UIImage?
    var activityIndicator: UIActivityIndicatorView!
    
    var changeState : Bool {
        set {
            if newValue {
                self.backgroundColor = Theme.qiuRed
                self.isEnabled = true
            }else {
                self.backgroundColor = Theme.lightGray
                self.isEnabled = false
            }
        }
        get {
            return self.isEnabled
        }
    }
    
    func showLoading() {
        originalButtonText = self.titleLabel?.text
        originalButtonImage = self.image(for: .normal)
        
        self.setTitle("", for: .normal)
        self.setImage(nil, for: .normal)
        
        if (activityIndicator == nil) {
            activityIndicator = createActivityIndicator()
        }
        
        showSpinning()
    }
    
    func hideLoading() {
        DispatchQueue.main.async {[unowned self] in
            let animating = self.activityIndicator?.isAnimating ?? false
            if(animating) {
                self.setTitle(self.originalButtonText, for: .normal)
                self.setImage(self.originalButtonImage, for: .normal)
                self.activityIndicator?.stopAnimating()
            }
        }
    }
    
    private func createActivityIndicator() -> UIActivityIndicatorView {
        let activityIndicator = UIActivityIndicatorView()
        activityIndicator.hidesWhenStopped = true
        activityIndicator.color = UIColor.white
        return activityIndicator
    }
    
    private func showSpinning() {
        DispatchQueue.main.async {[unowned self] in
            self.activityIndicator.translatesAutoresizingMaskIntoConstraints = false
            self.addSubview(self.activityIndicator)
            self.centerActivityIndicatorInButton()
            self.activityIndicator.startAnimating()
        }
    }
    
    private func centerActivityIndicatorInButton() {
        let xCenterConstraint = NSLayoutConstraint(item: self, attribute: .centerX, relatedBy: .equal, toItem: activityIndicator, attribute: .centerX, multiplier: 1, constant: 0)
        self.addConstraint(xCenterConstraint)
        
        let yCenterConstraint = NSLayoutConstraint(item: self, attribute: .centerY, relatedBy: .equal, toItem: activityIndicator, attribute: .centerY, multiplier: 1, constant: 0)
        self.addConstraint(yCenterConstraint)
    }


}
