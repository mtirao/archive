//
//  Preferences.swift
//  Easy Planner
//
//  Created by Marcos Tirao on 9/9/16.
//  Copyright © 2016 Marcos Tirao. All rights reserved.
//

import UIKit

private let longitudeKey = "longitude"
private let latitudeKey = "latitude"
private let deviceTokenKey = "deviceToken"
private let pushNotificationKey = "pushNotification"
private let versionKey = "versionKey"
private let onboardedKey = "onboarded"
private let isLoggedKey = "islogged"
private let serverIpKey =  "server_ip"

class Preferences {
    
    
    static var longitude : Double? {
        
        set {
            if ((newValue) != nil) {
                UserDefaults.standard.set(newValue, forKey: longitudeKey)
            }
        }
        
        get {
            return UserDefaults.standard.double(forKey: longitudeKey)
        }
    }
    
    static var latitude : Double? {
        
        set {
            if (newValue != nil) {
                UserDefaults.standard.set(newValue, forKey: latitudeKey)
            }
        }
        
        get {
            return UserDefaults.standard.double(forKey: latitudeKey)
        }
    }
    
    static var deviceToken: String {
        
        set {
            
            UserDefaults.standard.set(newValue, forKey: deviceTokenKey)
        }
        
        get {
            return UserDefaults.standard.string(forKey: deviceTokenKey) ?? ""
        }
    }
    
    

    static var pushNotification: Bool {
        
        set {
            UserDefaults.standard.set(newValue, forKey: pushNotificationKey)
        }
        
        get {
            return UserDefaults.standard.bool(forKey: pushNotificationKey)
        }
    }
    
    static var version: String {
        set {
            UserDefaults.standard.set(newValue, forKey: versionKey)
        }
        
        get {
            
            if let path = Bundle.main.path(forResource: "Info", ofType: "plist") {
                let resourceFileDictionary = NSDictionary(contentsOfFile: path)
                let version = resourceFileDictionary?.object(forKey: "CFBundleVersion") as! String
                return "2.0 \(version)"
            }
            return "2.0 (35)"
        }

    }
    
    static var onboarded: Bool {
        
        set {
            UserDefaults.standard.set(newValue, forKey: onboardedKey)
        }
        
        get {
            return UserDefaults.standard.bool(forKey: onboardedKey)
        }
        
    }
    
    static var isLogged: Bool {
        
        set {
            UserDefaults.standard.set(newValue, forKey: isLoggedKey)
        }
        
        get {
            return UserDefaults.standard.bool(forKey: isLoggedKey)
        }

    }
    
    static var serverIp: String {
        
        set {
            UserDefaults.standard.set(newValue, forKey: serverIpKey)
        }
        
        get {
            return UserDefaults.standard.string(forKey: serverIpKey) ?? ""
        }

        
    }
    
}
