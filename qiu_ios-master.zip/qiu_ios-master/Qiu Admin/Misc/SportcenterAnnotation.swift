//
//  SportcenterAnnotation.swift
//  Qiu
//
//  Created by Marcos Tirao on 20/10/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit
import MapKit

class SportcenterAnnotation: MKPointAnnotation {
    
    var sportcenter : String = ""
    var status : String = ""
    
}
