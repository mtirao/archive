//
//  Theme.swift
//  Qiu
//
//  Created by Marcos Tirao on 7/26/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class Theme {
    
    //Color Scheme
    static var navigationBackgroundColor : UIColor {
        let color = UIColor(red: 0.035, green: 0.625, blue: 0.527, alpha: 1)
        return color
    }
    
    static var qiuRedLight : UIColor {
        let color = UIColor(red: 1, green: 0.539, blue: 0.402, alpha: 1)
        return color
    }
    
    static var qiuRed : UIColor {
        let color = UIColor(red: 0.976, green: 0.458, blue: 0.352, alpha: 1)
        return color
    }
    
    static var qiuGreen : UIColor {
        let color = UIColor(red: 0.035, green: 0.625, blue: 0.527, alpha: 1)
        return color
    }
    
    static var qiuGreenLight : UIColor {
        let color = UIColor(red: 0.035, green: 0.625, blue: 0.527, alpha: 1)
        return color
    }
    
    static var qiuYellow : UIColor {
        let color = UIColor(red: 1, green: 0.741, blue: 0, alpha: 1)
        return color
    }
    
    static var barTint : UIColor {
        let color = UIColor(red: 1, green: 0.539, blue: 0.402, alpha: 1)
        return color
    }
    
    static var dayColor : UIColor {
        let color = UIColor(red: 0.035, green: 0.625, blue: 0.527, alpha: 1)
        return color
    }
    
    static var lightGray : UIColor {
        let color = UIColor(red: 0.950, green: 0.950, blue: 0.950, alpha: 1)
        return color
    }
    
    static var lightLightGray : UIColor {
        let color = UIColor(red: 0.960, green: 0.960, blue: 0.960, alpha: 1)
        return color
    }
    
    static var facebookColor : UIColor {
        let color = UIColor(red: 0.23, green: 0.347, blue: 0.593, alpha: 1)
        return color
    }
    
    //Margin
    static var topMargin = 10
    static var leading = 10
    static var trailing = -10
    static var top = 64
    static var topBigMargin = 25
    
    static func dateShortFormat(date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        
        return formatter.string(from: date)
        
    }
    
    static func dateShortFormat(string: String) -> Date {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        
        return formatter.date(from: string) ?? Date()
    }
    
    static func timeShortFormat(date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        
        return formatter.string(from: date)
    }
    
    static func turnTimeShortFormat(date: Date) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd/YYYY - HH:mm"
        
        return dateFormatter.string(from: date)
    }
    
    static func turnDateToInt(date: Date) -> Int64{
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "YYYYMMdd"
        
        let strDate = dateFormatter.string(from: date)
        
        return Int64(strDate) ?? 0
    }
    
    static func turnTimeShorFormat(date: Date, time: Date) -> String {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "HH:mm"
        
        let time = dateFormatter.string(from: time)
        dateFormatter.dateFormat = "MM/dd/YYYY"
        
        let date = dateFormatter.string(from: date)
        
        return "\(date) - \(time)"
        
    }
    
    static func isoDateToDate(isoDate: String) -> Date? {
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
        return dateFormatter.date(from: isoDate)
    }
    
    static func DateToIsoDate(isoDate: Date) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
        return dateFormatter.string(from:isoDate)
    }
    
    
}
