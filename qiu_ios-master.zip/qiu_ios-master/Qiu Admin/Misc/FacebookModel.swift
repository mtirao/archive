//
//  Facebook.swift
//  Qiu
//
//  Created by Marcos Tirao on 8/29/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import FBSDKCoreKit
import FBSDKLoginKit

class FacebookModel {
    
    static var email : String = ""
    static var name : String = ""
    
    static func data(completionHandler: @escaping (String, String) -> Void ) {
        
        let tokenString = FBSDKAccessToken.current().tokenString
        
        
        var emailAux = ""
        var nameAux = ""
        
        let req = FBSDKGraphRequest(graphPath: "me", parameters: ["fields":"email,name"], tokenString: tokenString, version: nil, httpMethod: "GET")
        _ = req?.start(completionHandler: { (result, arg1, arg2)   -> Void in
            if let facebookData = arg1 as? [String : Any] {
                emailAux = facebookData["email"] as! String
                nameAux = facebookData["name"] as! String
            }
            
            self.email = emailAux
            self.name = nameAux
            
            completionHandler(emailAux, nameAux)
            
        })
        
    }
    
    
}
