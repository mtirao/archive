//
//  TurnTableModel.swift
//  Qiu
//
//  Created by Marcos Tirao on 9/15/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class TurnTableModel: NSObject, UITableViewDataSource {

    static let cellIdentifier = "cellIdentifier"
    
    var startHour : Int = 8
    var sportCenter = SportCenterModel()
    var turns = TurnModel()
    
    var selectedGround : String = ""
    var selectedDate : Date?
    
    weak var turnTableDelegate : TurnCellDelegate?
    
    func loadData() {
        guard let date = selectedDate else {
            return
        }
        
        turns.load(for: date, ground: selectedGround, sportcenter: sportCenter.id)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: TurnTableModel.cellIdentifier, for: indexPath as IndexPath)
        
        if let turnCell = cell as? TurnTableCell {
            let hours = self.startHour + indexPath.row
            if selectedDate != nil {
                var firstName = ""
                if let first = self.turns.fetch(for: Float(hours)) {
                    firstName = first.name ?? ""
                    turnCell.upperText.text = firstName
                    turnCell.upperText.textColor = UIColor.white
                    turnCell.upperText.backgroundColor = (first.status != "new") ? Theme.qiuGreen : Theme.qiuYellow
                }else {
                    turnCell.upperText.text = ""
                    turnCell.upperText.textColor = UIColor.white
                    turnCell.upperText.backgroundColor = UIColor.white
                }
                
                if let second = self.turns.fetch(for: Float(hours) + 0.5) {
                    if firstName != second.name {
                        turnCell.lowerText.text = second.name
                    }
                    turnCell.lowerText.textColor = UIColor.white
                    turnCell.lowerText.backgroundColor = turnCell.upperText.backgroundColor
                }else {
                    turnCell.lowerText.text = ""
                    turnCell.lowerText.textColor = UIColor.white
                    turnCell.lowerText.backgroundColor = UIColor.white
                }
                
            }else {
                turnCell.upperText.text = ""
                turnCell.lowerText.text = ""
                turnCell.lowerText.backgroundColor = UIColor.white
                turnCell.upperText.backgroundColor = UIColor.white
            }
            turnCell.time.text = "\(hours):00"
            turnCell.selectionStyle = .none
            
            turnCell.delegate = self.turnTableDelegate
        }
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        self.sportCenter.reloadData()
        
        self.startHour = Int(self.sportCenter.openAt)
        let closeAt = self.sportCenter.closeAt
        
        let result = Int(closeAt) - self.startHour + 1
        
        return result
    }
    
    func fetch(at hour: String) -> Turn? {
        
        /*let h = hour.components(separatedBy: ":")
        
        if h.count > 1 && h[1] == "30"{
            let (_, second, _) = turns.fetch(for: "\(h[0]):00")
            return second
        }else if h.count > 1 {
            let (first, _, _) = turns.fetch(for: "\(h[0]):00")
            return first
        }*/
        
        return nil
    }

}
