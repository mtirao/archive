//
//  CalendarTurnModel.swift
//  Qiu
//
//  Created by Marcos Tirao on 10/10/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class CalendarTurnModel: NSObject, UITableViewDataSource {

    static let calendarTableCell = "CalendarTableCell"
    
    var turnModel = TurnModel()
    var sportCenter = SportCenterModel()
    
    let loginModel = LoginModel()
    
    var turns : [Turn]?
    
    func loadTurn(for date: Date) {
        
        loginModel.load()
        turns = turnModel.fetch(at: date)
        
        DispatchQueue.main.async {
            self.sportCenter.reloadData()
        }
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return turns?.count ?? 0
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: CalendarTurnModel.calendarTableCell) as! CalendarCell
        
        let turn = self.turns![indexPath.row]
        
        let time = ""//Theme.turnTimeShorFormat(date: turn.date! as Date, time: turn.date! as Date)
        
        cell.descriptionTurn.text = "\(time) \(turn.name!)"
        
        if turn.status != TurnResponse.TurnStatus.confirmed.rawValue  {
            cell.pofileImage?.image = UIImage(named:"profile-selected")
        }else {
            cell.pofileImage?.image = UIImage(named:"profile")
        }
        
        
        if isOwnTurn(at: indexPath) {
            cell.turnMark.backgroundColor = Theme.qiuGreen
        }else{
            cell.turnMark.backgroundColor = Theme.qiuRed
        }
        
        return cell
    }
    
    func isOwnTurn(at indexPath: IndexPath) -> Bool {
        
        if let turn = self.turns?[indexPath.row] {
            return loginModel.token == turn.token
        }
        
        return false
    }
    
    func isTurnToOwnSportcenter(at indexPath: IndexPath) -> Bool {
        if let turn = self.turns?[indexPath.row] {
            return turn.sportcenter == sportCenter.id
        }
        
        return false
    }
    
    func turn(at indexPath: IndexPath) -> Turn {
        
        return self.turns![indexPath.row]
        
    }
    
}



