//
//  Alert.swift
//  Qiu
//
//  Created by Marcos Tirao on 8/21/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class Alert {
    
    let viewController : UIViewController
    
    init(presenting: UIViewController) {
        self.viewController = presenting
    }
    
    func showAlert(title:String, message: String) {
            
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
            
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            
        alert.addAction(okAction)
        
        DispatchQueue.main.async {
            self.viewController.present(alert, animated: true, completion: nil)
        }
    }
    
    func showAlert(title:String, message: String, handler: ((UIAlertAction) -> Void)? ) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default, handler: handler)
        
        alert.addAction(okAction)
        
        DispatchQueue.main.async {
            self.viewController.present(alert, animated: true, completion: nil)
        }

    }
    
    func showError(error: ErrorResponse?, completion: @escaping (UIAlertAction) -> Void ) {
        
        var title = "AUTHORIZE_ERROR".localizable()
        var message = "AUTHORIZE_ERROR_MESSAGE".localizable()
        
        if error == .networkError {
            title = "NETWORK_ERROR".localizable()
            message = "NETWORK_ERROR_MESSAGE".localizable()
        }
        
        self.showAlert(title: title, message: message, handler: { (action) -> Void in
            
            completion(action)
            
        })
    }
    
    func showActionSheet(title: String, message: String, actions: [UIAlertAction]) {
        
        let alert = UIAlertController(title: title, message: message, preferredStyle: .actionSheet)
        
        for action in actions {
            alert.addAction(action)
        }
        
        let cancelAction = UIAlertAction(title: "CANCEL".localizable(), style: .cancel, handler: nil)
        alert.addAction(cancelAction)
        
        DispatchQueue.main.async {
            self.viewController.present(alert, animated: true, completion: nil)
        }
    }
}
