//
//  CourtCollectionModel.swift
//  Qiu
//
//  Created by Marcos Tirao on 9/14/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit
import CoreData

class CourtCollectionModel: NSObject, UICollectionViewDataSource {
    
    static let cellIdentifier = "courtCell"
    
    var ground : GroundModel?
    var selectedType : [Bool]?

    let label = UILabel()
    
    func loadData() {
        if ground == nil {
            ground = GroundModel()
        }
        
        ground?.reloadData()
        
        selectedType = Array(repeating: false, count: ground?.count ?? 0)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        let count = ground?.count ?? 0
        
        if(count == 0) {
            label.text = "No courts yet!"
            collectionView.backgroundView = label
        }else {
            collectionView.backgroundView = nil
        }
        
        return count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CourtCollectionModel.cellIdentifier, for: indexPath as IndexPath)
        
        if let courtCell = cell as? CourtCollectionCell, let court = ground {
            
            let court = court.ground(at: indexPath)
            courtCell.textLabel.text = court.name ?? "?? \(indexPath.row) ??"
            courtCell.layer.cornerRadius = 5
            
        }
        
        return cell
    }
    
    func select(itemAt indexPath: IndexPath, collectionView: UICollectionView) -> String {
        
        guard let court = ground else {
            return ""
        }
        
        if let groundCell = collectionView.cellForItem(at: indexPath) as? CourtCollectionCell {
            groundCell.setSelect(state: true)
        }
        
        selectedType![indexPath.row] = true
        
        let type = court.ground(at: indexPath)
        
        return type.id ?? ""
    }
    
    func deselect(itemAt indexPath: IndexPath, collectionView: UICollectionView) {
        
        if let courtCell = collectionView.cellForItem(at: indexPath) as? CourtCollectionCell {
            courtCell.setSelect(state: false)
        }
        
        selectedType![indexPath.row] = false
        
    }
   
    func select(itemWithId: String, collectionView: UICollectionView) {
        
        guard let court = ground else {
            return
        }
        
        for i in 0 ..< court.count {
            let indexPath = IndexPath(row: i, section:0)
            let g = court.ground(at: indexPath)
            
            if itemWithId == g.id {
                _ = self.select(itemAt: IndexPath(row: i, section: 0), collectionView: collectionView)
            }
        }
        
    }
}
