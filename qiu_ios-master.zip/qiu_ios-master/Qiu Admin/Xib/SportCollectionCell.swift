//
//  SportCollectionCell.swift
//  Qiu
//
//  Created by Marcos Tirao on 8/16/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class SportCollectionCell: UICollectionViewCell {

    
    @IBOutlet weak var sportImage: UIImageView!
    @IBOutlet weak var sportName: UILabel!
    @IBOutlet weak var check : UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.sportImage.tintColor = UIColor.white
        self.sportName.textColor = UIColor.white

    }
    
    func setSelect(state: Bool) {
        
        if state {
            self.check.image = UIImage(named: "check")
        }else {
            self.check.image = UIImage()
        }
        
    }
}
