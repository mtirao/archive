//
//  CourtCollectionCell.swift
//  Qiu
//
//  Created by Marcos Tirao on 9/14/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class CourtCollectionCell: UICollectionViewCell {
    
    @IBOutlet weak var textLabel: UILabel!
    @IBOutlet weak var statusMark : UIView!
    @IBOutlet weak var check : UIImageView!
    
    private var selectionState : Bool = false
    
    override func awakeFromNib() {
        super.awakeFromNib()
        statusMark.backgroundColor = UIColor.white
    }

    func setSelect(state: Bool) {
        
        if state {
            self.check.image = UIImage(named: "check")
        }else {
            self.check.image = UIImage()
        }
        
    }

}
