//
//  DatePickerCollectionCell.swift
//  Qiu
//
//  Created by Marcos Tirao on 9/15/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class DatePickerCollectionCell: UICollectionViewCell {
    
    @IBOutlet weak var dayName: UILabel!
    @IBOutlet weak var day: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func setSelect(state: Bool) {
        
        if state {
            self.dayName.textColor = UIColor.white
            self.day.textColor = UIColor.white
            self.backgroundColor = Theme.qiuGreen
        }else {
            self.dayName.textColor = UIColor.black
            self.day.textColor = UIColor.black
            self.backgroundColor = UIColor.white
        }
    }

}
