//
//  CalendarCellTableViewCell.swift
//  Qiu
//
//  Created by Marcos Tirao on 8/25/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class CalendarCell: UITableViewCell {

    @IBOutlet weak var descriptionTurn : UILabel!
    @IBOutlet weak var pofileImage: UIImageView?
    @IBOutlet weak var turnMark: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
