//
//  TimePickerCollectionCell.swift
//  Qiu
//
//  Created by Marcos Tirao on 9/12/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class TimePickerCollectionCell: UICollectionViewCell {
    
    @IBOutlet weak var time: UILabel!
    
    private var selectionState : Bool = false
    
    var selectedState : Bool {
        
        set {
            self.selectionState = newValue
            if newValue {
                self.backgroundColor = Theme.qiuGreen
                self.time.textColor = UIColor.white
            }else {
                self.backgroundColor = UIColor.white
                self.time.textColor = Theme.qiuGreen
            }
        }
        
        get {
            return self.selectionState
        }
        
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectedState = false
    }

}
