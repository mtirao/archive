//
//  TurnTableCell.swift
//  Qiu
//
//  Created by Marcos Tirao on 9/15/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class TurnTableCell: UITableViewCell {

    
    @IBOutlet weak var time: UILabel!
    @IBOutlet weak var upperBackground: UIView!
    @IBOutlet weak var lowerBackground: UIView!
    
    @IBOutlet weak var upperText: UILabel!
    @IBOutlet weak var lowerText: UILabel!
    
    weak var delegate :TurnCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        let lowerGesture = UITapGestureRecognizer(target: self, action: #selector(lowerText(_:)))
        lowerText.addGestureRecognizer(lowerGesture)
        
        let upperGesture = UITapGestureRecognizer(target: self, action: #selector(upperText(_:)))
        upperText.addGestureRecognizer(upperGesture)
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    @objc func upperText(_ sender: Any) {
        self.delegate?.didSelectFirstHalf(at: time.text ?? "")
    }
    
    
    @objc func lowerText(_ sender: Any) {
        
        let timeArr = (time.text ?? "").components(separatedBy: ":")
        
        if(timeArr.count > 0) {
            self.delegate?.didSelectSecondHalf(at: "\(timeArr[0]):30")
        }
    }
}
