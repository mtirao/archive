//
//  TimePickerDataSource.swift
//  Qiu
//
//  Created by Marcos Tirao on 9/13/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit


class TimePickerDataSource: NSObject, UICollectionViewDataSource {
    
    static let cellIdentifier = "timeCell"
    
    var firstSelection : Int = -1
    var secondSelection : Int = -1
    
    var startHour : Double = 8
    var endHour : Double = 23
    
    var selectionCount : Int {
        get {
            if firstSelection >= secondSelection {
                return firstSelection - secondSelection
            }else {
                return secondSelection - firstSelection
            }
        }
    }
    
    var selectionRange : (Int, Int) {
        get {
            if currentSelection == 0 {
                if firstSelection >= secondSelection {
                    return (secondSelection, firstSelection)
                }else {
                    return (firstSelection, secondSelection)
                }
            }else {
                return (firstSelection, firstSelection)
            }
        }
    }
    
    override init() {
        
    }
    
    private var currentSelection : Int = 0
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        let result = Int(self.endHour) - Int(ceil(self.startHour)) + 1
        
        return result * 2 + 1
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: TimePickerDataSource.cellIdentifier, for: indexPath as IndexPath)
        
        if let timeCell = cell as? TimePickerCollectionCell {
            
            var hour = Int(startHour) + indexPath.row / 2
            if hour > 23 {
                hour = 0
            }
            
            if indexPath.row % 2 == 1 {
                timeCell.time.text = "\(hour):30"
            }else {
                timeCell.time.text = "\(hour):00"
            }
            timeCell.layer.cornerRadius = 5
            
            let (startSelection, endSelection) = self.selectionRange
            
            
            if startSelection == endSelection  {
                if indexPath.row == startSelection {
                    timeCell.selectedState = true
                }else {
                    timeCell.selectedState = false
                }
            } else {
                if indexPath.row  >= startSelection && indexPath.row <= endSelection {
                    timeCell.selectedState = true
                }else {
                    timeCell.selectedState = false
                }
            }
            
            print("IndexPath.row:\(indexPath.row) section:\(indexPath.section), startSelection:\(startSelection) endSelection:\(endSelection)")
        }
        
        return cell
    }
    
    func selectTime(at indexPath: IndexPath) {
        
        if currentSelection == 0 {
            firstSelection = indexPath.row
            currentSelection = 1
        }else {
            secondSelection = indexPath.row
            currentSelection = 0
        }
    }
    
    func selectTime(time:String) {
        
        var timeArr = time.components(separatedBy: ":")
        
        let begin: Double = Double("\(timeArr[0])")! + convertHalfHourToDouble(hour: timeArr[1])
        let end: Double = Double("\(timeArr[0])")! + 1 + convertHalfHourToDouble(hour: timeArr[1])
        
        selectTime(openAt: begin, closeAt: end)
    }
    
    func selectTime(startAt: String, endAt:String) {
        
        var timeArr = startAt.components(separatedBy: ":")
        
        let openAt: Double = Double("\(timeArr[0])")! + convertHalfHourToDouble(hour: timeArr[1])
        
        timeArr = endAt.components(separatedBy: ":")
        let endAt: Double = Double("\(timeArr[0])")! + convertHalfHourToDouble(hour: timeArr[1])
        
        selectTime(openAt: openAt, closeAt: endAt)
    }
    
    private func convertHalfHourToDouble(hour: String) -> Double {
        if hour == "30" {
            return 0.5
        }else {
            return 0.0
        }
    }
    
    func selectTime(openAt: Double, closeAt: Double) {
        
        let count = (Int(closeAt - startHour) - Int(ceil(openAt - startHour )) ) * 2
        
        firstSelection = Int(ceil(openAt) - startHour) * 2
        
        secondSelection = firstSelection + count
        
    }
    
    func timeSelection() -> (CGFloat, CGFloat) {
        
        let (startSelection, endSelection) = self.selectionRange
        
        var openAt : CGFloat = 0
        var closeAt : CGFloat = 0
        
        var hour = Int(startHour) + startSelection / 2
        
        if startSelection % 2 == 1 {
            openAt = CGFloat(hour) + CGFloat(0.5)
        }else {
            openAt = CGFloat(hour)
        }
        
        hour = Int(startHour) + endSelection / 2
        if endSelection % 2 == 1 {
            closeAt = CGFloat(hour) + CGFloat(0.5)
        }else {
            closeAt = CGFloat(hour)
        }
        
        return (openAt, closeAt)
    }
    
}
