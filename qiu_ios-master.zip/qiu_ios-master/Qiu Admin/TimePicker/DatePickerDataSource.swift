//
//  DatePickerDataSource.swift
//  Qiu
//
//  Created by Marcos Tirao on 9/15/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class DatePickerDataSource: NSObject, UICollectionViewDataSource {
    
    static let cellIdentifier = "dateCell"
    
    var startDate = Date()
    var selectedType : [Bool] = Array(repeating: false, count: 30)
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 30
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: DatePickerDataSource.cellIdentifier, for: indexPath as IndexPath)
        
        if let dateCell = cell as? DatePickerCollectionCell {
            let date = CalendarUtil.computeDay(byAdding: indexPath.row, toDate: startDate)
            let (dayName, _, _, day) = CalendarUtil.componentsForDate(forDate: date)
            dateCell.backgroundColor = UIColor.white
            dateCell.day.text = "\(day)"
            dateCell.dayName.text = "\(dayName)".localizable()
            dateCell.layer.cornerRadius = 5
        }
        
        return cell

    }
    
    func select(at indexPath: IndexPath, collectionView: UICollectionView) -> Date{
        let date = CalendarUtil.computeDay(byAdding: indexPath.row, toDate: startDate)
        selectedType[indexPath.row] = true
        
        if let dateCell = collectionView.cellForItem(at: indexPath) as? DatePickerCollectionCell{
            dateCell.setSelect(state: true)
        }
        
        return date
    }
    
    func deselect(itemAt indexPath: IndexPath, collectionView: UICollectionView) {
        
        if let dateCell = collectionView.cellForItem(at: indexPath) as? DatePickerCollectionCell{
            dateCell.setSelect(state: false)
        }
        
        selectedType[indexPath.row] = false
        
    }
    
    func select(itemWithDate: String, collectionView: UICollectionView) {
        
    }
    
}
