//
//  CalendarUtilities.swift
//  Easy Planner
//
//  Created by Marcos Tirao on 3/22/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation

class CalendarUtil {
    
    static let dayName = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"]
    
    class func string(from date: Date, timeOnly:Bool) -> String{
        
        let formatter = DateFormatter()
        
        if timeOnly {
            formatter.dateFormat = "HH:mm"
        }else  {
            formatter.dateStyle = .medium
        }
        
        return formatter.string(from: date)
        
    }
    
    
    class func mysqlString(from date: Date) -> String {
        
        let formatter = DateFormatter()
        formatter.dateFormat = " YYYY-MM-dd hh:mm:ss"
        
        return formatter.string(from: date)
        
    }
    
    class func firstHourOfCurrentDate(forDate: Date) -> Date {
        
        let currentCalendar = Calendar.current
        let unitFlags = Set<Calendar.Component>([.year, .month, .day, .hour, .minute, .second])
        var comp = currentCalendar.dateComponents(unitFlags, from: forDate)
        comp.setValue(0, for: .hour)
        comp.setValue(0, for: .minute)
        comp.setValue(0, for: .second)
        
        return currentCalendar.date(from: comp)!
        
    }
    
    class func lastHourOfCurrentDate(forDate: Date) -> Date {
        
        let currentCalendar = Calendar.current
        let unitFlags = Set<Calendar.Component>([.year, .month, .day, .hour, .minute, .second])
        var comp = currentCalendar.dateComponents(unitFlags, from: forDate)
        comp.setValue(23, for: .hour)
        comp.setValue(59, for: .minute)
        comp.setValue(59, for: .second)
        
        
        return currentCalendar.date(from: comp)!
        
    }
    
    class func startOfMonth(forDate: Date) -> Date {
        return Calendar.current.date(from: Calendar.current.dateComponents([.year, .month], from: Calendar.current.startOfDay(for: forDate)))!
    }
    
    class func endOfMonth(forDate: Date) -> Date {
        return Calendar.current.date(byAdding: DateComponents(month: 1, day: -1), to: CalendarUtil.startOfMonth(forDate: forDate))!
    }
    
    class func startOfYear(forDate: Date) -> Date {
        
        var dateComponents = Calendar.current.dateComponents([.year, .month, .day], from: forDate)
        dateComponents.day = 1
        dateComponents.month = 1
        
        let date = Calendar.current.date(from: dateComponents)
        
        return date!
    }
    
    class func endOfYear(forDate: Date) -> Date {
        var dateComponents = Calendar.current.dateComponents([.year, .month, .day], from: forDate)
        dateComponents.day = 31
        dateComponents.month = 12
        
        let date = Calendar.current.date(from: dateComponents)
        
        return date!

    }
    
    class func dateFromComponents(day: Int, month: Int, year: Int) -> Date {
        
        let dateComponents = DateComponents(calendar: Calendar.current, year: year, month: month, day: day)
        let date = Calendar.current.date(from: dateComponents)
        
        return date!
    }
    
    class func dateFromComponents(day: Int, month: Int, year: Int, hour: Int, minute: Int, second: Int) -> Date {
        
        let dateComponents = DateComponents(calendar: Calendar.current, year: year, month: month, day: day, hour:hour, minute: minute, second:second)
        
        
        let date = Calendar.current.date(from: dateComponents)
        
        return date!
    }
    
    class func dateFromComponents(hour: Int, minute: Int) -> Date {
        
        let (year, month, day) = CalendarUtil.componentsForDate(forDate: Date())
        let dateComponents = DateComponents(calendar: Calendar.current, year: year, month: month, day: day, hour: hour, minute: minute)

        let date = Calendar.current.date(from: dateComponents)
        
        return date!
    }
    
    class func componentsForDate(forDate: Date) -> (Int, Int, Int) {
        let dateComponents = Calendar.current.dateComponents([.year, .month, .day], from: forDate)
        return (dateComponents.year ?? 0, dateComponents.month ?? 0, dateComponents.day ?? 0)
    }
    
    class func componentsForDate(forDate:Date) -> (String, Int, Int, Int) {
        let dateComponents = Calendar.current.dateComponents([.weekday, .year, .month, .day], from: forDate)
        return (dayName[(dateComponents.weekday ?? 1) - 1], dateComponents.year ?? 0, dateComponents.month ?? 0, dateComponents.day ?? 0)
    }
    
    class func componentsForDate(forDate:Date) -> (Int, Int) {
        let dateComponents = Calendar.current.dateComponents([.hour, .minute], from: forDate)
        return (dateComponents.hour ?? 0, dateComponents.minute ?? 0)
    }
    
    
    class func roundToNearestHour(from: Date) -> Date {
        
        let currentCalendar = Calendar.current
        let unitFlags = Set<Calendar.Component>([.year, .month, .day, .hour, .minute, .second])
        var comp = currentCalendar.dateComponents(unitFlags, from: from)
        
        let min = comp.minute!
        let minutes = min - (min % 30)
        comp.minute = Int(minutes)
        
        
        return currentCalendar.date(from: comp) ?? Date()
        
    }
    
    class func computeHour(byAdding: Int, toDate: Date) -> Date {
        let result = toDate.addingTimeInterval(Double(byAdding) * 3600)
        return result
    }
    
    class func computeDay(byAdding: Int, toDate: Date) -> Date {
        let result = toDate.addingTimeInterval(Double(byAdding) * 3600 * 24)
        return result
    }
    
    
}
