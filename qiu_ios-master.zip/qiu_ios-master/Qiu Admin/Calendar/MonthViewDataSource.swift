

//
//  MonthViewDataSource.swift
//  Qiu
//
//  Created by Marcos Tirao on 8/15/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

protocol MonthViewDataSource {
    
    func numberOfWeeks() -> Int
    func numberOfDaysPerWeek() -> Int
    func viewForDayAt(indexPath: IndexPath) -> UIView
    func calendarForMonth(month: Int) -> [[Int]]
    func currentYear() -> Int
    func today(day: Int, month: Int, year: Int) -> Bool
    
}
