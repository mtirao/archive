//
//  MonthView.swift
//  Easy Planner
//
//  Created by Marcos Tirao on 5/19/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class MonthView: UIView {

    private var currentSelection : UILabel?
    
    private var dayWidth : Int = 0
    private var dayVStep : Int = 0
    
    var month : Int?
    var year : Int?
    var delegate: MonthViewDelegate?
    var dataSource: MonthViewDataSource?

    
    let numColums = 7
    let numRows = 6
    
    let header : Int = 10
    
    let dayNames = ["SUN".localizable(), "MON".localizable(), "TUE".localizable(), "WED".localizable(), "THU".localizable(), "FRI".localizable(), "SAT".localizable()]
    
    
    
    @IBInspectable var fontSize: CGFloat = 9
    @IBInspectable var dayNameFontSize : CGFloat  = 7
    @IBInspectable var headerSpacing:Int = 0
    @IBInspectable var daySpacing: Int = 0
    @IBInspectable var dayMargin: Int = 0
    @IBInspectable var longMonthName: Bool = false
    @IBInspectable var dayName: Bool = false
    @IBInspectable var maximunVStep = 50
    @IBInspectable var weekHeight = 50
    @IBInspectable var currentDayColor : CGColor = UIColor.black.cgColor
    @IBInspectable var dayNameColor :CGColor = UIColor.black.cgColor
    @IBInspectable var dayFont = UIFont.systemFont(ofSize: 9)
    @IBInspectable var dayNameFont = UIFont.systemFont(ofSize: 7)
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func removeAllMonth() {
        for view in self.subviews {
            view.removeFromSuperview()
        }
    }
    
    func minimumSizeToFit() -> CGSize {
        
        let headerSpacing = header + Int(self.headerSpacing)
        
        return CGSize (width: Int(self.frame.width), height: ((self.dataSource?.numberOfWeeks() ?? 0) + 1) * weekHeight + headerSpacing)
    }
    
    func dataMonth(forMonth: Int) {
        
        guard let calendarDataSource = self.dataSource else {
            return
        }
        
        self.month = forMonth
        self.year = calendarDataSource.currentYear()
        
        
        let dayHStep = Int(self.frame.width) / 7
        
        dayVStep = (Int(self.frame.height) - header) / 6
        dayVStep = dayVStep > maximunVStep ? maximunVStep : dayVStep
        
        
        let calendar = calendarDataSource.calendarForMonth(month: forMonth)
        
        var headerSpacing = header + Int(self.headerSpacing) + Int(daySpacing)
        
        if calendar[5][0] == 0 {
            headerSpacing = header + Int(self.headerSpacing) + Int(daySpacing) + 8
        }
        
        let view = UIView(frame: CGRect(x: 0, y: 0,  width: Int(self.frame.width), height: header + Int(headerSpacing * 2)))
        view.backgroundColor = self.backgroundColor
        self.addSubview(view)
        
        if dayName {
            for i in 0..<numColums {
                let day = UILabel(frame: CGRect(x: i * dayHStep, y: 4 , width: dayHStep - daySpacing, height: Int(dayNameFontSize) + 4))
                day.text = self.dayNames[i]
                day.font = UIFont.boldSystemFont(ofSize: dayNameFontSize)
                day.textColor = UIColor(cgColor: dayNameColor)
                day.textAlignment = .center
                self.addSubview(day)
            }
        }
        
        var xCoordinate = 0
        var lineWidth = 0
        
        for row in 0..<calendarDataSource.numberOfWeeks() {
            let weekView = UIView(frame: CGRect(x: 0, y: (weekHeight + 1)*row + Int(dayNameFontSize) + headerSpacing , width:Int(self.frame.width), height:weekHeight))
            weekView.backgroundColor = self.backgroundColor
            
            for col in 0..<calendarDataSource.numberOfDaysPerWeek() {
                if calendar[row][col] != 0 {
                    
                    let text = String(calendar[row][col])
                    let myString: NSString = text as NSString
                    let size: CGSize = myString.size(withAttributes: [kCTFontAttributeName as NSAttributedStringKey: UIFont.systemFont(ofSize: fontSize)])
                    
                    dayWidth = Int(sqrt(size.width * size.width + size.height * size.height))
                    
                    let label = UILabel(frame: CGRect(x: col * dayHStep + daySpacing + dayMargin, y: 4, width: dayWidth, height: dayWidth))
                    
                    if xCoordinate == 0 {
                        xCoordinate = col * dayHStep + daySpacing + dayMargin
                    }
                    
                    if delegate != nil {
                        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(MonthView.didSelectDay(sender:)))
                        label.isUserInteractionEnabled = true
                        label.addGestureRecognizer(tapGesture)
                    }
                    
                    label.font = dayFont
                    label.text = String(calendar[row][col])
                    label.textAlignment = .center
                    
                    if calendarDataSource.today(day: calendar[row][col], month: self.month! + 1, year: self.year!) {
                        selectLabel(label: label, color: UIColor(cgColor: currentDayColor))
                    }
                    
                    lineWidth = col * dayHStep + daySpacing + dayMargin + dayWidth
                    
                    weekView.addSubview(label)
                    
                }
            }
            
            
            let horizontalLine = UIView(frame: CGRect(x:CGFloat(xCoordinate), y: CGFloat(weekHeight - 4), width: CGFloat(lineWidth), height:CGFloat(0.5)))
            horizontalLine.backgroundColor = UIColor.lightGray
            weekView.addSubview(horizontalLine)
            
            xCoordinate = 0;
            
            self.addSubview(weekView)
            
        }
        
    }
    
    
    
    @objc func didSelectDay(sender:UITapGestureRecognizer?) {
        if let label = sender?.view as? UILabel {
            
            if (dataSource?.today(day: Int((self.currentSelection?.text) ?? "0")!, month: self.month! + 1, year: self.year!))! {
                self.currentSelection?.backgroundColor = Theme.dayColor
                self.currentSelection?.textColor = UIColor.white
            }else {
                self.currentSelection?.backgroundColor = self.backgroundColor
                self.currentSelection?.textColor = UIColor.black
            }
            
           
            selectLabel(label: label, color: UIColor.black)
            delegate?.didSelectDate(day: Int(label.text!)!, month: self.month! + 1, year: self.year!)
            self.currentSelection = label
        }
    }
    
    private func selectLabel(label: UILabel, color: UIColor) {
        label.backgroundColor = color
        label.textColor = UIColor.white
        label.layer.masksToBounds = true
        label.layer.cornerRadius = CGFloat(label.frame.width) / 2.0
    }
}
