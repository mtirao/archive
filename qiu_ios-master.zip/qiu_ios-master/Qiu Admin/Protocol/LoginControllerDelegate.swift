//
//  LoginDelegate.swift
//  Qiu
//
//  Created by Marcos Tirao on 8/21/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

protocol LoginControllerDelegate: class{
    
    func didFinishedLogin()
    func didFinshedLoginWithError()
    
}
