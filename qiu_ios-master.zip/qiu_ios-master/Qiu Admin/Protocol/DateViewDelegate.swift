//
//  DateViewDelegate.swift
//  Qiu
//
//  Created by Marcos Tirao on 9/4/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation

protocol DateViewDelegate: class {
    
    func didSelectOpen(open: Bool)
    
}
