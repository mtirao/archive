//
//  LogiSheetDelegate.swift
//  Qiu
//
//  Created by Marcos Tirao on 8/21/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation

protocol LoginSheetDelegate: class {
    
    func loginEmail(email: String, password: String)
    
}
