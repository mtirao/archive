//
//  TurnCellDelegate.swift
//  Qiu
//
//  Created by Marcos Tirao on 08/10/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

protocol TurnCellDelegate: class {
    
    func didSelectFirstHalf(at hour: String)
    func didSelectSecondHalf(at hour: String)
    
}
