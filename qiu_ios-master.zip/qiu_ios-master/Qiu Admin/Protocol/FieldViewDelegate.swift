//
//  didSelectFirstResponder.swift
//  Qiu
//
//  Created by Marcos Tirao on 9/6/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

protocol FieldViewDelegate: class {

    func didSelectFirstResponder(frame: CGRect)
    func textDidChange(fieldView:FieldView, text: String)
    
}
