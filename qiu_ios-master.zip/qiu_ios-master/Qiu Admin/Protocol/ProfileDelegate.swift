//
//  ProfileDelegate.swift
//  Qiu
//
//  Created by Marcos Tirao on 8/26/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

protocol ProfileDelegate {

    func didLogout()
    
}
