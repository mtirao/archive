//
//  RadioButton.swift
//  Qiu
//
//  Created by Marcos Tirao on 27/10/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit
import SnapKit
import UIFontComplete

class RadioButton: UIView, RadioGroupItemProtocol {

    private let staticText: UILabel
    private let button: UIButton
    
    var labelFont : UIFont? {
        set {
            self.staticText.font = newValue
        }
        
        get {
            return self.staticText.font
        }
    }
    
    var isEnable : Bool {
        get {
            return button.isEnabled
        }
        set {
            button.isEnabled = newValue
        }
    }
    
    var delegate: RadioButtonDelegate?
    
    init(frame: CGRect, label: String) {
        
        self.staticText = UILabel();
        self.staticText.font = UIFont(name:Font.helveticaNeue.rawValue, size: UIFont.systemFontSize )
        self.staticText.text = label
        self.button = UIButton()
        self.button.setImage(UIImage(named:"radio-on-button"), for:.selected)
        self.button.setImage(UIImage(named:"radio-on-button"), for:.disabled)
        self.button.setImage(UIImage(named:"radio-on-button"), for: .normal)
        
        super.init(frame:frame)
        
        self.button.addTarget(self, action: #selector(RadioButton.selectAction), for: .touchUpInside)
        
        self.addSubview(self.button)
        self.button.snp.makeConstraints{ (make) -> Void in
            make.height.width.equalTo(20)
            make.left.equalTo(Theme.leading)
            make.top.equalTo(0)
        }
        
        self.addSubview(staticText)
        self.staticText.snp.makeConstraints{ (make) -> Void in
            make.height.equalTo(30)
            make.left.equalTo(self.button.snp.right).offset(Theme.leading)
            make.centerY.equalTo(self.button.snp.centerY)
            make.right.equalTo(self.snp.right)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        self.staticText = UILabel()
        self.button = UIButton()
        
        super.init(coder: aDecoder)
    
    }
    
    @objc func selectAction() {
        self.delegate?.didSelect(button: self)
    }
    
    func didSelect() {
        self.button.isSelected = true
    }
    
    func didDeselect() {
        self.button.isSelected = false
    }

}
