//
//  FormItemProtocol.swift
//  Qiu
//
//  Created by Marcos Tirao on 27/10/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

protocol RadioGroupItemProtocol {
    
    func didSelect()
    func didDeselect()

}
