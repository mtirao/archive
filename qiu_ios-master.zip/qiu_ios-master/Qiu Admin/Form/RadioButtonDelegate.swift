//
//  RadioButtonDelegate.swift
//  Qiu
//
//  Created by Marcos Tirao on 27/10/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation

protocol RadioButtonDelegate: class {

    func didSelect(button: RadioButton)


}
