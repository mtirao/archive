//
//  FormView.swift
//  Qiu
//
//  Created by Marcos Tirao on 27/10/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class RadioGroup: UIView, RadioButtonDelegate {
    
    private var radioButtons : [RadioButton] = [RadioButton]()
    
    var isEnable : Bool {
        set {
            for button in radioButtons {
                button.isEnable = newValue
            }
        }
        
        get {
            return radioButtons[0].isEnable
        }
    }
    
    init(frame: CGRect, buttonLabels: [String]) {
        
        super.init(frame: frame)
        
        var index = 0
        for label in buttonLabels {
            let button = RadioButton(frame: CGRect(x:0, y:0, width:0, height:0), label: label)
            button.delegate = self
            radioButtons.append(button)
            self.addSubview(button)
            button.snp.makeConstraints{(make) -> Void in
                make.height.equalTo(30)
                make.trailing.equalTo(self)
                make.leading.equalTo(self)
                if index == 0 {
                    make.top.equalTo(0)
                    button.didSelect()
                }else {
                    make.top.equalTo(radioButtons[index - 1].snp.bottom).offset(5)
                }
            }
            index = index + 1
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func didSelect(button: RadioButton) {
        for buttons in radioButtons {
            buttons.didDeselect()
        }
        button.didSelect()
    }
}
