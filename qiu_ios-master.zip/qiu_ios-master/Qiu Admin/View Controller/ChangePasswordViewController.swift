//
//  ChangePasswordViewController.swift
//  Qiu
//
//  Created by Marcos Tirao on 9/3/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit
import UIFontComplete

class ChangePasswordViewController: UIViewController {
    
    
    let currentPassword = FieldView(frame: CGRect(x:0, y:0, width:0, height:0), type: .password, label: "CURRENT_PASSWORD".localizable())
    
    let newPassword = FieldView(frame: CGRect(x:0, y:0, width:0, height:0), type: .password, label: "NEW_PASSWORD".localizable())
    let confirmPassword = FieldView(frame: CGRect(x:0, y:0, width:0, height:0), type: .password, label: "CONFIRM_PASSWORD".localizable())
    
    let save = QuiButton()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationController?.navigationBar.tintColor = UIColor.white
        self.view.backgroundColor = UIColor.white
        
        self.currentPassword.placeholder = "CURRENT_PASSWORD_PLACEHOLDER".localizable()
        self.newPassword.placeholder = "NEW_PASSWORD_PLACEHOLDER".localizable()
        self.confirmPassword.placeholder = "CONFIRM_PASSWORD_PLACEHOLDER".localizable()
        
        self.currentPassword.labelFont =  UIFont(name:Font.helveticaNeue.rawValue, size:UIFont.systemFontSize )
        self.newPassword.labelFont =  UIFont(name:Font.helveticaNeue.rawValue, size:UIFont.systemFontSize )
        self.confirmPassword.labelFont =  UIFont(name:Font.helveticaNeue.rawValue, size:UIFont.systemFontSize )
       
        self.view.addSubview(currentPassword)
        currentPassword.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(self.topLayoutGuide.snp.bottom).offset(16)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(-10)
            make.height.equalTo(50)
        }
        
        self.view.addSubview(newPassword)
        newPassword.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(currentPassword.snp.bottom).offset(16)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(-10)
            make.height.equalTo(50)
        }
        
        self.view.addSubview(confirmPassword)
        confirmPassword.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(newPassword.snp.bottom).offset(16)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(-10)
            make.height.equalTo(50)
        }

        
        save.layer.cornerRadius = 20
        save.addTarget(self, action: #selector(ChangePasswordViewController.changePassword), for: .touchUpInside)
        save.setTitle("SAVE_PASSWORD".localizable(), for: .normal)
        save.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        save.titleLabel?.textColor = UIColor.white
        save.backgroundColor = Theme.qiuRed
        save.alpha = 1.0
        self.view.addSubview(save)
        save.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(confirmPassword.snp.bottom).offset(40)
            make.trailing.leading.equalToSuperview().inset(UIEdgeInsetsMake(0, 16, 0, 16))
            make.height.equalTo(40)
        }

        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @objc func changePassword() {
        
        save.showLoading()
        
        guard let currentPassword = self.currentPassword.data else {
            return
        }
        
        guard let newPassword = self.newPassword.data else {
            return
        }
        
        guard let confirmPassword = self.confirmPassword.data else {
            return
        }
        
        if newPassword != confirmPassword {
            self.confirmPassword.info = "CHANGE_PASSWORD_CONFIRM_ERROR".localizable()
            return
        }
        
        let dataProvider = Request()
        let authorizeViewModel = AuthorizationViewModel(dataProvider: dataProvider)
        
        authorizeViewModel.authorize(oldPassword: currentPassword, newPassword: newPassword, completion:{(response) -> Void in
            
            DispatchQueue.main.async {
                
                self.navigationController?.popViewController(animated: true)
                self.save.hideLoading()
            }
            
        }, error: {(error) -> Void in
            DispatchQueue.main.async {
                self.currentPassword.info = "CHANGE_PASSWORD_CURRENT_ERROR".localizable()
                self.save.hideLoading()
            }
            
        })
    }
    

}
