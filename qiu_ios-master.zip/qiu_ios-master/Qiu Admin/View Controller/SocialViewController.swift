//
//  SocialViewController.swift
//  Qiu
//
//  Created by Marcos Tirao on 8/18/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit
import TwitterKit

class SocialViewController: TWTRTimelineViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        
        
        TWTRTwitter.sharedInstance().start(withConsumerKey: "gRWr6NVapfIRCYxnec6CbBpqQ", consumerSecret: "IQiJhFKx1ndnfkQhozDQ5yj20rWmVZtlYAaB9gewkfJqd3sabQ", accessGroup: nil)
        
        
        let dataSource = TWTRListTimelineDataSource(listSlug: "QiuProApp", listOwnerScreenName: "QiuProApp", apiClient: TWTRAPIClient()) //TWTRUserTimelineDataSource(screenName: "archetapp", apiClient: TWTRAPIClient())
        
        
        self.dataSource = dataSource//TWTRListTimelineDataSource(listSlug: "QiuProApp", listOwnerScreenName: "qiuproapp", apiClient: client)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        Tracking.userEnterView(viewName: .socialView)
        
        
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.navigationBar.barTintColor = Theme.navigationBackgroundColor
        
    }

    override var prefersStatusBarHidden: Bool {
        return false
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        Tracking.userExitView(viewName: .socialView)
        
    }

}
