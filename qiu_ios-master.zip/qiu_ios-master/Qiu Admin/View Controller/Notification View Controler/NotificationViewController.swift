//
//  Notification.swift
//  Qiu
//
//  Created by Marcos Tirao on 8/16/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class NotificationViewController: UIViewController, UITableViewDelegate {

    let notificationTable = UITableView()
    
    var messageViewModel : MessageViewModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let dataProvider = Request()
        messageViewModel = MessageViewModel(dataProvider: dataProvider)
        
        createNotificationTable()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        Tracking.userEnterView(viewName: .notificationView)
        
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.navigationBar.barTintColor = Theme.navigationBackgroundColor
        
        messageViewModel?.message(completion: {
            DispatchQueue.main.async {
                self.notificationTable.reloadData()
            }
        }, error: { _ in
            print("Something bad happend")
        })
    }
    
    override var prefersStatusBarHidden: Bool {
        return false
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        Tracking.userExitView(viewName: .notificationView)
        
    }
    
    func createNotificationTable() {
        
        notificationTable.register(UINib(nibName: "NotificationTableCell", bundle: nil), forCellReuseIdentifier: MessageViewModel.cellIdentifier)
        notificationTable.dataSource = self.messageViewModel
        notificationTable.delegate = self
        self.view.addSubview(notificationTable )
        notificationTable.estimatedRowHeight = 64
        notificationTable.backgroundColor = UIColor.white
        notificationTable.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(self.topLayoutGuide.snp.top)
            make.leading.trailing.equalTo(0)
            make.bottom.equalTo(self.bottomLayoutGuide.snp.bottom)
        }
        
    }

}

//MARK: - Table View Delegate & Datasource
extension NotificationViewController {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let viewController = NotificationDetailViewController()
        
        if let message = messageViewModel?.message(atIndex: indexPath) {
            viewController.titleField.data = message.title
            viewController.messageField.data = message.message
            viewController.creationDateField.data = Theme.dateShortFormat(date: message.createAt as Date)
            self.navigationController?.pushViewController(viewController, animated: true)
        }
        
    }
}
