//
//  NotificationDetailViewController.swift
//  Qiu
//
//  Created by Marcos Tirao on 21/04/2018.
//  Copyright © 2018 Marcos Tirao. All rights reserved.
//

import UIKit
import UIFontComplete

class NotificationDetailViewController: UIViewController {
    
    let titleField = FieldView(frame: CGRect(x:0, y:0, width:0, height:0), type: .text, label: "TITLE".localizable())
    let creationDateField = FieldView(frame: CGRect(x:0, y:0, width:0, height:0), type: .text, label: "DATE".localizable())
    let messageField = FieldView(frame: CGRect(x:0, y:0, width:0, height:0), type: .multiText, label: "MESSAGE".localizable())
    
    let save = QuiButton()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.tintColor = UIColor.white
        self.view.backgroundColor = UIColor.white
        
        self.titleField.placeholder = "TITLE".localizable()
        self.creationDateField.placeholder = "DATE".localizable()
        self.messageField.placeholder = "MESSAGE".localizable()
        
        self.titleField.enabled = false
        self.creationDateField.enabled = false
        self.messageField.enabled = false
        
        self.titleField.labelFont =  UIFont(name:Font.helveticaNeueBold.rawValue, size:UIFont.systemFontSize )
        self.creationDateField.labelFont =  UIFont(name:Font.helveticaNeueBold.rawValue, size:UIFont.systemFontSize )
        self.messageField.labelFont =  UIFont(name:Font.helveticaNeueBold.rawValue, size:UIFont.systemFontSize )
        
        self.view.addSubview(titleField)
        titleField.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(self.topLayoutGuide.snp.bottom).offset(16)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(-10)
            make.height.equalTo(50)
        }
        
        self.view.addSubview(creationDateField)
        creationDateField.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(titleField.snp.bottom).offset(16)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(-10)
            make.height.equalTo(50)
        }
        
        self.view.addSubview(messageField)
        messageField.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(creationDateField.snp.bottom).offset(16)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(-10)
            make.height.equalTo(120)
        }
        
        
        save.layer.cornerRadius = 20
        save.addTarget(self, action: #selector(ContactUsViewController.sendMessage), for: .touchUpInside)
        save.setTitle("DELETE_MESSAGE".localizable(), for: .normal)
        save.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        save.titleLabel?.textColor = UIColor.white
        save.backgroundColor = Theme.qiuRed
        save.alpha = 1.0
        self.view.addSubview(save)
        save.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(messageField.snp.bottom).offset(30)
            make.trailing.leading.equalToSuperview().inset(UIEdgeInsetsMake(0, 16, 0, 16))
            make.height.equalTo(40)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated
    }
    
    
    
    @objc func sendMessage() {
        
        self.save.showLoading()
        
        /*let dataProvider = Request()
        let messageViewModel = MessageViewModel(dataProvider: dataProvider)
        messageViewModel.sendMessage(to: .support, title: "question", message: message.data ?? "", type: .query , completion: {
            let alert = Alert(presenting: self)
            self.save.hideLoading()
            alert.showAlert(title: "MESSAGE_TITLE".localizable(), message: "MESSAGE_DESCRIPTION".localizable(), handler: { _ -> Void in
                DispatchQueue.main.async{
                    self.navigationController?.popViewController(animated: true)
                }
            })
        }, error: {(error) -> Void in
            
            self.save.hideLoading()
            let alert = Alert(presenting: self)
            alert.showAlert(title: "MESSAGE_TITLE".localizable(), message: "MESSAGE_DESCRIPTION_ERROR".localizable())
            print("Todo mal")
        })*/
        
    }
    
}
