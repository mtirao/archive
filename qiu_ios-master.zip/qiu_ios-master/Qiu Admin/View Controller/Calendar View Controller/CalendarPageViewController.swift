//
//  CalendarPageControllerViewController.swift
//  Qiu
//
//  Created by Marcos Tirao on 7/28/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class CalendarPageViewController: UIPageViewController, UIPageViewControllerDataSource, LoginControllerDelegate {

    var viewControllersModel : [CalendarViewController] = [CalendarViewController()]
    
    var titleLabel : UILabel?
    
    let loginViewController = LoginViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let addTurn = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(CalendarPageViewController.addTurn))
        self.navigationController?.navigationBar.tintColor = UIColor.white
        self.navigationItem.rightBarButtonItem = addTurn

        self.dataSource = self
        
        self.automaticallyAdjustsScrollViewInsets = false
        
        titleLabel?.text = viewControllersModel[0].headerName()
        
        self.setViewControllers(viewControllersModel, direction: .forward, animated: true, completion: nil)
        
        NotificationController.notificationObserver(observer: self, selector: #selector(CalendarPageViewController.updateMonthHeader), name: Notes.newMonthNotification.notification)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        Tracking.userEnterView(viewName: .calendarView)

        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.navigationBar.barTintColor = Theme.navigationBackgroundColor

    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        Tracking.userExitView(viewName: .calendarView)

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @objc func updateMonthHeader(notification: Notification) {
        if let month = notification.userInfo?["Header"] as? String {
            titleLabel?.text = month
        }
    }
    
    
    
    @objc func addTurn() {
        
        if !Preferences.isLogged {
            loginViewController.delegate = self
            self.present(loginViewController, animated: true, completion: nil)
        }else {
            didFinishedLogin()
        }
    }
    
    
}


//MARK: LoginControllerDelegate
extension CalendarPageViewController {
    
    func didFinishedLogin() {
        DispatchQueue.main.async {
            self.loginViewController.dismiss(animated: true, completion: {
                DispatchQueue.main.async {
                    let turnViewController = TurnViewController()
                    self.present(turnViewController, animated: true, completion: nil)
                }
            })
            
        }
    }
    
    func didFinshedLoginWithError() {
        
    }
    
}

// MARK: UIPageViewControllerDataSource
extension CalendarPageViewController  {
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        
        guard let currentIndex = self.viewControllersModel.index(of: viewController as! CalendarViewController) else {
            return nil
        }
        
        if currentIndex == self.viewControllersModel.count - 1 {
            
            let viewController = self.viewControllersModel[currentIndex]
            
            var month = viewController.month
            var year = viewController.year
            
            if(month >= 11) {
                month = 0
                year += 1
            }else {
                month += 1
            }
            
            let calendarController = CalendarViewController(year: year, month: month)
            
            
            self.viewControllersModel.append(calendarController)
            self.setViewControllers(viewControllers, direction: .forward, animated: true, completion: nil)
            
            return self.viewControllersModel[currentIndex+1]
        }
        
        return self.viewControllersModel[currentIndex + 1]
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        
        guard let currentIndex = self.viewControllersModel.index(of: viewController as! CalendarViewController) else {
            return nil
        }
        
        if currentIndex == 0 {
            
            let viewController = self.viewControllersModel[currentIndex]
            
            var month = viewController.month
            var year = viewController.year
            
            if(month <= 0) {
                month = 11
                year -= 1
            }else {
                month -= 1
            }
            
            let calendarController = CalendarViewController(year: year, month: month)
            
            self.viewControllersModel.insert(calendarController, at: 0)
            self.setViewControllers(viewControllers, direction: .forward, animated: true, completion: nil)
            
            return self.viewControllersModel[0]
        }
        
        return self.viewControllersModel[currentIndex - 1]
    }
    
    
}
