//
//  CalendarViewController.swift
//  Qiu
//
//  Created by Marcos Tirao on 7/26/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit
import SnapKit
import UIFontComplete



class CalendarViewController: UIViewController, MonthViewDelegate, MonthViewDataSource, UITableViewDelegate {
    
    
    let calendarModel : CalendarModel
    let turnsTable = UITableView()
    
    
    var year : Int
    var month: Int
    
    var monthView : MonthView?
    
    var dataSource = CalendarTurnModel()
    
    var selectedDate: Date?
    
    init(year:Int, month:Int) {
        
        self.year = year
        self.month = month
        calendarModel = CalendarModel(year: self.year)
        
        super.init(nibName: nil, bundle: nil)
    }
    
    init() {
        let (year, month, _) = CalendarUtil.componentsForDate(forDate: Date())
        
        self.year = year
        self.month = month - 1
        
        calendarModel = CalendarModel(year: self.year)
        
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        
        let (year, month, _) = CalendarUtil.componentsForDate(forDate: Date())
        
        self.year = year
        self.month = month - 1
        
        calendarModel = CalendarModel(year: self.year)
        
        super.init(coder: aDecoder)
    }
    
    func headerName() -> String {
        return "\(calendarModel.monthName(month: month)) \(year)"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        monthView = MonthView(frame:self.view.frame)
        monthView?.dataSource = self
        monthView?.delegate = self
        
        
        calendarModel.longMonthName = true
        //self.headerLabel?.text = "\(calendarModel.monthName(month: month)) \(year)"
        
        //Setting up monthView
        monthView?.fontSize = 18
        monthView?.dayNameFontSize = 13
        monthView?.dayName = true
        monthView?.headerSpacing = 4
        monthView?.daySpacing = 4
        monthView?.dayMargin = 8
        monthView?.currentDayColor = Theme.dayColor.cgColor
        monthView?.dayNameColor = Theme.qiuGreen.cgColor
        monthView?.dayFont = UIFont(name: Font.helveticaNeueThin.rawValue, size: 15)!
        monthView?.dayNameFont = UIFont(name: Font.helveticaNeueThin.rawValue, size: 9)!
        
        monthView?.backgroundColor = UIColor.white
        monthView?.layer.borderColor = Theme.lightGray.cgColor
        self.view.addSubview(monthView!)
        
        monthView?.dataMonth(forMonth: month)
        
        monthView?.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(self.topLayoutGuide.snp.bottom)
            make.height.equalTo(monthView!.minimumSizeToFit().height)
            make.trailing.leading.equalTo(0)
        }
        monthView?.setNeedsLayout()
        
        
        //Setting up turns table for selectedDay
        turnsTable.register(UINib(nibName: "CalendarCell", bundle: nil), forCellReuseIdentifier: CalendarTurnModel.calendarTableCell)
        turnsTable.dataSource = self.dataSource
        turnsTable.delegate = self
        turnsTable.estimatedRowHeight = 54
        self.view.addSubview(turnsTable)
        turnsTable.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(monthView!.snp.bottom)
            make.trailing.leading.equalTo(0)
            make.bottom.equalTo(0)
        }
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        NotificationController.postNotification(name: Notes.newMonthNotification.notification, userInfo: ["Header" as NSObject:self.headerName() as AnyObject])
        
        let dataProvider = Request()
        let turnViewModel = TurnViewModel(dataProvider: dataProvider)
        
        turnViewModel.turnAllOwner(completion: {
            self.loadTurn()
            DispatchQueue.main.sync {
                self.turnsTable.reloadData()
            }            
        })
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        super.viewDidAppear(animated)
        //monthView?.dataMonth(forMonth: month)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var prefersStatusBarHidden: Bool {
        return false
    }
    
    func loadTurn() {
        if self.selectedDate != nil {
            self.dataSource.loadTurn(for: self.selectedDate!)
        }
    }
}


//MARK: - CalendarDelegate 
extension CalendarViewController {
    
    func didSelectDate(day: Int, month: Int, year: Int) {
        
        let selectDate = CalendarUtil.dateFromComponents(day: day, month: month, year: year)
        
        self.selectedDate = selectDate
        
        self.dataSource.loadTurn(for: selectDate)
        self.turnsTable.reloadData()
        
    }
    
}

extension CalendarViewController {
    
    func numberOfWeeks() -> Int {
        return calendarModel.weeks + 1
    }
    
    func numberOfDaysPerWeek() -> Int {
        return 7
    }
    
    func viewForDayAt(indexPath: IndexPath) -> UIView {
        return UIView()
    }
    
    func calendarForMonth(month: Int) -> [[Int]] {
        return calendarModel.calendarForMonth(month: month + 1)
    }
    
    func currentYear() -> Int {
        return calendarModel.year
    }
    
    func today(day: Int, month: Int, year: Int) -> Bool {
        return calendarModel.today(day: day, month:month, year: year)
    }
    
}

extension CalendarViewController {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let turn = dataSource.turn(at: indexPath)
        
        if dataSource.isTurnToOwnSportcenter(at: indexPath) {
            let detail = TurnOwnDetailViewController()
            detail.sportVisible = false
            detail.court = turn.ground ?? ""
            detail.currentTurn = turn
            detail.time = "" //Theme.turnTimeShorFormat(date: turn.date! as Date, time: turn.time! as Date)
            self.present(detail, animated: true, completion: nil)
        }else {
            let detail = TurnViewController()
            detail.currentTurn = turn
            self.present(detail, animated: true, completion: nil)
        }
        
        if dataSource.isOwnTurn(at: indexPath) {
            let detail = TurnOwnDetailViewController()
            let turn = dataSource.turn(at: indexPath)
            detail.court = turn.ground ?? ""
            detail.currentTurn = turn
            detail.time = "" //Theme.turnTimeShorFormat(date: turn.date! as Date, time: turn.time! as Date)
            self.present(detail, animated: true, completion: nil)
        }
        
    }
    
}
