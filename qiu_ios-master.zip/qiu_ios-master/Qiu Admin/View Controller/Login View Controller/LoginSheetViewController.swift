//
//  LoginSheetViewController.swift
//  Qiu
//
//  Created by Marcos Tirao on 8/20/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class LoginSheetViewController: UIViewController, ModalPresentable {
    
    let emailField = FieldView(frame: CGRect(x:0, y:0, width:0, height:0), type: .email, label: "EMAIL".localizable())
    let passwordField = FieldView(frame: CGRect(x:0, y:0, width:0, height:0), type: .password, label: "PASSWORD".localizable())
    let emailLogin = UIButton()
    
    weak var delegate : LoginSheetDelegate?

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = UIColor.white
        
        emailField.placeholder = "user@email.com".localizable()
        passwordField.placeholder = "Your password".localizable()
        
        self.modalPresentationStyle = .formSheet
        
        let closeButton = UIButton()
        closeButton.setImage(UIImage(named: "close"), for: .normal)
        closeButton.addTarget(self, action: #selector(LoginSheetViewController.closeAction), for: .touchUpInside)
        self.view.addSubview(closeButton)
        closeButton.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(16)
            make.trailing.equalTo(Theme.trailing)
            make.height.width.equalTo(24)
        }
        
        
        self.view.addSubview(emailField)
        emailField.snp.makeConstraints{(make) -> Void in
            make.top.equalToSuperview().offset(40)
            make.leading.equalTo(10)
            make.trailing.equalTo(-10)
            make.height.equalTo(50)
        }
        
        self.view.addSubview(passwordField)
        passwordField.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(emailField.snp.bottom).offset(40)
            make.leading.equalTo(10)
            make.trailing.equalTo(-10)
            make.height.equalTo(50)
        }

        
        emailLogin.layer.cornerRadius = 25
        emailLogin.addTarget(self, action: #selector(LoginSheetViewController.loginAction(sender:)), for: .touchUpInside)
        emailLogin.setTitle("LOGIN".localizable(), for: .normal)
        emailLogin.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        emailLogin.titleLabel?.textColor = UIColor.white
        emailLogin.backgroundColor = Theme.qiuRed
        emailLogin.alpha = 1.0
        self.view.addSubview(emailLogin)
        emailLogin.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(passwordField.snp.bottom).offset(40)
            make.trailing.leading.equalToSuperview().inset(UIEdgeInsetsMake(0, 16, 0, 16))
            make.height.equalTo(50)
            
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @objc func loginAction(sender: Any) {
        
        _ = emailField.resignFirstResponder()
        _ = passwordField.resignFirstResponder()
        
        guard let email = emailField.data else  {
            return
        }
        
        guard let password = passwordField.data else {
            return
        }
        
        if !isValidEmail(testStr: email) {
            self.emailField.info = "EMAIL_ALERT_MESSAGE".localizable()
            return
        }
        
        if password.count <= 6 {
            self.passwordField.info = "PASSWORD_ALERT_MESSAGE".localizable()
            return
            
        }
        
        self.dismiss(animated: true, completion: { [weak del = self.delegate] in
            del?.loginEmail(email: email, password: password)
        })
    }
    
    @objc func closeAction() {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    func isValidEmail(testStr:String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: testStr)
    }
    
    
}
