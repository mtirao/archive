//
//  LoginViewController.swift
//  Qiu
//
//  Created by Marcos Tirao on 8/19/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit
import FBSDKCoreKit
import FBSDKLoginKit
import AccountKit

class LoginViewController: UIViewController, UIViewControllerTransitioningDelegate, LoginSheetDelegate, AKFViewControllerDelegate{

    
    var phoneLogin = QuiButton()
    var facebookLogin = QuiButton()
    
    let buttonImageLeft :CGFloat = -25
    
    let loginSheet = LoginSheetViewController()
    
    let dataProvider = Request()
    
    var interactiveDismiss = false
    
    var keyboardAlreadyShowed = false
    
    var frame: CGRect?
    
    weak var delegate : LoginControllerDelegate?
    
    var accountKit : AKFAccountKit?
    var pendingLoginViewController : AKFViewController?
    var authorizationCode: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if accountKit == nil {
            accountKit = AKFAccountKit(responseType: .accessToken)
        }
        
        pendingLoginViewController = accountKit!.viewControllerForLoginResume()
        
        NotificationCenter.default.addObserver(self, selector: #selector(LoginViewController.keyboardShow(notification:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(LoginViewController.keyboardHide(notification:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)

        
        self.navigationController?.isNavigationBarHidden = true
        self.loginSheet.delegate = self
        
        let backgroundImage = UIImageView(image: UIImage(named: "launch-screen-background"))
        self.view.addSubview(backgroundImage)
        backgroundImage.snp.makeConstraints{(make) -> Void in
            make.top.bottom.equalTo(0)
            make.trailing.leading.equalTo(0)
        }
        
        let button = UIButton()
        button.addTarget(self, action: #selector(LoginViewController.closeAction), for: .touchUpInside)
        button.setImage(UIImage(named:"close-white"), for: .normal)
        self.view.addSubview(button)
        button.snp.makeConstraints{(make) -> Void in
            make.top.equalToSuperview().offset(24)
            make.leading.equalToSuperview().offset(24)
            make.height.equalTo(40)
        }
        
        
        phoneLogin.layer.cornerRadius = 25
        phoneLogin.addTarget(self, action: #selector(LoginViewController.buttonPressed(sender:)), for: .touchDown)
        phoneLogin.addTarget(self, action: #selector(LoginViewController.phoneLoginAction), for: .touchUpInside)
        phoneLogin.setTitle("PHONE_LOGIN".localizable(), for: .normal)
        phoneLogin.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        phoneLogin.titleLabel?.textColor = UIColor.white
        phoneLogin.backgroundColor = Theme.qiuRed
        phoneLogin.alpha = 1.0
        phoneLogin.setImage(UIImage(named:"mobile"), for: .normal) // imageView = UIImageView(UIImage(name:"email"))
        phoneLogin.imageEdgeInsets = UIEdgeInsetsMake(0, buttonImageLeft - 5, 0, 0)
        self.view.addSubview(phoneLogin)
        phoneLogin.snp.makeConstraints{(make) -> Void in
            make.bottom.equalToSuperview().inset(UIEdgeInsetsMake(0, 0, 110, 0))
            make.trailing.leading.equalToSuperview().inset(UIEdgeInsetsMake(0, 16, 0, 16))
            make.height.equalTo(50)
            
        }
        
        facebookLogin.layer.cornerRadius = 25
        facebookLogin.addTarget(self, action: #selector(LoginViewController.buttonPressed(sender:)), for: .touchDown)
        facebookLogin.addTarget(self, action: #selector(LoginViewController.facebookLoginAction), for: .touchUpInside)
        facebookLogin.setTitle("FACEBOOK_LOGIN".localizable(), for: .normal)
        facebookLogin.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        facebookLogin.titleLabel?.textColor = UIColor.white
        facebookLogin.backgroundColor = Theme.facebookColor
        facebookLogin.setImage(UIImage(named:"facebook"), for: .normal)
        facebookLogin.imageEdgeInsets = UIEdgeInsetsMake(0, buttonImageLeft, 0, 0)
        facebookLogin.alpha = 1.0
        self.view.addSubview(facebookLogin)
        facebookLogin.snp.makeConstraints{(make) -> Void in
            make.bottom.equalToSuperview().inset(UIEdgeInsetsMake(0, 0, 200, 0))
            make.trailing.leading.equalToSuperview().inset(UIEdgeInsetsMake(0, 16, 0, 16))
            make.height.equalTo(50)
            
        }

    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        Tracking.userEnterView(viewName: .loginView)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        Tracking.userExitView(viewName: .loginView)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @objc func closeAction() {
        
        if Preferences.onboarded {
            self.dismiss(animated: true, completion: nil)
        }else {
            NotificationController.postNotification(name: Notes.endOnboardNotification.notification, userInfo: nil)
        }
    }
    
    @objc func phoneLoginAction() {
       
        guard let accKit = accountKit else {
            return
        }
        
        let viewController = accKit.viewControllerForPhoneLogin(with: nil, state: UUID().uuidString) as AKFViewController
        
        viewController.enableSendToFacebook = true
        viewController.delegate = self
        
        self.present(viewController as! UIViewController, animated: true, completion: nil)
        
    }
    
    @objc func facebookLoginAction() {
        
        facebookLogin.showLoading()
        
        FBSDKAccessToken.refreshCurrentAccessToken{ (request,arg1,arg2)  -> Void in
            print(arg2?.localizedDescription ?? "No error")
        }
        
        let fbLoginManager : FBSDKLoginManager = FBSDKLoginManager()

        fbLoginManager.logIn(withReadPermissions: ["public_profile", "email"], from: self, handler: { (result, error) -> Void in
            if (error != nil) {
                
            } else if (result?.isCancelled)! {
                self.facebookLogin.hideLoading()
                
                let alert = Alert(presenting: self)
                alert.showAlert(title: "FACEBOOK_AUTHORIZE_ERROR".localizable(), message: "FACEBOOK_AUTHORIZE_ERROR_MESSAGE".localizable(), handler: { action -> Void in
                    self.dismiss(animated: true, completion: nil)
                })
                
                
            } else {
                if let fbloginresult : FBSDKLoginManagerLoginResult = result {
                    
                    if let permissions = fbloginresult.grantedPermissions {
                        if(permissions.contains("email")) {

                            let authorizeViewModel = AuthorizationViewModel(dataProvider: self.dataProvider)
                            
                            let fbGraph = FBSDKGraphRequest.init(graphPath: "me", parameters: ["fields" : "id,name,email"])
                            let _ = fbGraph?.start(completionHandler: { connection, result, error in
                                
                                if error == nil {
                                
                                    let data = result as! [String : AnyObject]
                                    
                                    let email = data["email"] as! String
                                    let name = data["name"] as! String
                                    
                                    authorizeViewModel.authorize(email: email, name:name , completion:{ [unowned self] (response) -> Void in
                                        
                                        response.save()
                                        
                                        let login = LoginModel()
                                        login.load()
                                        let token = login.token
                                        
                                        
                                        if Preferences.onboarded {
                                            self.loadProfileInfo(token: token, facebookLogin: true)
                                        }else {
                                            
                                            self.loadProfileInfo(token: token, facebookLogin: true, ignoreDelegate: true)
                                            NotificationController.postNotification(name: Notes.endOnboardNotification.notification, userInfo: nil)
                                        }
                                        
                                        self.facebookLogin.hideLoading()
                                        
                                        self.delegate?.didFinishedLogin()
                                        
                                        }, error: {(error) -> Void in
                                            self.showError(error: error)
                                            
                                            self.facebookLogin.hideLoading()
                                        }
                                    )
                                }else {
                                    self.showError(error: ErrorResponse.networkError)
                                    self.facebookLogin.hideLoading()
                                }
                                
                            })
                            
                            
                        }
                    }
                }
            }
        })
    }
    
    func viewController(_ viewController: (UIViewController & AKFViewController)!, didCompleteLoginWith accessToken: AKFAccessToken!, state: String!) {
        
        self.accountKit?.requestAccount({ (account, error) -> Void in
            if error == nil {
                self.loginMobile(mobile: account?.phoneNumber?.phoneNumber ?? "" )
            }else {
                self.showError(error: ErrorResponse.networkError)
                self.phoneLogin.hideLoading()
            }
            
        })
    }
   
    
    func loginMobile(mobile: String) {
        
        phoneLogin.showLoading()
        
        let authorizeViewModel = AuthorizationViewModel(dataProvider: dataProvider)
        
        authorizeViewModel.authorize(mobile: mobile, completion:{ (response) -> Void in
            
            //Preferences.serverToken = response._id
            self.phoneLogin.hideLoading()
            response.save()
            
            let login = LoginModel()
            login.load()
            let token = login.token
            
            if Preferences.onboarded {
                
                self.loadProfileInfo(token: token, facebookLogin: false )
            }else {
                self.loadProfileInfo(token: token, facebookLogin: false, ignoreDelegate: true)
                NotificationController.postNotification(name: Notes.endOnboardNotification.notification, userInfo: nil)
            }
            
        }, error: {(error) -> Void in
            self.phoneLogin.hideLoading()
            self.showError(error: error)
        })
    }
    
    //Login button was pressed form the login sheet
    func loginEmail(email: String, password: String) {
        
        phoneLogin.showLoading()
        
        let dataProvider = Request()
        let authorizeViewModel = AuthorizationViewModel(dataProvider: dataProvider)
        
        authorizeViewModel.authorize(email: email, password: password, completion:{ (response) -> Void in
            
            response.save()
            
            let login = LoginModel()
            login.load()
            let token = login.token
            
            if Preferences.onboarded {
                
                self.loadProfileInfo(token: token, facebookLogin: false)
                
            }else {
                self.loadProfileInfo(token: token, facebookLogin: false, ignoreDelegate: true)
                
                NotificationController.postNotification(name: Notes.endOnboardNotification.notification, userInfo: nil)
            }
            
        }, error: {(error) -> Void in
            self.showError(error: error)
        })
        
        self.phoneLogin.hideLoading()
        
    }
    
    
    @objc func buttonPressed(sender: Any) {
        
    }
    
    func showError(error: ErrorResponse?) {
        
        let alert = Alert(presenting: self)
        alert.showError(error: error, completion: {_ in 
            if Preferences.onboarded {
                self.delegate?.didFinshedLoginWithError()
            }else {
                NotificationController.postNotification(name: Notes.endOnboardNotification.notification, userInfo: nil)
            }
        })

    }
    
    func loadProfileInfo(token: String, facebookLogin: Bool, ignoreDelegate: Bool = false) {
        
        let profileViewModel = ProfileViewModel(dataProvider: dataProvider)
        profileViewModel.profile(token: token, completion: {
        
            let sportcenterViewModel = SportcenterViewModel(dataProvider: self.dataProvider)
            sportcenterViewModel.listSportCenterOwned(completion: {
                self.delegate?.didFinishedLogin()
            }, error: {(error) -> Void in
                self.delegate?.didFinishedLogin()
            })
            
            if(facebookLogin) {
                self.facebookLogin.hideLoading()
            }else {
                self.phoneLogin.hideLoading()
            }
            
        }, error: {(error) -> Void in
            if(facebookLogin) {
                self.facebookLogin.hideLoading()
            }else {
                self.phoneLogin.hideLoading()
            }
            if !ignoreDelegate {
                self.delegate?.didFinshedLoginWithError()
            }
            
        })
    }
    
}

extension LoginViewController {
    
    @objc func keyboardShow(notification:Notification) {
        
        if keyboardAlreadyShowed {
            return
        }
        
        if frame == nil {
            frame = self.loginSheet.view.frame
        }
        
        let passwordField = view.convert(self.loginSheet.passwordField.frame, from:self.loginSheet.view)
        
        let yCoordinate = self.view.frame.size.height - passwordField.origin.y
        let actualFrame = CGRect(x:0, y: yCoordinate, width: self.loginSheet.view.frame.width, height: self.loginSheet.view.frame.size.height + yCoordinate)
        
        loginSheet.maximizeToFrame(frame: actualFrame)
        
        keyboardAlreadyShowed = true
    }
    
    @objc func keyboardHide(notification:Notification) {
        if let frame = self.frame {
            loginSheet.maximizeToFrame(frame: frame)
        }
        keyboardAlreadyShowed = false
    }
    
}

extension LoginViewController {
    
    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return ModalTransitionAnimator(type: .Dismiss)
    }
    
    func presentationController(forPresented presented: UIViewController, presenting: UIViewController?, source: UIViewController) -> UIPresentationController? {
        return ModalPresentationController(presentedViewController: presented, presenting: presenting)
    }
    
    
    func interactionControllerForDismissal(using animator: UIViewControllerAnimatedTransitioning) -> UIViewControllerInteractiveTransitioning? {
        
        return nil
    }
}


