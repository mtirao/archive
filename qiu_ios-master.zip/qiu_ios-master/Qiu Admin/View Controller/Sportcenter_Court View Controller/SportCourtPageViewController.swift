//
//  SportCourtPageViewController.swift
//  Qiu
//
//  Created by Marcos Tirao on 9/8/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit
import UIFontComplete

class SportCourtPageViewController: UIPageViewController, UIPageViewControllerDataSource {
    
    var viewControllersModel : [SportCourtViewController] = [SportCourtViewController]()
    
    var groundModel : GroundModel = GroundModel()
    
    let pageControl = UIPageControl()
    
    
    
    let graphImage = UIImageView(image: UIImage(named:"graph"))
    let moneyImage = UIImageView(image: UIImage(named:"money"))
    let gearsImage = UIImageView(image: UIImage(named:"gears"))
    
    let line1 = UILabel()
    let line2 = UILabel()
    let line3 = UILabel()
    let line4 = UILabel()
    let line5 = UILabel()
    let line6 = UILabel()
    let line7 = UILabel()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let addCourt = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(SportCourtPageViewController.addCourt))
        self.navigationController?.navigationBar.tintColor = UIColor.white
        self.navigationItem.rightBarButtonItem = addCourt

        self.view.backgroundColor = UIColor.white

        
        super.viewDidLoad()
        
        self.view.backgroundColor = UIColor.white
        self.navigationController?.navigationBar.isHidden = true
        
        //Presentation
        
        
        presentationView()
        
        self.dataSource = self
        self.automaticallyAdjustsScrollViewInsets = false
        
        pageControl.currentPage = 0
        pageControl.numberOfPages = viewControllersModel.count
        pageControl.pageIndicatorTintColor = Theme.lightGray
        pageControl.currentPageIndicatorTintColor = Theme.qiuGreen
        self.view.addSubview(pageControl)
        pageControl.snp.makeConstraints{(make) -> Void in
            make.centerX.equalTo(self.view.snp.centerX)
            make.bottom.equalTo(self.view.snp.bottom).offset(-64)
        }
        
        let swipeGesture = UISwipeGestureRecognizer(target: self, action: #selector(SportCourtPageViewController.removeCourt))
        swipeGesture.direction = .up
        self.view.addGestureRecognizer(swipeGesture)
        
        self.view.bringSubview(toFront: pageControl)
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.navigationController?.navigationBar.isHidden = false
        
        let groundModel = GroundModel()
        
        if groundModel.count > 0 {
            viewControllersModel.removeAll()
            graphImage.removeFromSuperview()
            moneyImage.removeFromSuperview()
            gearsImage.removeFromSuperview()
            
            line1.removeFromSuperview()
            line2.removeFromSuperview()
            line3.removeFromSuperview()
            line4.removeFromSuperview()
            line5.removeFromSuperview()
            line6.removeFromSuperview()
            line7.removeFromSuperview()
        }
        
        for i in 0 ..< groundModel.count {
            let sportViewController = SportCourtViewController()
            sportViewController.setGround(ground: groundModel.ground(at: IndexPath(row: i, section: 0)))
            self.viewControllersModel.append(sportViewController)
        }
        
        if self.viewControllersModel.count > 0 {
            pageControl.numberOfPages = viewControllersModel.count
            pageControl.currentPage = viewControllersModel.count - 1
            
            let last = self.viewControllersModel.last!
            self.setViewControllers([last], direction: .forward, animated: true, completion: nil)
        }
       
    }
    
    @objc func removeCourt(gesture:UISwipeGestureRecognizer) {

        let alert = UIAlertController(title: "DELETE_COURT_ALERT".localizable(), message: "DELETE_COURT_ALERT_MESSAGE".localizable(), preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .destructive, handler: {  [unowned self] action -> Void   in
            
            let current = self.pageControl.currentPage
            
            UIView.animate(withDuration: 0.6, animations: {
                self.viewControllersModel[current].view.alpha = 0
                
            }, completion:{ [unowned self] result -> Void in
                
                let viewController = self.viewControllersModel[current]
                
                self.groundModel.delete(withId: viewController.courtId!)
                    
                self.viewControllersModel.remove(at: current)
                
                if self.viewControllersModel.count > 0 {
                    let last = self.viewControllersModel.last!
                    
                    self.pageControl.numberOfPages = self.viewControllersModel.count
                    self.pageControl.currentPage = current
                    
                    self.setViewControllers([last], direction: .forward, animated: true, completion: nil)
                }else {
                    self.presentationView()
                }
               
                
                let dataProvider = Request()
                let groundViewModel = GroundViewModel(dataProvider: dataProvider)
                
                groundViewModel.deleteGround(sportcenter: viewController.courtId!, completion: { (response) -> Void in
                    NSLog("Court Remove from server")
                }, error: { _ in 
                    NSLog("Court dont Remove from server")
                })
                
            })
            
            
        })
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: nil)
        
        alert.addAction(okAction)
        alert.addAction(cancelAction)
        
        DispatchQueue.main.async {
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    @objc func addCourt() {
        
        if self.viewControllersModel.count == 0 {
            
            graphImage.removeFromSuperview()
            moneyImage.removeFromSuperview()
            gearsImage.removeFromSuperview()
            
            line1.removeFromSuperview()
            line2.removeFromSuperview()
            line3.removeFromSuperview()
            line4.removeFromSuperview()
            line5.removeFromSuperview()
            line6.removeFromSuperview()
            line7.removeFromSuperview()
        }
        
        viewControllersModel.append(SportCourtViewController())
        
        //self.viewControllers?.append(viewControllersModel)
        let last = viewControllersModel.last!
        
        pageControl.numberOfPages = viewControllersModel.count
        pageControl.currentPage = viewControllersModel.count - 1
        
        
        self.setViewControllers([last], direction: .forward, animated: true, completion: nil)
    }
    //MARK: - Presentation View
    func presentationView() {
        //IMAGES
        self.view.addSubview(graphImage)
        self.view.addSubview(moneyImage)
        self.view.addSubview(gearsImage)
        
        self.view.addSubview(line1)
        self.view.addSubview(line2)
        self.view.addSubview(line3)
        self.view.addSubview(line4)
        self.view.addSubview(line5)
        self.view.addSubview(line6)
        self.view.addSubview(line7)
        
        
        line1.font = UIFont(name:Font.helveticaNeue.rawValue, size:24)
        line1.textColor = UIColor.gray
        line1.text = "LINE1_SPORTCENTER_PRESENTATION".localizable()
        line1.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(self.topLayoutGuide.snp.bottom).offset(24)
            make.height.equalTo(25)
            make.left.equalTo(24)
            make.right.equalTo(0)
        }
        
        line2.font = UIFont(name:Font.helveticaNeue.rawValue, size:24)
        line2.textColor = UIColor.gray
        line2.text = "LINE2_SPORTCENTER_PRESENTATION".localizable()
        line2.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(line1.snp.bottom).offset(24)
            make.height.equalTo(25)
            make.left.equalTo(24)
            make.right.equalTo(0)
        }
        
        line3.font = UIFont(name:Font.helveticaNeue.rawValue, size:24)
        line3.textColor = UIColor.gray
        line3.text = "LINE3_SPORTCENTER_PRESENTATION".localizable()
        line3.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(line2.snp.bottom).offset(24)
            make.height.equalTo(25)
            make.left.equalTo(24)
            make.right.equalTo(0)
        }
        
        line4.font = UIFont(name:Font.helveticaNeue.rawValue, size:UIFont.systemFontSize)
        line4.textColor = UIColor.lightGray
        line4.text = "LINE4_SPORTCENTER_PRESENTATION".localizable()
        line4.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(line3.snp.bottom).offset(24)
            make.height.equalTo(25)
            make.left.equalTo(24)
            make.right.equalTo(0)
        }
        
        line5.font = UIFont(name:Font.helveticaNeue.rawValue, size:UIFont.systemFontSize)
        line5.textColor = UIColor.lightGray
        line5.text = "LINE5_SPORTCENTER_PRESENTATION".localizable()
        line5.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(line4.snp.bottom).offset(24)
            make.height.equalTo(25)
            make.left.equalTo(24)
            make.right.equalTo(0)
        }
        
        line6.font = UIFont(name:Font.helveticaNeue.rawValue, size:UIFont.systemFontSize)
        line6.textColor = UIColor.lightGray
        line6.text = "LINE6_SPORTCENTER_PRESENTATION".localizable()
        line6.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(line5.snp.bottom).offset(24)
            make.height.equalTo(25)
            make.left.equalTo(24)
            make.right.equalTo(0)
        }
        
        line7.font = UIFont(name:Font.helveticaNeue.rawValue, size:UIFont.systemFontSize)
        line7.textColor = UIColor.lightGray
        line7.text = "LINE7_SPORTCENTER_PRESENTATION".localizable()
        line7.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(line6.snp.bottom).offset(24)
            make.height.equalTo(25)
            make.left.equalTo(24)
            make.right.equalTo(0)
        }
        
        
        graphImage.snp.makeConstraints{(make) -> Void in
            make.bottom.equalTo(self.bottomLayoutGuide.snp.top).offset(-24)
            make.leading.equalTo(48)
            make.height.width.equalTo(40)
            
        }
        
        
        gearsImage.snp.makeConstraints{(make) -> Void in
            make.bottom.equalTo(self.bottomLayoutGuide.snp.top).offset(-24)
            make.centerX.equalTo(self.view.snp.centerX).offset(-8)
            make.height.width.equalTo(40)
            
        }
        
        
        moneyImage.snp.makeConstraints{(make) -> Void in
            make.bottom.equalTo(self.bottomLayoutGuide.snp.top).offset(-24)
            make.trailing.equalTo(-48)
            make.height.width.equalTo(40)
            
        }
    }
}



// MARK: UIPageViewControllerDataSource

extension SportCourtPageViewController  {
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        guard let currentIndex = self.viewControllersModel.index(of: viewController as! SportCourtViewController) else {
            return nil
        }
        
        if currentIndex == 0 {
            pageControl.currentPage = 0
            return nil
        }
        
        pageControl.currentPage = currentIndex
        return self.viewControllersModel[currentIndex - 1]
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        guard let currentIndex = self.viewControllersModel.index(of: viewController as! SportCourtViewController) else {
            return nil
        }
        
        if currentIndex == self.viewControllersModel.count - 1 {
            pageControl.currentPage = currentIndex
            return nil
        }
        
        pageControl.currentPage = currentIndex
        return self.viewControllersModel[currentIndex + 1]

    }
    
}
