//
//  SportCenterViewController.swift
//  Qiu
//
//  Created by Marcos Tirao on 9/3/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit
import SnapKit
import MapKit
import UIFontComplete


class SportCenterViewController: UIViewController, DateViewDelegate, FieldViewDelegate, UICollectionViewDelegate, MKMapViewDelegate {
    
    var delegate: PresentDelegate?
    
    let datasource = TimePickerDataSource()
    let mapView = MKMapView()
    let scrollView = UIScrollView()
    
    let nameField = FieldView(frame: CGRect(x:0, y:0, width:0, height:0), type: .text, label: "NAME_LABEL".localizable())
    let addressField = FieldView(frame: CGRect(x:0, y:0, width:0, height:0), type: .text, label: "ADDRESS_LABEL".localizable())
    let phoneField = FieldView(frame: CGRect(x:0, y:0, width:0, height:0), type: .number, label: "PHONE_LABEL".localizable())
    let aboutField = FieldView(frame: CGRect(x:0, y:0, width:0, height:0), type: .text, label: "ABOUT_LABEL".localizable())
    let emailField = FieldView(frame: CGRect(x:0, y:0, width:0, height:0), type: .email, label: "CONTACT_LABEL".localizable())
    
    let feeRequired = SwitchView(frame: CGRect(x:0, y:0, width:0, height:0), label: "FEE_REQUIRED".localizable())
    
    let sportCenter = QuiButton()
    
    let locationButton = UIButton(type: .custom)
 
    var timePickerCollectionView : UICollectionView?
    
    var keyboardSize : CGRect? = nil
    
    var sportCenterModel : SportCenterModel?
    
    var sportCenterLocation : CLLocationCoordinate2D?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let addCourt = UIBarButtonItem(title: "COURT".localizable(), style: .plain, target: self, action: #selector(SportCenterViewController.addCourt))
        let backButton = UIBarButtonItem(title: "", style: .plain, target: self, action: #selector(SportCenterViewController.backAction))
        backButton.image = UIImage(named:"left-arrow-white")
        self.navigationController?.navigationBar.tintColor = UIColor.white
        self.navigationItem.rightBarButtonItem = addCourt
        self.navigationItem.leftBarButtonItem = backButton
        self.navigationItem.title = "SPORT_CENTER".localizable()
        
        
        
        NotificationCenter.default.addObserver(self, selector: #selector(SportCenterViewController.keyboardShow(notification:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(SportCenterViewController.keyboardHide(notification:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
        
        self.view.backgroundColor = UIColor.white
        
        
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
        layout.itemSize = CGSize(width: 50, height: 50)
        layout.scrollDirection = .horizontal
        
        self.navigationController?.navigationBar.isHidden = false

        
        self.addressField.labelFont =  UIFont(name:Font.helveticaNeueBold.rawValue, size:UIFont.systemFontSize )
        self.nameField.labelFont =  UIFont(name:Font.helveticaNeueBold.rawValue, size:UIFont.systemFontSize )
        self.phoneField.labelFont =  UIFont(name:Font.helveticaNeueBold.rawValue, size:UIFont.systemFontSize )
        self.aboutField.labelFont =  UIFont(name:Font.helveticaNeueBold.rawValue, size:UIFont.systemFontSize )
        self.emailField.labelFont =  UIFont(name:Font.helveticaNeueBold.rawValue, size:UIFont.systemFontSize )
        self.feeRequired.labelFont = UIFont(name:Font.helveticaNeueBold.rawValue, size:UIFont.systemFontSize )
        self.feeRequired.state = true
        
        self.addressField.placeholder =  "ADDRESS_CENTER_PLACEHOLDER".localizable()
        self.nameField.placeholder =  "NAME_CENTER_PLACEHOLDER".localizable()
        self.phoneField.placeholder =  "PHONE_CENTER_PLACEHOLDER".localizable()
        self.aboutField.placeholder =  "ABOUT_CENTER_PLACEHOLDER".localizable()
        self.emailField.placeholder =  "CONTACT_CENTER_PLACEHOLDER".localizable()
        
        self.addressField.delegate = self
        self.nameField.delegate = self
        self.phoneField.delegate = self
        self.aboutField.delegate = self
        self.emailField.delegate = self
        
        self.addressField.enabled = false
        
        
        //Scrollview
        self.view.addSubview(scrollView)
        scrollView.snp.makeConstraints { make in
            make.right.left.bottom.equalTo(self.view)
            make.top.equalTo(self.view.snp.top)
        }
        
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(SportCenterViewController.tapOnMap(gesture:)))
        mapView.addGestureRecognizer(tapGesture)
        mapView.delegate = self
        mapView.showsUserLocation = true
        mapView.isScrollEnabled = true
        scrollView.addSubview(mapView)
        mapView.snp.makeConstraints{(make) -> Void in
            make.top.equalToSuperview()
            make.height.equalTo(250)
            make.leading.trailing.equalTo(self.view)
        }
        
        scrollView.addSubview(nameField)
        nameField.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(mapView.snp.bottom).offset(24)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(-10)
            make.height.equalTo(50)
        }
        
        scrollView.addSubview(addressField)
        addressField.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(nameField.snp.bottom).offset(24)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(-10)
            make.height.equalTo(50)
        }
        
        scrollView.addSubview(phoneField)
        phoneField.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(addressField.snp.bottom).offset(24)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(-10)
            make.height.equalTo(50)
        }
        
        scrollView.addSubview(aboutField)
        aboutField.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(phoneField.snp.bottom).offset(24)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(-10)
            make.height.equalTo(50)
        }
        
        scrollView.addSubview(emailField)
        emailField.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(aboutField.snp.bottom).offset(24)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(-10)
            make.height.equalTo(50)
        }
        
        scrollView.addSubview(feeRequired)
        feeRequired.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(emailField.snp.bottom).offset(24)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(-10)
            make.height.equalTo(50)
        }
        
        let openDoors = UILabel()
        openDoors.font = UIFont(name:Font.helveticaNeue.rawValue, size:UIFont.systemFontSize)
        openDoors.text = "OPEN_DOORS".localizable()
        scrollView.addSubview(openDoors)
        openDoors.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(feeRequired.snp.bottom).offset(24)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(-10)
            make.height.equalTo(21)
        }
        
        timePickerCollectionView = UICollectionView(frame: self.view.frame, collectionViewLayout: layout)
        timePickerCollectionView!.dataSource = self.datasource
        timePickerCollectionView!.delegate = self
        timePickerCollectionView!.register(UINib(nibName: "TimePickerCollectionCell", bundle: nil), forCellWithReuseIdentifier: TimePickerDataSource.cellIdentifier)
        timePickerCollectionView!.backgroundColor = Theme.lightLightGray
        self.view.addSubview(timePickerCollectionView!)
        timePickerCollectionView!.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(openDoors.snp.bottom).offset(Theme.topMargin)
            make.leading.equalTo(Theme.leading)
            make.trailing.equalTo(Theme.trailing)
            make.height.equalTo(layout.itemSize.height + layout.sectionInset.bottom + layout.sectionInset.top)
        }

        
        
        sportCenter.layer.cornerRadius = 20
        sportCenter.addTarget(self, action: #selector(SportCenterViewController.addSportCenter), for: .touchUpInside)
        sportCenter.changeState = false
        sportCenter.setTitle("ADD_SPORT_CENTER".localizable(), for: .normal)
        sportCenter.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        sportCenter.titleLabel?.textColor = UIColor.white
        sportCenter.alpha = 1.0
        scrollView.addSubview(sportCenter)
        sportCenter.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(timePickerCollectionView!.snp.bottom).offset(40)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(-10)
            make.height.equalTo(34)
        }
        
       
        
        locationButton.setImage(UIImage(named:"location"), for: .normal)
        locationButton.setImage(UIImage(named:"location"), for: .highlighted)
        locationButton.backgroundColor = UIColor.white
        locationButton.layer.cornerRadius = 5
        locationButton.tintColor =  Theme.qiuGreen
        locationButton.layer.shadowOffset = CGSize(width: 5, height: 5)
        locationButton.layer.shadowColor = UIColor.gray.cgColor
        locationButton.addTarget(self, action: #selector(SportCenterViewController.useCurrentLocation), for: .touchUpInside)
        self.view.addSubview(locationButton)
        locationButton.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(self.mapView.snp.top).offset(8)
            make.height.width.equalTo(35)
            make.right.equalTo(mapView.snp.right).inset(UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 16))
        }
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.sportCenterModel?.reloadData()
        
        if let center = self.sportCenterModel {
            
            if center.address.count > 0 {
                self.addressField.data = center.address
            }
            
            if center.about.count > 0 {
                self.aboutField.data = center.about
            }
            
            if center.name.count > 0 {
                self.nameField.data = center.name
            }
            
            if center.phone.count > 0 {
                self.phoneField.data = center.phone
            }
            
            if center.contact.count > 0 {
                self.emailField.data = center.contact
            }
            
            if center.latitud != 0 && center.longitude != 0{
                self.sportCenterLocation = CLLocationCoordinate2D(latitude: center.latitud, longitude: center.longitude)
                addAnnotation(for: self.sportCenterLocation!)
            }
            
            if center.openAt != 0 && center.closeAt != 0 {
                self.datasource.selectTime(openAt: center.openAt, closeAt: center.closeAt)
            }
            
            self.sportCenter.setTitle("UPDATE_SPORT_CENTER".localizable(), for: .normal)
            
            self.navigationItem.rightBarButtonItem?.isEnabled = true
        }else{
            self.navigationItem.rightBarButtonItem?.isEnabled = false
        }

    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        super.viewDidAppear(animated)
        
        if let location = self.sportCenterLocation {
            centerMapOnLocation(location: CLLocation(latitude: location.latitude, longitude: location.longitude))
        }else {
            let location = CLLocation(latitude: Preferences.latitude ?? 0.0, longitude: Preferences.longitude ?? 0.0)
            centerMapOnLocation(location: location)
        }
        
        let contentHeight = self.sportCenter.frame.origin.y + self.sportCenter.frame.size.height + CGFloat(Theme.topMargin)
        self.scrollView.contentSize = CGSize(width: self.view.frame.size.width, height: contentHeight)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}


//MARK:- Action Function
extension SportCenterViewController {
    
    @objc func backAction() {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    @objc func addCourt() {
        
        let court = SportCourtPageViewController(transitionStyle: .scroll, navigationOrientation: .horizontal, options: nil)
        self.navigationController?.pushViewController(court, animated: true)
    }
    
    func closeAction() {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    @objc func addSportCenter() {
        
        self.sportCenter.showLoading()
        
        let dataProvider = Request()
        let sportcenter = SportcenterViewModel(dataProvider: dataProvider)
        
        sportcenter.name = nameField.data!
        sportcenter.address = addressField.data!
        sportcenter.phone = phoneField.data!
        sportcenter.email = emailField.data!
        sportcenter.about = aboutField.data!
        sportcenter.mobileverify = "true"
        sportcenter.emailverify = "true"
        sportcenter.feerequired = "\(feeRequired.state)"
        
        let (openAt, closeAt) = self.datasource.timeSelection()
        sportcenter.openAt = openAt
        sportcenter.closeAt = closeAt
        sportcenter.latitude = (self.sportCenterLocation?.latitude)!
        sportcenter.longitude = (self.sportCenterLocation?.longitude)!
     
        if let error = sportcenter.validate() {
            
            let alert = Alert(presenting: self)
            
            if error == .authorizedFailedError {
                let alert = Alert(presenting: self)
                alert.showAlert(title:"SPORTCENTER_ERROR".localizable(), message: "LOGIN_REQUIRED".localizable())
                sportCenter.hideLoading()
            }else {
                alert.showAlert(title:"SPORTCENTER_ERROR".localizable(), message: "FIELD_REQUIRED".localizable())
                sportCenter.hideLoading()
                return
            }
            
        }else {
        
            sportcenter.addSportcenter(id: sportCenterModel?.id, completion: {
                
                self.sportCenter.hideLoading()
                DispatchQueue.main.async {
                    self.navigationController?.popToRootViewController(animated: true)
                }
                
            }, error: {(error) -> Void in
                
                let alert = Alert(presenting: self)
                alert.showAlert(title:"SPORTCENTER_ERROR".localizable(), message: "SPORTCENTER_ERROR_MESSAGE".localizable())
                
                DispatchQueue.main.async {
                    self.sportCenter.hideLoading()
                }
                
            })
        }
        
    }
}

//MARK:- Delegate Function DateViewDelegate, FieldViewDelegate
extension SportCenterViewController {
    
    func didSelectOpen(open: Bool) {
        let contentHeight = self.sportCenter.frame.origin.y + self.sportCenter.frame.size.height + CGFloat(Theme.topMargin)
        self.scrollView.contentSize = CGSize(width: self.view.frame.size.width, height: contentHeight)
    }
    
    func didSelectFirstResponder(frame: CGRect) {
        
        //let offset =  abs((self.keyboardSize?.origin.y ?? 0) - frame.origin.y)
        
        let aux = frame.origin.y + frame.size.height + 55
        let keyboard = self.keyboardSize?.origin.y ?? 0
        
        if aux < keyboard {
            let point = CGPoint(x: 0, y: keyboard - aux)
            self.scrollView.setContentOffset(point, animated: true)
        }
        
    }
    
    func textDidChange(fieldView: FieldView, text: String) {
        
        sportCenter.changeState = true
        
    }
    
}


//MARK: - DataSource Function TimePicker
extension SportCenterViewController {
        
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        self.datasource.selectTime(at: indexPath)
        
        self.timePickerCollectionView?.reloadData()
        
        if let cell = collectionView.cellForItem(at: indexPath) as? TimePickerCollectionCell {
            cell.selectedState = true
        }
        
        self.sportCenter.changeState = true
            
    }
    
}

//MARK:- Map delegate and other functions
extension SportCenterViewController {
    
   @objc func useCurrentLocation() {
            
        let location = self.mapView.userLocation.coordinate
        centerMapOnLocation(location: CLLocation(latitude: location.latitude, longitude: location.longitude))
        //addAnnotation(for:location)
        self.sportCenter.changeState = true
    }
    
    func updateLocationCity(location: CLLocationCoordinate2D) {
        
        let ceo = CLGeocoder()
        
        ceo.reverseGeocodeLocation(CLLocation(latitude: location.latitude, longitude: location.longitude)) { (placemarks, error) in
            if let placemark = placemarks?[0] {
                
                
                let annotation = MKPointAnnotation()
                let locality = placemark.locality ?? ""
                let country = placemark.country ?? ""
                
                if let name = self.nameField.data {
                    annotation.title = name
                }else {
                    annotation.title = "\(country), \(locality)"
                }
                
                if let locatedAt = placemark.addressDictionary {
                    if let street = locatedAt["Street"] as? String {
                        annotation.subtitle = street
                        self.addressField.data = street
                    }
                    
                    if let addrList = placemark.addressDictionary?["FormattedAddressLines"] as? [String] {
                        let address =  addrList.joined(separator: ", ")
                        print(address)
                    }
                    
                    
                }
                annotation.coordinate = location
                
                self.mapView.removeAnnotations(self.mapView.annotations)
                self.mapView.addAnnotation(annotation)
                self.sportCenterLocation = location
                
            }
            
        }
        
    }
    
    func addAnnotation(for location: CLLocationCoordinate2D) {
        
        let annotation = MKPointAnnotation()
        annotation.title = "Loading..."
        annotation.coordinate = location

        
        mapView.removeAnnotations(mapView.annotations)
        mapView.addAnnotation(annotation)
        updateLocationCity(location: location)
        
    }
    
    @objc func tapOnMap(gesture: UITapGestureRecognizer) {
        
        let location = gesture.location(in: mapView )
        
        let coordinate = mapView.convert(location, toCoordinateFrom: mapView)
        let coord = CLLocationCoordinate2D(latitude: coordinate.latitude, longitude: coordinate.longitude)
        
        
        addAnnotation(for: coord)
        
        self.sportCenter.changeState = true
        
    }
    
    func centerMapOnLocation(location: CLLocation) {
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate, regionRadius * 2.0, regionRadius * 2.0)
        mapView.setRegion(coordinateRegion, animated: true)
    }
}

//MARK: - Keyboard showing function
extension SportCenterViewController {
    @objc func keyboardShow(notification:Notification) {
        
        if let size = notification.userInfo?["UIKeyboardFrameBeginUserInfoKey"] as? CGRect{
            self.keyboardSize = size
        }
        
    }
    
    @objc func keyboardHide(notification:Notification) {
        self.keyboardSize = nil
    }
}
