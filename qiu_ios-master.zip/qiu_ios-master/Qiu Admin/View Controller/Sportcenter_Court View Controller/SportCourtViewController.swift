//
//  SportCourtViewController.swift
//  Qiu
//
//  Created by Marcos Tirao on 9/3/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit
import UIFontComplete

class SportCourtViewController: UIViewController, UICollectionViewDelegate, FieldViewDelegate {

    let court = QuiButton()
    
    let dataSource = TypeCollectionModel()
    
    let scrollView = UIScrollView()
    
    let nameField = FieldView(frame: CGRect(x:0, y:0, width:0, height:0), type: .text, label: "COURT_NAME".localizable())
    let priceField = FieldView(frame: CGRect(x:0, y:0, width:0, height:0), type: .currency, label: "PRICE".localizable())
    let feeField = FieldView(frame: CGRect(x:0, y:0, width:0, height:0), type: .currency, label: "FEE".localizable())
    
    var typeField : String?
    
    var keyboardSize : CGRect? = nil
    var collectionView : UICollectionView?

    var sportCenterModel: SportCenterModel?
    
    var courtId: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        sportCenterModel = SportCenterModel()
        
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.navigationBar.barTintColor = Theme.navigationBackgroundColor
        
        self.view.backgroundColor = UIColor.white
        
        NotificationCenter.default.addObserver(self, selector: #selector(SportCenterViewController.keyboardShow(notification:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(SportCenterViewController.keyboardHide(notification:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
             
        self.nameField.delegate = self
        self.priceField.delegate = self
        self.feeField.delegate = self
        
        let sportLabel = UILabel()
        sportLabel.text = "SPORTS".localizable()
        sportLabel.font = UIFont(name:Font.helveticaNeue.rawValue, size: UIFont.systemFontSize )
        
        sportLabel.textColor = UIColor.gray
        self.view.addSubview(sportLabel)
        sportLabel.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(self.topLayoutGuide.snp.bottom).offset(Theme.topMargin)
            make.leading.equalTo(Theme.leading)
            make.height.equalTo(20)
        }
       
        //Scrollview
        self.view.addSubview(scrollView)
        scrollView.snp.makeConstraints { make in
            make.right.left.bottom.equalTo(self.view)
            make.top.equalTo(self.view.snp.top)
        }
        
        //Colllection view for Sports
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
        layout.itemSize = CGSize(width: 90, height: 90)
        layout.scrollDirection = .horizontal
        
        collectionView = UICollectionView(frame: self.view.frame, collectionViewLayout: layout)
        collectionView!.dataSource = self.dataSource
        collectionView!.delegate = self
        collectionView!.register(UINib(nibName: "SportCollectionCell", bundle: nil), forCellWithReuseIdentifier: "sportCell")
        collectionView!.backgroundColor = UIColor.white
        scrollView.addSubview(collectionView!)
        collectionView!.snp.makeConstraints{(make) -> Void in
            
            make.top.equalTo(sportLabel.snp.bottom).offset(Theme.topMargin)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(-10)
            make.height.equalTo(layout.itemSize.height + layout.sectionInset.bottom + layout.sectionInset.top)
        }
        
        self.nameField.labelFont =  UIFont(name:Font.helveticaNeue.rawValue, size:UIFont.systemFontSize )
        self.nameField.placeholder = "NAME_COURT_PLACEHOLDER".localizable()
        scrollView.addSubview(nameField)
        nameField.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(collectionView!.snp.bottom).offset(32)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(-10)
            make.height.equalTo(50)
        }
        
        self.priceField.labelFont =  UIFont(name:Font.helveticaNeue.rawValue, size:UIFont.systemFontSize )
        self.priceField.placeholder = "PRICE_PLACEHOLDER".localizable()
        scrollView.addSubview(priceField)
        priceField.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(nameField.snp.bottom).offset(32)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(-10)
            make.height.equalTo(50)
        }
        
        self.feeField.labelFont =  UIFont(name:Font.helveticaNeue.rawValue, size:UIFont.systemFontSize )
        self.feeField.placeholder = "PRICE_PLACEHOLDER".localizable()
        scrollView.addSubview(feeField)
        feeField.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(priceField.snp.bottom).offset(32)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(-10)
            make.height.equalTo(50)
        }

        
        court.layer.cornerRadius = 20
        court.addTarget(self, action: #selector(SportCourtViewController.addSportCourt), for: .touchUpInside)
        court.setTitle("SAVE_SPORT_COURT".localizable(), for: .normal)
        court.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        court.titleLabel?.textColor = UIColor.white
        court.backgroundColor = Theme.qiuRed
        court.alpha = 1.0
        scrollView.addSubview(court)
        court.snp.makeConstraints{(make) -> Void in
            make.bottom.equalTo(self.bottomLayoutGuide.snp.top).offset(-10)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(-10)
            make.height.equalTo(40)
        }

        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        dataSource.loadData()
        
        self.dataSource.select(itemWithId: self.typeField ?? "" , collectionView: self.collectionView!)
    }
    override func viewDidAppear(_ animated: Bool) {
        
        super.viewDidAppear(animated)
        
        let contentHeight = self.court.frame.origin.y + self.court.frame.size.height + CGFloat(Theme.topMargin)
        self.scrollView.contentSize = CGSize(width: self.view.frame.size.width, height: contentHeight)
        
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @objc func addSportCourt() {
        
        court.showLoading()
        
        self.sportCenterModel?.reloadData()
        
        if !Preferences.isLogged {
            let alert = Alert(presenting: self)
            alert.showAlert(title:"Error", message: "You must be logged in")
            court.hideLoading()
            return
        }
        
        guard let name = self.nameField.data else{
            self.nameField.info = "NAME_FIELD_REQUIRED".localizable()
            court.hideLoading()
            return
        }
        
        guard let type = self.typeField else {
            let alert = Alert(presenting: self)
            alert.showAlert(title: "TYPE_REQUIRED".localizable(), message: "TYPE_REQUIRED_MESSAGE".localizable())
            court.hideLoading()
            return
        }
        
        if name.count <= 5 {
            self.nameField.info = "NAME_FIELD_REQUIRED".localizable()
            court.hideLoading()
            return
        }
        
        
        let price = self.priceField.dataAsNumber
        if price.int16Value < 0 {
            self.priceField.info = "PRICE_FIELD_REQUIRED".localizable()
            court.hideLoading()
            return
        }
        
        let fee = self.feeField.dataAsNumber
        if (self.sportCenterModel?.feerequired ?? false)  && (fee.int16Value < 0)  {
            self.priceField.info = "FEE_FIELD_REQUIRED".localizable()
            court.hideLoading()
            return
        }
        
        if fee.int16Value > price.int16Value {
            self.priceField.info = "FEE_FIELD_INVALID".localizable()
            court.hideLoading()
            return
        }
        
        
        guard let center = self.sportCenterModel?.id else {
            court.hideLoading()
            return;
        }
        
        let request = GroundRequest()
        request.type  = type
        request.name = name
        request.price = price
        request.fee = fee
        request.sportcenter = self.sportCenterModel?.id
        
        let dataProvider = Request()
        let groundViewModel = GroundViewModel(dataProvider: dataProvider)
        
        if let court = self.courtId {
            
            groundViewModel.updateGround(ground:court , param: request, completion: {(response) -> Void in
                    response.save()
                DispatchQueue.main.async {
                    self.court.hideLoading()
                }
            }, error: {(error) -> Void in
                
                let alert = Alert(presenting: self)
                alert.showAlert(title:"COURT_ERROR".localizable(), message: "COURT_ERROR_MESSAGE".localizable())
                
                DispatchQueue.main.async {
                    self.court.hideLoading()
                }
            })
            
        }else {
            groundViewModel.addGround(sportcenter:center , param: request, completion: {(response) -> Void in
                
                response.save()
                self.courtId = response._id
                DispatchQueue.main.async {
                    self.court.hideLoading()
                }
            }, error: {(error) -> Void in
                
                let alert = Alert(presenting: self)
                alert.showAlert(title:"COURT_ERROR".localizable(), message: "COURT_ERROR_MESSAGE".localizable())
                
                DispatchQueue.main.async {
                    self.court.hideLoading()
                }
            })
        }
    }
    
    func setGround(ground: Ground) {
        
        if let name = ground.name {
            self.nameField.data = name
        }
        
        let price = ground.price
        self.priceField.data = String(price) + ".00"
        
        let fee = ground.fee
        self.feeField.data = String(fee) + ".00"
        
        self.typeField = ground.type
        
        self.courtId = ground.id
    }
    
    
}

extension SportCourtViewController {
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        typeField = self.dataSource.select(itemAt: indexPath, collectionView: collectionView)
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        
        self.dataSource.deselect(itemAt: indexPath, collectionView: collectionView)
        
        typeField = nil
    }
    
}

//MARK:- Keyboard showing notification methods
extension  SportCourtViewController {
    
    
    @objc func keyboardShow(notification:Notification) {
        
        if let size = notification.userInfo?["UIKeyboardFrameBeginUserInfoKey"] as? CGRect{
            self.keyboardSize = size
        }
        
    }
    
    @objc func keyboardHide(notification:Notification) {
        self.keyboardSize = nil
    }
    
    func didSelectFirstResponder(frame: CGRect) {
        
        //let offset =  abs((self.keyboardSize?.origin.y ?? 0) - frame.origin.y)
        
        let aux = frame.origin.y + frame.size.height + 55
        let keyboard = self.keyboardSize?.origin.y ?? 0
        
        if aux > keyboard {
            let point = CGPoint(x: 0, y: aux - keyboard)
            self.scrollView.setContentOffset(point, animated: true)
        }
        
    }
    
    func textDidChange(fieldView: FieldView, text: String) {
        
    }

}
