//
//  SportCenterPresentationViewController.swift
//  Qiu
//
//  Created by Marcos Tirao on 9/7/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit
import SnapKit
import UIFontComplete

class SportCenterPresentationViewController: UIViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = UIColor.white
        self.navigationController?.navigationBar.isHidden = true
        
        //BUTTONS
        let next = UIButton()
        self.view.addSubview(next)
        
        let button = UIButton()
        self.view.addSubview(button)
        
        //IMAGES
        let graphImage = UIImageView(image: UIImage(named:"graph"))
        self.view.addSubview(graphImage)
        
        let moneyImage = UIImageView(image: UIImage(named:"money"))
        self.view.addSubview(moneyImage)
        
        let gearsImage = UIImageView(image: UIImage(named:"gears"))
        self.view.addSubview(gearsImage)
        
        let line1 = UILabel()
        self.view.addSubview(line1)
        
        let line2 = UILabel()
        self.view.addSubview(line2)
        
        let line3 = UILabel()
        self.view.addSubview(line3)
        
        let line4 = UILabel()
        self.view.addSubview(line4)
        
        let line5 = UILabel()
        self.view.addSubview(line5)
        
        let line6 = UILabel()
        self.view.addSubview(line6)
        
        let line7 = UILabel()
        self.view.addSubview(line7)
        
        
        button.addTarget(self, action: #selector(SportCenterPresentationViewController.backAction), for: .touchUpInside)
        button.setImage(UIImage(named:"left-arrow"), for: .normal)
        button.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(32)
            make.leading.equalToSuperview().offset(Theme.leading)
            make.height.width.equalTo(32)
        }
        
        
        line1.font = UIFont(name:Font.helveticaNeue.rawValue, size:24)
        line1.textColor = UIColor.gray
        line1.text = "LINE1_SPORTCENTER_PRESENTATION".localizable()
        line1.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(button.snp.bottom).offset(24)
            make.height.equalTo(25)
            make.left.equalTo(24)
            make.right.equalTo(0)
        }
        
        line2.font = UIFont(name:Font.helveticaNeue.rawValue, size:24)
        line2.textColor = UIColor.gray
        line2.text = "LINE2_SPORTCENTER_PRESENTATION".localizable()
        line2.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(line1.snp.bottom).offset(24)
            make.height.equalTo(25)
            make.left.equalTo(24)
            make.right.equalTo(0)
        }
        
        line3.font = UIFont(name:Font.helveticaNeue.rawValue, size:24)
        line3.textColor = UIColor.gray
        line3.text = "LINE3_SPORTCENTER_PRESENTATION".localizable()
        line3.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(line2.snp.bottom).offset(24)
            make.height.equalTo(25)
            make.left.equalTo(24)
            make.right.equalTo(0)
        }
        
        line4.font = UIFont(name:Font.helveticaNeue.rawValue, size:UIFont.systemFontSize)
        line4.textColor = UIColor.lightGray
        line4.text = "LINE4_SPORTCENTER_PRESENTATION".localizable()
        line4.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(line3.snp.bottom).offset(24)
            make.height.equalTo(25)
            make.left.equalTo(24)
            make.right.equalTo(0)
        }
        
        line5.font = UIFont(name:Font.helveticaNeue.rawValue, size:UIFont.systemFontSize)
        line5.textColor = UIColor.lightGray
        line5.text = "LINE5_SPORTCENTER_PRESENTATION".localizable()
        line5.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(line4.snp.bottom).offset(24)
            make.height.equalTo(25)
            make.left.equalTo(24)
            make.right.equalTo(0)
        }
        
        line6.font = UIFont(name:Font.helveticaNeue.rawValue, size:UIFont.systemFontSize)
        line6.textColor = UIColor.lightGray
        line6.text = "LINE6_SPORTCENTER_PRESENTATION".localizable()
        line6.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(line5.snp.bottom).offset(24)
            make.height.equalTo(25)
            make.left.equalTo(24)
            make.right.equalTo(0)
        }
        
        line7.font = UIFont(name:Font.helveticaNeue.rawValue, size:UIFont.systemFontSize)
        line7.textColor = UIColor.lightGray
        line7.text = "LINE7_SPORTCENTER_PRESENTATION".localizable()
        line7.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(line6.snp.bottom).offset(24)
            make.height.equalTo(25)
            make.left.equalTo(24)
            make.right.equalTo(0)
        }
        
        
        graphImage.snp.makeConstraints{(make) -> Void in
            make.bottom.equalTo(next.snp.top).offset(-24)
            make.leading.equalTo(48)
            make.height.width.equalTo(40)

        }
        
        
        gearsImage.snp.makeConstraints{(make) -> Void in
            make.bottom.equalTo(next.snp.top).offset(-24)
            make.centerX.equalTo(self.view.snp.centerX).offset(-8)
            make.height.width.equalTo(40)
            
        }
        
        
        moneyImage.snp.makeConstraints{(make) -> Void in
            make.bottom.equalTo(next.snp.top).offset(-24)
            make.trailing.equalTo(-48)
            make.height.width.equalTo(40)
            
        }
        
        next.addTarget(self, action: #selector(SportCenterPresentationViewController.nextAction), for: .touchUpInside)
        next.setImage(UIImage(named:"right-arrow"), for: .normal)
        next.snp.makeConstraints{(make) -> Void in
            make.bottom.equalTo(self.bottomLayoutGuide.snp.top).offset(-32)
            make.trailing.equalTo(Theme.trailing)
            make.height.width.equalTo(40)
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @objc func nextAction() {
        let sportCenter = SportCenterViewController()
        
        self.navigationController?.pushViewController(sportCenter, animated: true)
    }
    
    @objc func backAction() {
        self.navigationController?.popViewController(animated: true)
    }

}
