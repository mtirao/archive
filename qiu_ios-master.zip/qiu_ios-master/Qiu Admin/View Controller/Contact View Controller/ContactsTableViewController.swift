//
//  ContactsTableViewController.swift
//  Qiu
//
//  Created by Marcos Tirao on 21/10/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit
import Contacts

class ContactsTableViewController: UITableViewController {
    
    static let cellReuseIdentifier = "contactsCell"
    
    var turnId : String?
    
    var objects: [(selected: Bool, contact: CNContact)]?
    
    var store: CNContactStore?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let addTurn = UIBarButtonItem(title: "SAVE".localizable(), style: .done, target: self, action: #selector(ContactsTableViewController.payTurn))
        self.navigationController?.navigationBar.tintColor = UIColor.white
        self.navigationItem.rightBarButtonItem = addTurn
        self.navigationItem.title = "FRIENDS".localizable()
        
        self.tableView.register(UINib(nibName: "ContactCell", bundle: nil), forCellReuseIdentifier: ContactsTableViewController.cellReuseIdentifier)
        
        store = CNContactStore()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        retrieveContactsWithStore(store: store!)
    }
    
    // MARK: - Table view data source
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 55
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return objects?.count ?? 0
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: ContactsTableViewController.cellReuseIdentifier, for: indexPath) as! ContactCell
        
        let contact = objects?[indexPath.row]
        let formatter = CNContactFormatter()
        
        cell.title?.text = formatter.string(from: (contact?.1)!)
        cell.selectionStyle = .none
        
        if let phoneNumbers = contact?.1.phoneNumbers {
            for phone in phoneNumbers {
                cell.subtitle?.text = phone.value.stringValue
            }
        }
        
        return cell
    }
    

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let cell = tableView.cellForRow(at: indexPath) {
            if (self.objects?[indexPath.row].0)! {
                self.objects?[indexPath.row].0 = false
                cell.accessoryType = .none
            }else {
                self.objects?[indexPath.row].0 = true
                cell.accessoryType = .checkmark
            }
            
            self.objects?[indexPath.row].0 = true
        }
    }

    
    func retrieveContactsWithStore(store: CNContactStore) {
        do {
            
            let keysToFetch = [CNContactFormatter.descriptorForRequiredKeys(for: .fullName), CNContactPhoneNumbersKey] as [Any]
            let allContainers = try store.containers(matching: nil)
            
            self.objects = [(Bool, CNContact)]()
            
            for container in allContainers {
                let fetchPredicate = CNContact.predicateForContactsInContainer(withIdentifier: container.identifier)
                
                let containerResults = try store.unifiedContacts(matching: fetchPredicate, keysToFetch: keysToFetch as! [CNKeyDescriptor])
                
                for i in containerResults {
                    self.objects?.append((false, i))
                }
            }
            
            DispatchQueue.main.async{
                self.tableView.reloadData()
            }
        } catch {
            print(error)
        }
    }
    
    @objc func payTurn() {        
        
        guard let contacts = self.objects else {
            return
        }
        
        
        let dataProvider = Request()
        let playersViewModel = PlayersViewModel(dataProvider: dataProvider)
        
        
        let request = PlayersRequest()
        request.contacts = contacts
        request.turnId = self.turnId
        
        playersViewModel.addPlayers(param: request, completion: {[unowned self] (response) -> Void in
            
            if response.code == 200 {
                DispatchQueue.main.async {
                    let payment = TurnPaymentViewController()
                    payment.turnId = self.turnId
                    self.navigationController?.pushViewController(payment, animated: true)
                }
            }else {
                let alert = Alert(presenting: self)
                alert.showAlert(title:"TURN_ERROR".localizable(), message: "TURN_ERROR_MESSAGE".localizable())
            }
        
            }, error: { (error) -> Void in
                
                let alert = Alert(presenting: self)
                alert.showAlert(title:"TURN_ERROR".localizable(), message: "TURN_ERROR_MESSAGE".localizable())
        })
        
    }
}

extension ContactsTableViewController {
    
    func contactToJson(contact: CNContact) -> [String : String] {
        var json : [String : String] = [String : String]()
        
        let formatter = CNContactFormatter()
        
        json["name"] = formatter.string(from: contact)
        
        let phoneNumbers = contact.phoneNumbers
        for phone in phoneNumbers {
            json["phone"] = phone.value.stringValue
        }
        
        return json
    }
    
}
