//
//  ContactViewController.swift
//  Qiu
//
//  Created by Marcos Tirao on 15/12/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit
import UIFontComplete

class ContactUsViewController: UIViewController {

    let name = FieldView(frame: CGRect(x:0, y:0, width:0, height:0), type: .text, label: "NAME".localizable())
    let phone = FieldView(frame: CGRect(x:0, y:0, width:0, height:0), type: .number, label: "PHONE".localizable())
    let message = FieldView(frame: CGRect(x:0, y:0, width:0, height:0), type: .multiText, label: "MESSAGE".localizable())
    
    let save = QuiButton()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationController?.navigationBar.tintColor = UIColor.white
        self.view.backgroundColor = UIColor.white
        
        self.name.placeholder = "NAME_PLACEHOLDER".localizable()
        self.phone.placeholder = "PHONE_PLACEHOLDER".localizable()
        self.message.placeholder = "MESSAGE_PLACEHOLDER".localizable()
        
        self.name.labelFont =  UIFont(name:Font.helveticaNeue.rawValue, size:UIFont.systemFontSize )
        self.phone.labelFont =  UIFont(name:Font.helveticaNeue.rawValue, size:UIFont.systemFontSize )
        self.message.labelFont =  UIFont(name:Font.helveticaNeue.rawValue, size:UIFont.systemFontSize )
        
        self.view.addSubview(name)
        name.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(self.topLayoutGuide.snp.bottom).offset(16)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(-10)
            make.height.equalTo(50)
        }
        
        self.view.addSubview(phone)
        phone.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(name.snp.bottom).offset(16)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(-10)
            make.height.equalTo(50)
        }
        
        self.view.addSubview(message)
        message.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(phone.snp.bottom).offset(16)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(-10)
            make.height.equalTo(120)
        }
        
        
        save.layer.cornerRadius = 20
        save.addTarget(self, action: #selector(ContactUsViewController.sendMessage), for: .touchUpInside)
        save.setTitle("SAVE_MESSAGE".localizable(), for: .normal)
        save.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        save.titleLabel?.textColor = UIColor.white
        save.backgroundColor = Theme.qiuRed
        save.alpha = 1.0
        self.view.addSubview(save)
        save.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(message.snp.bottom).offset(30)
            make.trailing.leading.equalToSuperview().inset(UIEdgeInsetsMake(0, 16, 0, 16))
            make.height.equalTo(40)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated
    }
    
    
    
    @objc func sendMessage() {
        
        self.save.showLoading()
        
        let dataProvider = Request()
        let messageViewModel = MessageViewModel(dataProvider: dataProvider)
        messageViewModel.sendMessage(to: .support, title: "question", message: message.data ?? "", type: .query , completion: {
            let alert = Alert(presenting: self)
            self.save.hideLoading()
            alert.showAlert(title: "MESSAGE_TITLE".localizable(), message: "MESSAGE_DESCRIPTION".localizable(), handler: { _ -> Void in
                DispatchQueue.main.async{
                    self.navigationController?.popViewController(animated: true)
                }
            })
        }, error: {(error) -> Void in
            
            self.save.hideLoading()
            let alert = Alert(presenting: self)
            alert.showAlert(title: "MESSAGE_TITLE".localizable(), message: "MESSAGE_DESCRIPTION_ERROR".localizable())
            print("Todo mal")
        })
        
    }


}
