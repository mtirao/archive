//
//  TurnOwnDetailViewController.swift
//  Qiu
//
//  Created by Marcos Tirao on 26/09/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit
import UIFontComplete

class TurnOwnDetailViewController: UIViewController, UICollectionViewDelegate, FieldViewDelegate {
    
    
    let datasource = TimePickerDataSource()
    let scrollView = UIScrollView()
    var court : String = ""
    var sportcenter : String = ""
    var date : Date = Date()
    var time: String?
    var status: TurnResponse.TurnStatus?

    let courtField = FieldView(frame: CGRect(x: 0, y: 0, width: 0, height: 0), type: .text, label: "NAME_OWN_TURN_LABEL".localizable())
    let sportField = FieldView(frame: CGRect(x: 0, y: 0, width: 0, height: 0), type: .text, label: "SPORT".localizable())
    let dateField = FieldView(frame: CGRect(x: 0, y: 0, width: 0, height: 0), type: .text, label: "DATE".localizable())
    let nameField = FieldView(frame: CGRect(x: 0, y: 0, width: 0, height: 0), type: .text, label: "NAME_OWN_TURN".localizable())
    let phoneField = FieldView(frame: CGRect(x: 0, y: 0, width: 0, height: 0), type: .text, label: "PHONE_OWN_TURN_LABEL".localizable())
    let repeated = SwitchView(frame: CGRect(x:0, y:0, width:0, height:0), label: "REPEATED".localizable())
    
    let turn = QuiButton()
    
    var removeTurn : UIBarButtonItem?
    
    var timePickerCollectionView : UICollectionView?
    
    var groundModel : GroundModel?
    var typeModel : TypeModel?
    
    var currentTurn : Turn?
    
    let dataProvider = Request()
    
    var sportVisible : Bool = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = UIColor.white
        self.navigationItem.title = "TURN".localizable()
        
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
        layout.itemSize = CGSize(width: 50, height: 50)
        layout.scrollDirection = .horizontal
        
        //Scrollview
        self.view.addSubview(scrollView)
        scrollView.snp.makeConstraints { make in
            make.right.left.bottom.equalTo(self.view)
            make.top.equalTo(self.view.snp.top)
        }
        
        self.courtField.labelFont =  UIFont(name:Font.helveticaNeueBold.rawValue, size:UIFont.systemFontSize )
        self.sportField.labelFont =  UIFont(name:Font.helveticaNeueBold.rawValue, size:UIFont.systemFontSize )
        self.dateField.labelFont =  UIFont(name:Font.helveticaNeueBold.rawValue, size:UIFont.systemFontSize )
        self.nameField.labelFont =  UIFont(name:Font.helveticaNeueBold.rawValue, size:UIFont.systemFontSize )
        self.phoneField.labelFont =  UIFont(name:Font.helveticaNeueBold.rawValue, size:UIFont.systemFontSize )
        self.repeated.labelFont = UIFont(name:Font.helveticaNeueBold.rawValue, size:UIFont.systemFontSize )
        
        self.courtField.enabled = false
        self.sportField.enabled = false
        self.dateField.enabled = false
        
        self.nameField.placeholder = "NAME_OWN_TURN_PLACEHOLDER".localizable()
        self.phoneField.placeholder = "PHONE_OWN_TURN_PLACEHOLDER".localizable()
        
        self.courtField.delegate = self
        self.sportField.delegate = self
        self.nameField.delegate = self
        self.phoneField.delegate = self
        
        scrollView.addSubview(courtField)
        self.courtField.snp.makeConstraints {(make) -> Void in
            make.top.equalToSuperview().offset(Theme.topMargin)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(Theme.trailing)
            make.height.equalTo(50)
        }
        
        if sportVisible {
            scrollView.addSubview(sportField)
            self.sportField.snp.makeConstraints { (make) -> Void in
                make.top.equalTo(self.courtField.snp.bottom).offset(24)
                make.left.equalTo(Theme.leading)
                make.right.equalTo(self.view.snp.right).offset(Theme.trailing)
                make.height.equalTo(50)
            }
        }
        
        scrollView.addSubview(dateField)
        self.dateField.snp.makeConstraints { (make) -> Void in
            make.top.equalTo(sportVisible ? self.sportField.snp.bottom : self.courtField.snp.bottom).offset(24)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(Theme.trailing)
            make.height.equalTo(50)
        }
        
        scrollView.addSubview(nameField)
        self.nameField.snp.makeConstraints { (make) -> Void in
            make.top.equalTo(self.dateField.snp.bottom).offset(24)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(Theme.trailing)
            make.height.equalTo(50)
        }
        
        scrollView.addSubview(phoneField)
        self.phoneField.snp.makeConstraints { (make) -> Void in
            make.top.equalTo(self.nameField.snp.bottom).offset(24)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(Theme.trailing)
            make.height.equalTo(50)
        }
        
        scrollView.addSubview(repeated)
        self.repeated.snp.makeConstraints { (make) -> Void in
            make.top.equalTo(self.phoneField.snp.bottom).offset(24)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(Theme.trailing)
            make.height.equalTo(50)
        }
        
        timePickerCollectionView = UICollectionView(frame: self.view.frame, collectionViewLayout: layout)
        timePickerCollectionView!.dataSource = self.datasource
        timePickerCollectionView!.delegate = self
        timePickerCollectionView!.register(UINib(nibName: "TimePickerCollectionCell", bundle: nil), forCellWithReuseIdentifier: TimePickerDataSource.cellIdentifier)
        timePickerCollectionView!.backgroundColor = Theme.lightLightGray
        self.view.addSubview(timePickerCollectionView!)
        timePickerCollectionView!.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(repeated.snp.bottom).offset(Theme.topMargin)
            make.leading.equalTo(Theme.leading)
            make.trailing.equalTo(Theme.trailing)
            make.height.equalTo(layout.itemSize.height + layout.sectionInset.bottom + layout.sectionInset.top)
        }
        
        turn.layer.cornerRadius = 20
        turn.addTarget(self, action: #selector(TurnOwnDetailViewController.addTurnAction), for: .touchUpInside)
        turn.changeState = true
        turn.setTitle("ADD_OWN_TURN".localizable(), for: .normal)
        turn.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        turn.titleLabel?.textColor = UIColor.white
        turn.alpha = 1.0
        scrollView.addSubview(turn)
        turn.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(self.timePickerCollectionView!.snp.bottom).offset(40)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(Theme.trailing)
            make.height.equalTo(34)
        }
        
        self.groundModel = GroundModel()
        self.typeModel = TypeModel()
    }
    
    
            
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        
        guard let ground = groundModel else {
            return
        }
        
        guard let type = typeModel else {
            return
        }
        
        ground.reloadData()
        ground.select(withId: self.court)
        
        self.courtField.data = ground.name
        
        type.reloadData()
        type.select(withId: ground.type)
        
        self.dateField.data = formatter.string(from: self.date)
        self.sportField.data = type.name
        
        guard let timeSelected = self.time else {
            return
        }
        
        self.datasource.selectTime(time: timeSelected)
    
        
        if let turn = self.currentTurn {
            self.nameField.data = turn.name
            self.phoneField.data = turn.phone
            self.repeated.state = turn.isstitcky
            
            self.repeated.enabled = false
            
            self.turn.changeState = false
            
            let login = LoginModel()
            login.load()
            
            
            self.nameField.enabled = turn.token == login.token
            self.phoneField.enabled = turn.token == login.token
            self.timePickerCollectionView?.isUserInteractionEnabled = turn.token == login.token
            
            self.turn.addTarget(self, action: #selector(TurnOwnDetailViewController.updateTurnAction), for: .touchUpInside)
            
            if turn.token != login.token {
                self.turn.changeState = turn.status != "new"
                self.turn.setTitle("CONFIRM_TURN".localizable(), for: .normal)
                
            }else {
                self.turn.setTitle("ADD_OWN_TURN".localizable(), for: .normal)
            }
            
            let request = Request()
            let turnViewModel = TurnViewModel(dataProvider: request)
            
            turnViewModel.turn(byId: turn.id!, completion: {response in
                DispatchQueue.main.async {
                    self.courtField.data = (response.ground?.name ?? "")
                    self.sportField.data = "Futbol"
                }
            }, error: {error in
                
                
            })
            
        }else {
            
            self.turn.changeState = false
            
            validateFields()
        }
        
        
        //Button close sign
        if self.navigationController == nil {
            let closeButton = UIButton()
            closeButton.setImage(UIImage(named: "close"), for: .normal)
            closeButton.addTarget(self, action: #selector(TurnOwnDetailViewController.closeAction), for: .touchUpInside)
            self.view.addSubview(closeButton)
            closeButton.snp.makeConstraints{(make) -> Void in
                make.top.equalToSuperview().offset(Theme.topMargin)
                make.leading.equalTo(Theme.leading)
                make.height.width.equalTo(19)
            }
            
            if(currentTurn?.status != "new") {
                let removeButton = UIButton()
                removeButton.setImage(UIImage(named: "trash"), for: .normal)
                removeButton.addTarget(self, action: #selector(TurnOwnDetailViewController.removeTurnAction), for: .touchUpInside)
                self.view.addSubview(removeButton)
                removeButton.snp.makeConstraints{(make) -> Void in
                    make.top.equalToSuperview().offset(Theme.topMargin)
                    make.trailing.equalTo(Theme.trailing)
                    make.height.width.equalTo(19)
                }
            }
            
            courtField.snp.updateConstraints{(make) -> Void in
                make.top.equalToSuperview().offset(2*Theme.topMargin + 19)
            }
        }else {
            if(currentTurn?.status == "new") {
                removeTurn = UIBarButtonItem(title: "CONFIRM".localizable(), style: .done, target: self, action: #selector(TurnOwnDetailViewController.confirmTurnAction))
            }else {
                removeTurn = UIBarButtonItem(barButtonSystemItem: .trash, target: self, action: #selector(TurnOwnDetailViewController.removeTurnAction))
            }
            self.navigationController?.navigationBar.tintColor = UIColor.white
            self.navigationItem.rightBarButtonItem = removeTurn!
            removeTurn?.isEnabled = self.currentTurn != nil
        }
        
    }
    
    override var prefersStatusBarHidden: Bool {
        return self.navigationController == nil
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        let contentHeight = self.turn.frame.origin.y + self.turn.frame.size.height + CGFloat(Theme.topMargin)
        self.scrollView.contentSize = CGSize(width: self.view.frame.size.width, height: contentHeight)
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        self.currentTurn = nil
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textDidChange(fieldView: FieldView, text: String) {
        validateFields()
    }
    
    func didSelectFirstResponder(frame: CGRect) {
        
    }
    
    @objc func closeAction() {
        self.dismiss(animated: true, completion: nil)
    }
    
    @objc func confirmTurnAction()  {
        
        let alert = UIAlertController(title: "CONFIRM_TURN".localizable(), message: "CONFIRM_TURN_MESSAGE".localizable(), preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .destructive, handler: {  [unowned self ] action -> Void   in
            
            let turnViewModel = TurnViewModel(dataProvider:self.dataProvider)
            let request = TurnRequest()
            request.status = TurnResponse.TurnStatus.confirmed
            
            turnViewModel.updateTurn(turnId:self.currentTurn?.id ?? "", param:request, completion: { [unowned self] (response) -> Void in
                
                DispatchQueue.main.async {
                    if let navController = self.navigationController {
                        navController.popViewController(animated: true)
                    }else {
                        self.dismiss(animated: true, completion: nil)
                    }
                    
                }
                }, error: { _ in
                    let alert = Alert(presenting: self)
                    alert.showAlert(title: "ERROR_OWN_TURN".localizable(), message: "DELETE_TURN_ERROR_MESSAGE".localizable())
            })
            
        })
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: nil)
        
        alert.addAction(okAction)
        alert.addAction(cancelAction)
        
        DispatchQueue.main.async {
            self.present(alert, animated: true, completion: nil)
        }
        
    }
    
    @objc func removeTurnAction()  {
        
        let alert = UIAlertController(title: "DELETE_TURN_ALERT".localizable(), message: "DELETE_TURN_ALERT_MESSAGE".localizable(), preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .destructive, handler: {  [unowned self ] action -> Void   in
            
            let turnViewModel = TurnViewModel(dataProvider:self.dataProvider)
            turnViewModel.removeTurn(turnId:self.currentTurn?.id ?? "", completion: { [unowned self, weak currentTurn = self.currentTurn] (response) -> Void in
                
                if let turn = currentTurn {
                    let turnModel = TurnModel()
                    turnModel.delete(withId: turn.id!)
                }
                
                DispatchQueue.main.async {
                    if let navController = self.navigationController {
                        navController.popViewController(animated: true)
                    }else {
                        self.dismiss(animated: true, completion: nil)
                    }
                    
                }
            }, error: { _ in
                let alert = Alert(presenting: self)
                alert.showAlert(title: "ERROR_OWN_TURN".localizable(), message: "DELETE_TURN_ERROR_MESSAGE".localizable())
            })
 
        })
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: nil)
        
        alert.addAction(okAction)
        alert.addAction(cancelAction)
        
        DispatchQueue.main.async {
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    @objc func updateTurnAction() {
        turn.showLoading()
        
        let turnViewModel = TurnViewModel(dataProvider:dataProvider)
        let request = TurnRequest()
        request.status = TurnResponse.TurnStatus.paid
        
        turnViewModel.updateTurn(turnId: self.currentTurn?.id ?? "", param: request, completion: {(response) -> Void in
            
            response.save()
            DispatchQueue.main.async {
                self.turn.hideLoading()
                self.dismiss(animated: true, completion: nil)
            }
        }, error: {(error) -> Void in
            
            let alert = Alert(presenting: self)
            alert.showAlert(title:"TURN_ERROR".localizable(), message: "TURN_ERROR_MESSAGE".localizable())
            
            DispatchQueue.main.async {
                self.turn.hideLoading()
            }
        })
    }
    
    @objc func addTurnAction() {
        
        turn.showLoading()
        
        if !Preferences.isLogged {
            let alert = Alert(presenting: self)
            alert.showAlert(title:"Error", message: "You must be logged in")
            turn.hideLoading()
            return
        }
        
        guard let name = self.nameField.data else{
            self.nameField.info = "NAME_FIELD_REQUIRED".localizable()
            turn.hideLoading()
            return
        }
        
        let (year, month, day) = CalendarUtil.componentsForDate(forDate: self.date)
        let (start, end) = self.datasource.timeSelection()
        
        var dateFrom : Date
        
        if (start - ceil(start)) != 0 {
            dateFrom = CalendarUtil.dateFromComponents(day: day, month: month, year: year, hour: Int(start), minute: 30, second: 0)
            //from = Theme.DateToIsoDate(isoDate: dateFrom)
        }else {
            dateFrom = CalendarUtil.dateFromComponents(day: day, month: month, year: year, hour: Int(start), minute: 0, second: 0)
            //from = Theme.DateToIsoDate(isoDate: dateFrom)
        }
        
        let request = TurnRequest()
        request.sportcenter = self.sportcenter
        request.court = self.court
        request.name = name
        request.phone = phoneField.data ?? ""
        request.date = Theme.turnDateToInt(date: dateFrom)
        request.sticky = repeated.state
        request.status = TurnResponse.TurnStatus.confirmed
        request.time = Float(start)
        
        let request1 = TurnRequest()
        request1.sportcenter = self.sportcenter
        request1.court = self.court
        request1.name = name
        request1.phone = phoneField.data ?? ""
        request1.date = Theme.turnDateToInt(date: dateFrom)
        request1.sticky = repeated.state
        request1.status = TurnResponse.TurnStatus.confirmed
        request1.time = Float(start + (end - start) / 2)
        
        let turnViewModel = TurnViewModel(dataProvider:dataProvider)
        
        let requests : [TurnRequest] = [request, request1]
        
        
        turnViewModel.addTurn(param: requests, completion: {(response) -> Void in
            
            DispatchQueue.main.async {
                self.turn.hideLoading()
                self.navigationController?.popViewController(animated: true)
            }
        }, error: {(error) -> Void in
            
            DispatchQueue.main.async {
                self.turn.hideLoading()
            }
            
            let alert = Alert(presenting: self)
            
            if request.sticky! {
                alert.showAlert(title:"TURN_ERROR".localizable(), message: "TURN_ERROR_MESSAGE_1".localizable(), handler:{ _ in
                    DispatchQueue.main.async {
                        self.turn.hideLoading()
                        self.navigationController?.popViewController(animated: true)
                    }
                })
            }else {
                alert.showAlert(title:"TURN_ERROR".localizable(), message: "TURN_ERROR_MESSAGE".localizable())
            }
                
            
        })
    }
    
    func validateFields() {
        
        let (start, end) = self.datasource.selectionRange
        let phone = self.phoneField.data?.count ?? 0
        let name = self.nameField.data?.count ?? 0
        
        if start != end && phone > 0 && name > 0 {
            self.turn.changeState = true
        }
        
    }

}


//MARK: - DataSource Function TimePicker
extension TurnOwnDetailViewController {
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if self.currentTurn != nil {
            return
        }
        
        self.datasource.selectTime(at: indexPath)
        
        self.timePickerCollectionView?.reloadData()
        
        if let cell = collectionView.cellForItem(at: indexPath) as? TimePickerCollectionCell {
            cell.selectedState = true
        }
        
        let (start, end) = self.datasource.selectionRange
        
        if start != end {
            self.turn.changeState = true
        }
    }
    
}
