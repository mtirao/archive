//
//  TurnOwnViewController.swift
//  Qiu
//
//  Created by Marcos Tirao on 9/13/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class TurnOwnViewController: UIViewController, UICollectionViewDelegate, UITableViewDelegate, TurnCellDelegate{

    let scrollView = UIScrollView()
    
    let dataSource = CourtCollectionModel()
    let dataSourceDate = DatePickerDataSource()
    let dataSourceTurn = TurnTableModel()
    
    var collectionView : UICollectionView?
    var collectionViewDate : UICollectionView?
    var tableView : UITableView?
    
    var courtField : String?
    var dateField : Date?
    
    var sportcenter : SportCenterModel = SportCenterModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.navigationBar.barTintColor = Theme.navigationBackgroundColor
        self.title = "TURN".localizable()
        
        let addTurn = UIBarButtonItem(title: "WANT_PLAY".localizable(), style: .done, target: self, action: #selector(TurnOwnViewController.addTurn))
        self.navigationController?.navigationBar.tintColor = UIColor.white
        self.navigationItem.rightBarButtonItem = addTurn
        
        self.dataSourceTurn.turnTableDelegate = self
        
        //Scrollview
        self.view.addSubview(scrollView)
        scrollView.snp.makeConstraints { make in
            make.right.left.bottom.equalTo(self.view)
            make.top.equalTo(self.view.snp.top)
        }
        
        //Colllection view for court
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
        layout.itemSize = CGSize(width: 110, height: 36)
        layout.scrollDirection = .horizontal
        
        collectionView = UICollectionView(frame: self.view.frame, collectionViewLayout: layout)
        collectionView!.dataSource = self.dataSource
        collectionView!.tag = 0
        collectionView!.delegate = self
        collectionView!.register(UINib(nibName: "CourtCollectionCell", bundle: nil), forCellWithReuseIdentifier: CourtCollectionModel.cellIdentifier)
        collectionView!.backgroundColor = Theme.lightLightGray
        scrollView.addSubview(collectionView!)
        collectionView!.snp.makeConstraints{(make) -> Void in
            
            make.top.equalTo(self.topLayoutGuide.snp.bottom).offset(Theme.topMargin)
            make.left.equalTo(1)
            make.right.equalTo(self.view.snp.right).offset(-1)
            make.height.equalTo(layout.itemSize.height + layout.sectionInset.bottom + layout.sectionInset.top)
        }
        
        //Collection view to selected date
        let layoutDate: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layoutDate.sectionInset = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
        layoutDate.itemSize = CGSize(width: 50, height: 50)
        layoutDate.scrollDirection = .horizontal
        
        collectionViewDate = UICollectionView(frame: self.view.frame, collectionViewLayout: layoutDate)
        collectionViewDate!.dataSource = self.dataSourceDate
        collectionViewDate!.delegate = self
        collectionViewDate!.tag = 1
        collectionViewDate!.register(UINib(nibName: "DatePickerCollectionCell", bundle: nil), forCellWithReuseIdentifier: DatePickerDataSource.cellIdentifier)
        collectionViewDate!.backgroundColor = Theme.lightLightGray
        scrollView.addSubview(collectionViewDate!)
        collectionViewDate!.snp.makeConstraints{(make) -> Void in
            
            make.top.equalTo(self.collectionView!.snp.bottom).offset(Theme.topMargin)
            make.left.equalTo(1)
            make.right.equalTo(self.view.snp.right).offset(-1)
            make.height.equalTo(layoutDate.itemSize.height + layoutDate.sectionInset.bottom + layoutDate.sectionInset.top)
        }
    
        tableView = UITableView(frame: CGRect(x:0, y:0, width:0, height:0), style: .plain)
        tableView!.register(UINib(nibName: "TurnTableCell", bundle: nil), forCellReuseIdentifier: TurnTableModel.cellIdentifier)
        tableView!.dataSource = self.dataSourceTurn
        tableView!.delegate = self
        scrollView.addSubview(tableView!)
        tableView!.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(self.collectionViewDate!.snp.bottom).offset(Theme.topMargin)
            make.left.equalTo(1)
            make.right.equalTo(self.view.snp.right).offset(-1)
            make.bottom.equalTo(self.bottomLayoutGuide.snp.top)
        }
        
        sportcenter.reloadData()
        
        let dataProvider = Request()
        let groundViewModel = GroundViewModel(dataProvider:dataProvider)
        
        groundViewModel.listGround(sportcenter: sportcenter.id, completion: {(response) -> Void in
            DispatchQueue.main.async {
                
                response.save()
                
                self.dataSource.loadData()
                self.collectionView?.reloadData()
            }
            
        }, error: {(error) -> Void in
            print(error?.localizedDescription ?? "Error")
        })
        
        
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let request = Request()
        let turnModel = TurnViewModel(dataProvider: request)
        self.dataSourceTurn.startHour = Int(floor(sportcenter.openAt))
        
        turnModel.turn(completion: {
            
            DispatchQueue.main.async {
                self.dataSourceTurn.loadData()
                self.dataSource.loadData()
                self.collectionView?.reloadData()
                self.tableView?.reloadData()
            }
            
        }, error: {error in })
        
        
        
    }
        
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @objc func addTurn() {
        let turn = TurnViewController()
        self.navigationController?.pushViewController(turn, animated: true)
    }
    
}

//MARK: - Collection View delegate
extension TurnOwnViewController {
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if collectionView.tag == 0 {
            courtField = self.dataSource.select(itemAt: indexPath, collectionView: collectionView)
        }else {
            dateField = self.dataSourceDate.select(at: indexPath, collectionView: collectionView)
        }
        
        guard let date = dateField else {
            return
        }
        
        guard let court = courtField else {
            return
        }
        
        self.dataSourceTurn.selectedDate = date
        self.dataSourceTurn.selectedGround =  court
        self.dataSourceTurn.sportCenter = self.sportcenter
        self.dataSourceTurn.loadData()
        self.tableView?.reloadData()
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        
        if collectionView.tag == 0 {
            self.dataSource.deselect(itemAt: indexPath, collectionView: collectionView)
            courtField = nil
        }else {
            self.dataSourceDate.deselect(itemAt: indexPath, collectionView: collectionView)
        }
    }
    
}


//MARK: - Table view delegate
extension TurnOwnViewController {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 74.5
    }
    
    
    func didSelectFirstHalf(at hour: String) {
        rowSelection(at: hour)
    }
    
    func didSelectSecondHalf(at hour: String) {
        rowSelection(at: hour)
    }
    
    func rowSelection(at hour: String) {
        if let date = self.dateField, let court = self.courtField {
            let turnDetail = TurnOwnDetailViewController()
            turnDetail.date = date
            turnDetail.sportcenter = self.sportcenter.id
            turnDetail.court = court
            turnDetail.time = hour
            turnDetail.currentTurn = self.dataSourceTurn.fetch(at: hour)
            turnDetail.status = TurnResponse.TurnStatus.confirmed
            self.navigationController?.pushViewController(turnDetail, animated: true)
        }else {
            let alert = Alert(presenting: self)
            alert.showAlert(title: "ERROR_OWN_TURN".localizable(), message: "ERROR_OWN_TURN_MESSAGE".localizable())
        }
    }
}
