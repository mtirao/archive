//
//  CourtViewController.swift
//  Qiu
//
//  Created by Marcos Tirao on 7/26/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit
import MapKit
import CoreData
import UIFontComplete
import DateTimePicker
import Contacts

let regionRadius: CLLocationDistance = 1000

class TurnViewController: UIViewController, UICollectionViewDelegate, MKMapViewDelegate, LoginControllerDelegate {
    
    let mapView = MKMapView()
    
    let plusButton = UIButton()
    let dateField = UILabel()
    
    let dataSource = TypeCollectionModel()
    var collectionView : UICollectionView?
    
    var typeField: String?
    var sportcenterField: String?
    
    var currentTurn: Turn?
    
    var loginViewController : LoginViewController?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.backgroundColor = Theme.lightGray
        self.title = "TURN".localizable()
        
        let payTurn = UIBarButtonItem(title: "SAVE".localizable(), style: .done, target: self, action: #selector(TurnViewController.payTurnAction))
        self.navigationController?.navigationBar.tintColor = UIColor.white
        self.navigationItem.rightBarButtonItem = payTurn
        
        let sportLabel = UILabel()
        sportLabel.text = "SPORTS".localizable()
        sportLabel.font = UIFont(name:Font.helveticaNeue.rawValue, size: UIFont.systemFontSize )

        sportLabel.textColor = UIColor.gray
        self.view.addSubview(sportLabel)
        sportLabel.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(self.topLayoutGuide.snp.bottom).offset(Theme.topMargin)
            make.leading.equalTo(Theme.leading)
            make.height.equalTo(20)
        }
        
        if self.navigationController == nil {
            let closeButton = UIButton()
            
            closeButton.setImage(UIImage(named: "close"), for: .normal)
            closeButton.addTarget(self, action: #selector(TurnViewController.closeAction), for: .touchUpInside)
            self.view.addSubview(closeButton)
            closeButton.snp.makeConstraints{(make) -> Void in
                make.centerY.equalTo(sportLabel.snp.centerY)
                make.trailing.equalTo(Theme.trailing)
                make.height.width.equalTo(32)
            }
        }
       
        
        //Colllection view for Sports
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
        layout.itemSize = CGSize(width: 90, height: 90)
        layout.scrollDirection = .horizontal

        collectionView = UICollectionView(frame: self.view.frame, collectionViewLayout: layout)
        collectionView!.dataSource = self.dataSource
        collectionView!.delegate = self
        collectionView!.register(UINib(nibName: "SportCollectionCell", bundle: nil), forCellWithReuseIdentifier: "sportCell")
        collectionView!.backgroundColor = UIColor.white
        self.view.addSubview(collectionView!)
        collectionView!.snp.makeConstraints{(make) -> Void in
        
            make.top.equalTo(sportLabel.snp.bottom).offset(Theme.topMargin)
            make.leading.equalTo(Theme.leading)
            make.trailing.equalTo(Theme.trailing)
            make.height.equalTo(layout.itemSize.height + layout.sectionInset.bottom + layout.sectionInset.top)
        }
        
        
        //Button plus-minus sign
        plusButton.setImage(UIImage(named: "open-calendar"), for: .normal)
        plusButton.addTarget(self, action: #selector(TurnViewController.openAction), for: .touchUpInside)
        self.view.addSubview(plusButton)
        plusButton.snp.makeConstraints{(make) -> Void in
            make.top.equalTo((collectionView?.snp.bottom)!).offset(Theme.topMargin)
            make.leading.equalTo(Theme.leading)
            make.height.width.equalTo(19)
        }
        
        let label = UILabel()
        label.text = "DATE_TIME".localizable()
        label.font = UIFont(name:Font.helveticaNeue.rawValue, size:UIFont.systemFontSize )
        label.textColor = UIColor.gray
        self.view.addSubview(label)
        label.snp.makeConstraints{(make) -> Void in

            make.centerY.equalTo(plusButton.snp.centerY)
            make.left.equalTo(plusButton.snp.right).offset(5)
            make.width.equalTo(100)
            make.height.equalTo(20)
        }
        
        
        dateField.font = UIFont(name:Font.helveticaNeue.rawValue, size:UIFont.systemFontSize )
        dateField.textAlignment = .right
        dateField.textColor = UIColor.gray
        self.view.addSubview(dateField)
        dateField.snp.makeConstraints{(make) -> Void in
            make.centerY.equalTo(plusButton.snp.centerY)
            make.trailing.equalTo(Theme.trailing)
            make.width.equalTo(200)
            make.height.equalTo(20)
        }
        
        self.dateField.text = Theme.dateShortFormat(date: CalendarUtil.roundToNearestHour(from: Date()))
        
        
        //let tapGesture = UITapGestureRecognizer(target: self, action: #selector(MainEventViewController.tapOnMap(gesture:)))
        //mapView?.addGestureRecognizer(tapGesture)
        //mapView = MKMapView()
        mapView.showsUserLocation = true
        mapView.isScrollEnabled = true
        mapView.isZoomEnabled = true
        mapView.delegate = self
        
        self.view.addSubview(mapView)
        mapView.snp.makeConstraints{(make) -> Void in
            make.bottom.equalTo(self.view.snp.bottom)
            make.top.equalTo(dateField.snp.bottom).offset(Theme.topMargin)
            make.leading.trailing.equalTo(self.view)
        }
        
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.navigationBar.barTintColor = Theme.navigationBackgroundColor
    
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        super.viewDidAppear(animated)
        
        Tracking.userEnterView(viewName: .turnView)
        
        let location = CLLocation(latitude: Preferences.latitude ?? 0.0, longitude: Preferences.longitude ?? 0.0)
        centerMapOnLocation(location: location)
        
        self.dataSource.loadData()
        self.collectionView?.reloadData()
        
        NotificationController.notificationObserver(observer: self, selector: #selector(TurnViewController.reloadCollection), name: Notes.coreDataTypeLoaded.notification)
        
        let dataProvider = Request()
        let sportcenter = SportcenterViewModel(dataProvider: dataProvider)
        
        if let turn = self.currentTurn {
            
            //MARK: - TODO
            self.dateField.text = "" //Theme.dateShortFormat(date: CalendarUtil.roundToNearestHour(from: turn.time! as Date))
            
            let groundModel = GroundViewModel(dataProvider: dataProvider)
            
            groundModel.listGround(sportcenter: turn.sportcenter ?? "", completion: {[unowned self] (grounds) -> Void in
                
                for ground in grounds.grounds {
                    let turnGroundId = turn.ground!
                    let groundId = ground._id
                    if turnGroundId == groundId {
                        DispatchQueue.main.async { [unowned self] in
                            self.dataSource.select(itemWithId: ground.type, collectionView: self.collectionView!)
                        }
                    }
                }
                
                sportcenter.sportcenter(byId: turn.sportcenter ?? "", completion: {(sportcenter) -> Void in
                    DispatchQueue.main.async { [unowned self] in
                        self.addSportcenterOnMap(sportcenter: sportcenter)
                    }
                    
                }, error: {(error) -> Void in
                    let alert = Alert(presenting: self)
                    alert.showAlert(title:"NETWORK_ERROR".localizable(), message: "NETWORK_ERROR_MESSAGE".localizable())
                })
                
                }, error: { (error) -> Void in
                    let alert = Alert(presenting: self)
                    alert.showAlert(title:"NETWORK_ERROR".localizable(), message: "NETWORK_ERROR_MESSAGE".localizable())
            })
            
            
        }else {
            sportcenter.listSportCenter( completion: {(list) -> Void in
                
                DispatchQueue.main.async { [unowned self] in
                    for sportcenter in list.sportCenters {
                        self.addSportcenterOnMap(sportcenter: sportcenter)
                    }
                }
                
            }, error: {(error) -> Void in
                let alert = Alert(presenting: self)
                alert.showAlert(title:"NETWORK_ERROR".localizable(), message: "NETWORK_ERROR_MESSAGE".localizable())
            })
        }
        
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        Tracking.userExitView(viewName: .turnView)
        self.currentTurn = nil

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    override var prefersStatusBarHidden: Bool {
        return self.navigationController == nil
    }
    
    //MARK:- Delegate methods
    @objc func closeAction() {
        self.dismiss(animated: true, completion: nil)
    }
    
    @objc func openAction() {
        
        if self.currentTurn != nil {
            return
        }
        
        let picker = DateTimePicker()
        picker.selectedDate = Theme.dateShortFormat(string: dateField.text!)
        picker.highlightColor = Theme.qiuGreen
        picker.isDatePickerOnly = false // to hide time and show only date picker
        picker.completionHandler = { date in
            self.dateField.text = Theme.dateShortFormat(date: CalendarUtil.roundToNearestHour(from: date))
        }
        picker.show()
        
        
    }
    
    @objc func reloadCollection() {
        
        DispatchQueue.main.async {
            self.collectionView?.reloadData()
        }
        
    }
    
    
    @objc func payTurnAction() {
        
        //turn.showLoading()
        
        if !Preferences.isLogged {
            
            loginViewController = LoginViewController()
            loginViewController!.delegate = self
            self.present(loginViewController!, animated: true, completion: nil)
            
            return
        }
        
        payTurnActionAfterLogin()
        
    }
    
    func payTurnActionAfterLogin() {
        
        guard let type = self.typeField else {
            let alert = Alert(presenting: self)
            alert.showAlert(title:"ERROR_TURN".localizable(), message: "TYPE_REQUIRED_MESSAGE".localizable())
            return
        }
        
        guard let sportcenter = self.sportcenterField else {
            let alert = Alert(presenting: self)
            alert.showAlert(title:"ERROR_TURN".localizable(), message: "SPORTCENTER_REQUIRED_MESSAGE".localizable())
            return
        }
        
        let profile = ProfileModel()
        
        
        let name = profile.name
        let phone = profile.phone
        let start = Theme.dateShortFormat(string: self.dateField.text!)
        let (fromHour, fromMin) = CalendarUtil.componentsForDate(forDate: start)
    
        
        let dataProvider = Request()
        let turnViewModel = TurnViewModel(dataProvider: dataProvider)
        
        
        var time : Float = 0
        if fromMin == 30 {
            time = Float(fromHour) + 0.5
        }else {
            time = Float(fromHour)
        }
        
        let request = TurnRequest()
        request.sportcenter = sportcenter
        request.type = type
        request.name = name
        request.phone = phone
        request.time = time
        request.date = Theme.turnDateToInt(date: start)
        request.sticky = false
        request.status = TurnResponse.TurnStatus.new
        
        
        let request1 = TurnRequest()
        request1.sportcenter = sportcenter
        request1.type = type
        request1.name = name
        request1.phone = phone
        request1.time = time +  0.5
        request1.date = Theme.turnDateToInt(date: start)
        request1.sticky = false
        request1.status = TurnResponse.TurnStatus.new
        
        let requests : [TurnRequest] = [request, request1]
        
        turnViewModel.addTurn(param: requests, completion: {[unowned self] (response) -> Void in
            
            DispatchQueue.main.async {
                self.payAndConfirm(turnId: response)
            }
            
            }, error: {(error) -> Void in
                
                let alert = Alert(presenting: self)
                alert.showAlert(title:"TURN_ERROR".localizable(), message: "TURN_ERROR_MESSAGE".localizable())
        })
        
    }
    
    func payAndConfirm(turnId: String) {
        
        DispatchQueue.main.async {
            let payment = TurnPaymentViewController()
            payment.turnId = turnId
            self.navigationController?.pushViewController(payment, animated: true)
        }
    }
    
    func pushContactViewController(turnId:String) {
        let contactsViewController = ContactsTableViewController(style: .plain)
        contactsViewController.turnId = turnId
        self.navigationController?.pushViewController(contactsViewController, animated: true)
    }
}

//MARK: - MapKit
extension TurnViewController {
    
    func centerMapOnLocation(location: CLLocation) {
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate,
                                                                  regionRadius * 2.0, regionRadius * 2.0)
        mapView.setRegion(coordinateRegion, animated: true)
    }
    
    func addSportcenterOnMap(sportcenter: SportCenterResponse) {
        
        let latitud = sportcenter.latitude
        let longitude = sportcenter.longitude
        
        let annotation = SportcenterAnnotation()
        annotation.title = sportcenter.name
        annotation.subtitle = sportcenter.address
        annotation.sportcenter = sportcenter._id
        annotation.coordinate = CLLocationCoordinate2D(latitude: latitud, longitude: longitude)
        annotation.status = sportcenter.status
        
        let pinAnnotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: "pin")
        mapView.addAnnotation(pinAnnotationView.annotation!)
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        if(annotation .isKind(of: MKPointAnnotation.self)) {
            
            if let annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: "pin") {
                annotationView.annotation = annotation
                return createPinView(annotationView:annotationView)
            }else {
                let annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier:"pin")
                return createPinView(annotationView:annotationView)
            }
            
            
        }
        
        return nil
    }
    
    func createPinView(annotationView: MKAnnotationView) -> MKAnnotationView {
        
        annotationView.canShowCallout = true
        annotationView.isEnabled = true
        if let annotation = annotationView.annotation as? SportcenterAnnotation {
            if annotation.status == "confirmed" {
                annotationView.image = UIImage(named: "green-pin")
            }else {
                annotationView.image = UIImage(named: "red-pin")
            }
        }else {
            annotationView.image = UIImage(named: "red-pin")
        }
        
        
        return annotationView;
        
        
    }
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        let tapGesture = UITapGestureRecognizer(target:self,  action:#selector(calloutTapped(sender:)))
    
        if let annotation = view.annotation as? SportcenterAnnotation {
            if annotation.status == "confirmed" {
                view.addGestureRecognizer(tapGesture)
            }
        }
        
    }
    
    func mapView(_ mapView: MKMapView, didDeselect view: MKAnnotationView) {
        
        guard let gesture = view.gestureRecognizers else {
            return
        }
        
        view.removeGestureRecognizer(gesture.first!)
        let pin = view
        if let annotation = pin.annotation as? SportcenterAnnotation {
            if annotation.status == "confirmed" {
                pin.image = UIImage(named: "green-pin")
            }else {
                pin.image = UIImage(named: "red-pin")
            }
        }else {
            pin.image = UIImage(named: "red-pin")
        }
        
        self.sportcenterField = nil
    }
    
    @objc func calloutTapped(sender:UITapGestureRecognizer) {
        let view = sender.view as! MKAnnotationView
    
        view.image = UIImage(named: "selected-pin")
        
        if let annotation = view.annotation as? SportcenterAnnotation {
           self.sportcenterField = annotation.sportcenter
        }
    }

}

//MARK: - Sport selection type
extension TurnViewController {
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if self.currentTurn != nil {
            return
        }
        
        typeField = self.dataSource.select(itemAt: indexPath, collectionView: collectionView)
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        
        if self.currentTurn != nil {
            return
        }
        
        self.dataSource.deselect(itemAt: indexPath, collectionView: collectionView)
        
        typeField = nil
    }
}

extension TurnViewController {
    
    func didFinishedLogin() {
        DispatchQueue.main.async {
            self.loginViewController?.dismiss(animated: true, completion: nil)
            self.payTurnActionAfterLogin()
        }
        
    }
    
    func didFinshedLoginWithError() {
        
        if let presentingViewController = self.loginViewController {
            let alert = Alert(presenting: presentingViewController)
            alert.showAlert(title:"ERROR_TURN".localizable(), message: "AUTHORIZE_ERROR".localizable())
        }
    }
    
}
