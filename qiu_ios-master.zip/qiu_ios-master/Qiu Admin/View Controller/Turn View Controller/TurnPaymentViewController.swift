//
//  TurnPaymentViewController.swift
//  Qiu
//
//  Created by Marcos Tirao on 27/10/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit
import UIFontComplete
import FBSDKCoreKit
import FBSDKLoginKit
import AccountKit

class TurnPaymentViewController: UIViewController, AKFViewControllerDelegate {
    
    let radioGroup = RadioGroup(frame: CGRect(x:0, y:0, width:0, height:0), buttonLabels: ["CASH".localizable()])
    
    let sportcenterLabel = UILabel()
    let sportcenterAddressLabel = UILabel()
    
    let feeLabel = UILabel()
    let dateLabel = UILabel()
    let info = UILabel()
    
    let confirm = QuiButton()
    
    var turnId : String?
    
    var accountKit : AKFAccountKit?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "CONFIRM".localizable()
        
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(title: "", style: . plain, target: self, action: #selector(SportCenterViewController.backAction))
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(SportCenterViewController.backAction))
        
        self.view.backgroundColor = UIColor.white
        
        self.sportcenterLabel.text = "Loading..."
        self.sportcenterLabel.font = UIFont(name:Font.helveticaNeueBold.rawValue, size: 19 )
        self.view.addSubview(self.sportcenterLabel)
        self.sportcenterLabel.snp.makeConstraints{(make) in
            make.height.equalTo(30)
            make.leading.equalTo(Theme.leading)
            make.top.equalTo(Theme.topMargin)
        }
        
        self.sportcenterAddressLabel.text = "Loading..."
        self.sportcenterAddressLabel.font = UIFont(name:Font.helveticaNeue.rawValue, size: UIFont.systemFontSize )
        self.view.addSubview(self.sportcenterAddressLabel)
        self.sportcenterAddressLabel.snp.makeConstraints{(make) in
            make.height.equalTo(25)
            make.leading.equalTo(Theme.leading)
            make.top.equalTo(sportcenterLabel.snp.bottom)
        }
        
        let line = UIView()
        line.backgroundColor = UIColor.lightGray
        self.view.addSubview(line)
        line.snp.makeConstraints{(make) in
            make.height.equalTo(1)
            make.leading.equalTo(Theme.leading)
            make.trailing.equalTo(0)
            make.top.equalTo(self.sportcenterAddressLabel.snp.bottom).offset(5)
        }
        
        self.dateLabel.text = "Loading..."
        self.dateLabel.font = UIFont(name:Font.helveticaNeue.rawValue, size: 17 )
        self.view.addSubview(self.dateLabel)
        self.dateLabel.snp.makeConstraints{(make) in
            make.height.equalTo(30)
            make.leading.equalTo(Theme.leading)
            make.top.equalTo(line.snp.bottom).offset(10)
        }
        
        self.feeLabel.text = "Fee: $300"
        self.feeLabel.font = UIFont(name:Font.helveticaNeue.rawValue, size: 17 )
        self.view.addSubview(self.feeLabel)
        self.feeLabel.snp.makeConstraints{(make) in
            make.height.equalTo(30)
            make.leading.equalTo(Theme.leading)
            make.top.equalTo(dateLabel.snp.bottom).offset(10)
        }
        
        let line1 = UIView()
        line1.backgroundColor = UIColor.lightGray
        self.view.addSubview(line1)
        line1.snp.makeConstraints{(make) in
            make.height.equalTo(1)
            make.leading.equalTo(Theme.leading)
            make.trailing.equalTo(0)
            make.top.equalTo(self.feeLabel.snp.bottom).offset(5)
        }
        
        self.view.addSubview(radioGroup)
        radioGroup.isEnable = false
        self.radioGroup.snp.makeConstraints{(make) in
            make.height.equalTo(30)
            make.leading.equalTo(Theme.leading)
            make.top.equalTo(line1.snp.bottom).offset(10)
        }
        
        self.info.text = "The fee must be payed at sportcenter"
        self.info.font = UIFont(name:Font.helveticaNeue.rawValue, size: 12 )
        self.info.textColor = UIColor.red
        self.view.addSubview(self.info)
        self.info.snp.makeConstraints{(make) in
            make.height.equalTo(20)
            make.leading.equalTo(Theme.leading)
            make.top.equalTo(radioGroup.snp.bottom)
        }
        
        confirm.layer.cornerRadius = 20
        confirm.addTarget(self, action: #selector(TurnPaymentViewController.addTurnAction), for: .touchUpInside)
        confirm.changeState = true
        confirm.setTitle("ADD_OWN_TURN".localizable(), for: .normal)
        confirm.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        confirm.titleLabel?.textColor = UIColor.white
        confirm.alpha = 1.0
        self.view.addSubview(confirm)
        confirm.snp.makeConstraints{(make) -> Void in
            make.bottom.equalTo(self.view.snp.bottom).offset(-Theme.topMargin)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(Theme.trailing)
            make.height.equalTo(34)
        }
        
        let dataProvider = Request()
        let turnViewModel = TurnViewModel(dataProvider: dataProvider)
        
        turnViewModel.turn(byId: self.turnId!, completion: {(turn) -> Void in
            
            DispatchQueue.main.async {
                self.sportcenterLabel.text = turn.sportcenter?.name
                self.sportcenterAddressLabel.text = turn.sportcenter?.address
                let fee = turn.ground?.fee ?? 0
                self.feeLabel.text = "$ \(fee)"
                self.dateLabel.text = "" //Theme.dateShortFormat(date: turn.date as Date)
            }
        }, error: {(error) -> Void in
            self.sportcenterLabel.text = "Error"
            self.sportcenterAddressLabel.text = "Error"
            self.dateLabel.text = "Error"
        })
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @objc func addTurnAction() {
        
        let profile = ProfileModel()
        
        if !profile.mobileVerified {
            
            if accountKit == nil {
                accountKit = AKFAccountKit(responseType: .authorizationCode)
            }
            
            let viewController = accountKit!.viewControllerForPhoneLogin(with: nil, state: UUID().uuidString) as AKFViewController
            viewController.enableSendToFacebook = true
            viewController.delegate = self
            
            self.present(viewController as! UIViewController, animated: true, completion: nil)
            
        }
        
    }
    
    func backAction() {
        
        let alert = Alert(presenting: self)
        alert.showAlert(title: "CANCEL_TURN".localizable(), message: "CANCEL_TURN_MESSAGE".localizable(), handler: { action in 
            let dataProvider = Request()
            let turnViewModel = TurnViewModel(dataProvider: dataProvider)
            turnViewModel.removeTurn(turnId: self.turnId!, completion: {(turn) -> Void in
                DispatchQueue.main.async {
                    self.navigationController?.popToRootViewController(animated: true)
                }
            }, error: {(error) -> Void in
                DispatchQueue.main.async {
                    alert.showAlert(title: "TURN_ERROR".localizable(), message: "TURN_ERROR_MESSAGE".localizable())
                }
            })
        })
        
    }
    
    private func viewController(_ viewController: UIViewController!, didCompleteLoginWithAuthorizationCode code: String!, state: String!) {
        loginMobile(mobile: code)
    }
    
    func loginMobile(mobile: String) {
        
        confirm.showLoading()
        
        let dataProvider = Request()
        let loginViewModel = AuthorizationViewModel(dataProvider: dataProvider)
        
        loginViewModel.loginMobile(mobile: mobile, completion:{(token) -> Void in
            
            self.confirm.hideLoading()
            
            let dataProvider = Request()
            let profieViewModel = ProfileViewModel(dataProvider: dataProvider)
            profieViewModel.deviceId = Preferences.deviceToken
            
            profieViewModel.updateProfile(completion: {_ in}, error: {_ in})
            
            profieViewModel.profile(token: token, completion: {
              
                let turnViewModel = TurnViewModel(dataProvider: dataProvider)
                let request = TurnRequest()
                request.status = TurnResponse.TurnStatus.billable
                turnViewModel.updateTurn(turnId: self.turnId!, param: request, completion: {(turn) -> Void in
                    DispatchQueue.main.async {
                        self.navigationController?.popToRootViewController(animated: true)
                    }
                }, error: {(error) -> Void in
                    print("Error")
                })
                
                
            }, error: {(error) -> Void in
                self.showError(error: error)
            })
            
        },  error: {(err) -> Void in
            self.confirm.hideLoading()
            self.showError(error: err)
        })
        
        
    }
    
    func showError(error: ErrorResponse?) {
        
        let alert = Alert(presenting: self)
        
        var title = "AUTHORIZE_ERROR".localizable()
        var message = "AUTHORIZE_ERROR_MESSAGE".localizable()
        
        if error == .networkError {
            title = "NETWORK_ERROR".localizable()
            message = "NETWORK_ERROR_MESSAGE".localizable()
        }
        
        alert.showAlert(title: title, message: message, handler: { (action) -> Void in
            
            DispatchQueue.main.async {
                self.navigationController?.popToRootViewController(animated: true)
            }
            
        })
    }
}
