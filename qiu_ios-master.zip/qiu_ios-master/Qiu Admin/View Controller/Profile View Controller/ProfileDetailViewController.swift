//
//  ProfileDetailViewController.swift
//  Qiu
//
//  Created by Marcos Tirao on 8/29/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit
import UIFontComplete

class ProfileDetailViewController: UIViewController, VerifierDelegate {
    
    let profileName : UITextField = UITextField()
    
    let addressField = FieldView(frame: CGRect(x:0, y:0, width:0, height:0), type: .text, label: "ADDRESS_LABEL".localizable())
    let phoneField = FieldView(frame: CGRect(x:0, y:0, width:0, height:0), type: .text, label: "PHONE_LABEL".localizable())
    let contactField = FieldView(frame: CGRect(x:0, y:0, width:0, height:0), type: .email, label: "CONTACT_LABEL".localizable())
    let aboutField = FieldView(frame: CGRect(x:0, y:0, width:0, height:0), type: .text, label: "ABOUT_LABEL".localizable())
    
    let facebookVerifier = VerifierView(frame: CGRect(x:0, y:0, width:0, height:0), buttonText: "VERIFY".localizable(), buttonTextDisabled:"VERIFIED".localizable(),
                                        image: UIImage(named: "facebook-verifier")!, delegate: nil)
    
    let emailVerifier = VerifierView(frame: CGRect(x:0, y:0, width:0, height:0), buttonText: "VERIFY".localizable(), buttonTextDisabled:"VERIFIED".localizable(),
                                     image: UIImage(named: "email-verifier")!, delegate: nil)
    
    let mobileVerifier = VerifierView(frame: CGRect(x:0, y:0, width:0, height:0), buttonText: "VERIFY".localizable(), buttonTextDisabled:"VERIFIED".localizable(), 
                                      image: UIImage(named: "mobile-verifier")!, delegate: nil)
    
    let scrollView = UIScrollView()
    
    var userProfile : ProfileModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let addTurn = UIBarButtonItem(barButtonSystemItem: .save, target: self, action: #selector(ProfileDetailViewController.saveProfile))
        self.navigationController?.navigationBar.tintColor = UIColor.white
        self.navigationItem.rightBarButtonItem = addTurn

        
        self.view.backgroundColor = UIColor.white
        
        self.addressField.placeholder = "ADDRESS".localizable()
        self.phoneField.placeholder = "PHONE".localizable()
        self.contactField.placeholder = "CONTACT".localizable()
        self.aboutField.placeholder = "ABOUT".localizable()
        
        self.addressField.labelFont =  UIFont(name:Font.helveticaNeueBold.rawValue, size:UIFont.systemFontSize )
        self.phoneField.labelFont =  UIFont(name:Font.helveticaNeueBold.rawValue, size:UIFont.systemFontSize )
        self.contactField.labelFont =  UIFont(name:Font.helveticaNeueBold.rawValue, size:UIFont.systemFontSize )
        self.aboutField.labelFont =  UIFont(name:Font.helveticaNeueBold.rawValue, size:UIFont.systemFontSize )
       
        
        self.view.addSubview(scrollView)
        scrollView.snp.makeConstraints { make in
            make.top.right.left.bottom.equalTo(self.view)
        }
        
        
        let contentView = scrollView
       // scrollView.addSubview(contentView)
       // contentView.snp.makeConstraints{(make) -> Void in
        //    make.edges.equalTo(scrollView)
        //}
        
        let profileImage = UIImageView(image: UIImage(named: "avatar"))
        profileImage.layer.cornerRadius = 32
        contentView.addSubview(profileImage)
        profileImage.snp.makeConstraints{(make) -> Void in
            make.height.width.equalTo(64)
            make.top.equalTo(0)
            make.right.equalTo(self.view.snp.right).offset(-10)
        }
        
        self.profileName.font =  UIFont(name:Font.helveticaNeue.rawValue, size:24 )
        self.profileName.placeholder = "NAME".localizable()
        self.profileName.textAlignment = .right
        contentView.addSubview(profileName)
        profileName.snp.makeConstraints{(make) -> Void in
            make.height.equalTo(30)
            make.centerY.equalTo(profileImage.snp.centerY)
            make.right.equalTo(profileImage.snp.left).offset(-10)
            make.left.equalTo(Theme.leading)
        }
        
        
        contentView.addSubview(addressField)
        addressField.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(profileImage.snp.bottom).offset(32)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(-10)
            make.height.equalTo(50)
        }
        
        contentView.addSubview(phoneField)
        phoneField.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(addressField.snp.bottom).offset(24)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(-10)
            make.height.equalTo(50)
        }
        
        contentView.addSubview(contactField)
        contactField.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(phoneField.snp.bottom).offset(24)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(-10)
            make.height.equalTo(50)
        }
        
        contentView.addSubview(aboutField)
        aboutField.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(contactField.snp.bottom).offset(24)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(-10)
            make.height.equalTo(50)
        }
        
        
        contentView.addSubview(facebookVerifier)
        facebookVerifier.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(aboutField.snp.bottom).offset(24)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(-10)
            make.height.equalTo(40)
        }
        
        
        contentView.addSubview(emailVerifier)
        emailVerifier.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(facebookVerifier.snp.bottom).offset(24)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(-10)
            make.height.equalTo(40)
        }
        
        contentView.addSubview(mobileVerifier)
        mobileVerifier.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(emailVerifier.snp.bottom).offset(24)
            make.left.equalTo(Theme.leading)
            make.right.equalTo(self.view.snp.right).offset(-10)
            make.height.equalTo(40)
        }
        
        self.scrollView.setNeedsLayout()
        
        self.facebookVerifier.delegate = self
        self.mobileVerifier.delegate = self
        self.emailVerifier.delegate = self
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.userProfile?.reloadData()
        
        if (self.userProfile?.name.count)! > 0 {
            profileName.text = self.userProfile?.name
        }
        
        if (self.userProfile?.address.count)! > 0 {
            addressField.data = self.userProfile?.address
        }
        
        if (self.userProfile?.phone.count)! > 0 {
            phoneField.data = self.userProfile?.phone
        }

        if (self.userProfile?.about.count)! > 0 {
            aboutField.data = self.userProfile?.about
        }
        
        if (self.userProfile?.contact.count)! > 0 {
            contactField.data = self.userProfile?.contact
        }
        
        if (self.userProfile?.emailVerified)! {
            emailVerifier.hide = true
        }
        
        if (self.userProfile?.facebookVerified)! {
            facebookVerifier.hide = true
        }
        if (self.userProfile?.mobileVerified)! {
            mobileVerifier.hide = true
        }
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        
        let contentHeight = self.mobileVerifier.frame.origin.y + self.mobileVerifier.frame.size.height + CGFloat(Theme.topMargin)
        self.scrollView.contentSize = CGSize(width: self.view.frame.size.width, height: contentHeight)
    
    }
    
    @objc func saveProfile() {
    
        
        if Preferences.isLogged {
            
            let dataProvider = Request()
            let profileViewModel = ProfileViewModel(dataProvider: dataProvider)
            profileViewModel.name = profileName.text!
            profileViewModel.email = contactField.data!
            profileViewModel.about = aboutField.data!
            profileViewModel.address = addressField.data!
            profileViewModel.mobile = phoneField.data!
            profileViewModel.emailVerified = self.userProfile?.emailVerified ?? false
            profileViewModel.mobileVerified = self.userProfile?.mobileVerified ?? false
            profileViewModel.facebookVerified = self.userProfile?.facebookVerified ?? false
            
            profileViewModel.updateProfile(completion: { (profile) -> Void in
            
                profile.save()
                
                DispatchQueue.main.async {
                    self.navigationController?.popViewController(animated: true)
                }

                
            }, error: { (error) -> Void in
                
                let alert = Alert(presenting: self)
                
                let title = "UPDATE_PROFILE_ERROR".localizable()
                let message = "UPDATE_PROFILE_ERROR_MESSAGE".localizable()
                
                alert.showAlert(title: title, message: message)
                
                
            })
        }
        
    }
    
    func didSelectVerified() {
        
    }

}
