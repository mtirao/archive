//
//  ProfileViewController.swift
//  Qiu
//
//  Created by Marcos Tirao on 7/26/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit
import UIFontComplete
import FBSDKCoreKit
import FBSDKLoginKit


private let cellIdentifier = "optionCell"
private let nibFile = "ProfileOptionCell"

enum ActionIndex: Int{
    case profile = 0, contactUs, addSportCenter, logout, changePassword
}

class ProfileViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, PresentDelegate {
    
    
    
    let profileName = UILabel()
    let optionTableView = UITableView(frame: CGRect(x:0, y:0, width:0, height:0), style: .grouped)

    var delegate: ProfileDelegate?
    
    var options : [(String, String)] = [("PROFILE".localizable(), "profile"), ("HELP".localizable(), "envelop"),  ("CONVERT_TO_QIU".localizable(), "add-field"), ("LOGOUT".localizable(), ""), ("CHANGE_PASSWORD".localizable(), "")]
    
    let qiuLogin = ProfileModel()
    
    
    var configurationActionSheet: Alert?

    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        self.view.backgroundColor = UIColor.white
        self.navigationController?.navigationBar.isHidden = false
        
        let profileImage = UIImageView(image: UIImage(named: "avatar"))
        profileImage.layer.cornerRadius = 32
        self.view.addSubview(profileImage)
        profileImage.snp.makeConstraints{(make) -> Void in
            make.height.width.equalTo(64)
            make.top.equalTo(self.topLayoutGuide.snp.bottom).offset(Theme.topMargin)
            make.trailing.equalTo(Theme.trailing)
        }
        
        self.profileName.font =  UIFont(name:Font.helveticaNeue.rawValue, size:24 )
        self.profileName.textAlignment = .right
        self.profileName.text = "NAME".localizable()
        self.view.addSubview(profileName)
        self.profileName.snp.makeConstraints{(make) -> Void in
            make.height.equalTo(30)
            make.centerY.equalTo(profileImage.snp.centerY)            
            make.right.equalTo(profileImage.snp.left).offset(-10)
            make.left.equalTo(Theme.leading)

        }
        
        
        optionTableView.register(UINib(nibName: nibFile, bundle: nil), forCellReuseIdentifier: cellIdentifier)
        optionTableView.dataSource = self
        optionTableView.delegate = self
        self.view.addSubview(optionTableView)
        optionTableView.estimatedRowHeight = 64
        optionTableView.backgroundColor = UIColor.white
        optionTableView.snp.makeConstraints{(make) -> Void in
            make.top.equalTo(profileImage.snp.bottom).offset(Theme.topBigMargin)
            make.leading.trailing.equalTo(0)
            make.bottom.equalTo(self.bottomLayoutGuide.snp.top)
        }
        
        configurationActionSheet = Alert(presenting: self)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        Tracking.userEnterView(viewName: .profileView)

        
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.navigationBar.barTintColor = Theme.navigationBackgroundColor
        
        
        let sportCenterModel = SportCenterModel()
        if sportCenterModel.isLoad {
            updateViewForSportcenter()
            
        }else {
            loadSportCenter()
        }
        
        qiuLogin.reloadData()
        
        
        profileName.text = qiuLogin.name
        
        let login = LoginModel()
        login.load()
        let token = login.token
        
        let dataProvider = Request()
        let profileViewModel = ProfileViewModel(dataProvider: dataProvider)
        profileViewModel.profile(token: token)
        
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        Tracking.userExitView(viewName: .profileView)

    }
    
    func updateViewForSportcenter() {
        let configuration = UIBarButtonItem(image:UIImage(named: "gear"), style: .done, target: self, action: #selector(ProfileViewController.configurationAction))
        self.navigationController?.navigationBar.tintColor = UIColor.white
        self.navigationItem.rightBarButtonItem = configuration
        
    }
    
    func loadSportCenter() {
        
        let dataProvider = Request()
        let sportcenterViewModel = SportcenterViewModel(dataProvider: dataProvider)
        sportcenterViewModel.listSportCenterOwned(completion: {
            DispatchQueue.main.async {
                self.optionTableView.reloadData()
                self.updateViewForSportcenter()
            }
        }, error: {(error) -> Void in
            print(error.debugDescription)
        })
        
    }
    
    @objc func configurationAction() {
        
        let grounds = GroundModel()
        
        let courtAction = UIAlertAction(title: (grounds.count <= 0) ? "ADD_COURT".localizable() : "UPDATE_COURT".localizable(), style: .default , handler: { action -> Void in
            
            DispatchQueue.main.async {
                let court = SportCourtPageViewController(transitionStyle: .scroll, navigationOrientation: .horizontal, options: nil)
                self.navigationController?.pushViewController(court, animated: true)
            }
            
        })
        
        let deleteSportcenterAction = UIAlertAction(title: "DELETE_SPORTCENTER".localizable(), style: .destructive , handler: { action -> Void in
            
            let dataProvider = Request()
            let sportcenterViewModel = SportcenterViewModel(dataProvider: dataProvider)
            sportcenterViewModel.deleteSportcenter()
            
            DispatchQueue.main.async {
                self.navigationItem.rightBarButtonItem = nil
            }
        })

        configurationActionSheet?.showActionSheet(title: "PROFILE_ACTION_SHEET_TITLE".localizable(), message: "PROFILE_ACTION_SHEET_MESSAGE".localizable(), actions: [courtAction, deleteSportcenterAction])
    }
    
}

extension ProfileViewController {
    
    func didSelectDismiss(presented: UIViewController) {
        presented.dismiss(animated: true, completion: nil)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return options.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier)
        if let optionCell = cell as? ProfileOptionCell {
            let option = options[indexPath.row]
            
            optionCell.label.text = option.0
            optionCell.icon.image = UIImage(named:option.1)
            optionCell.selectionStyle = .none
            return optionCell
        }
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        guard let action = ActionIndex(rawValue: indexPath.row) else {
            return
        }
    
        switch action  {
        case  ActionIndex.profile:
            let detail = ProfileDetailViewController()
            detail.userProfile = self.qiuLogin
            self.navigationController?.pushViewController(detail, animated: true)
            break;
        case ActionIndex.contactUs:
            let contactUs = ContactUsViewController()
            self.navigationController?.pushViewController(contactUs, animated: true)
            break;
        case ActionIndex.addSportCenter:
            let sportCenterModel = SportCenterModel()
            
            if sportCenterModel.isLoad {
                let sportCenterViewController = SportCenterViewController()
                sportCenterViewController.sportCenterModel = sportCenterModel
                self.navigationController?.pushViewController(sportCenterViewController, animated: true)
            }else {
                let sportCenter = SportCenterPresentationViewController()
                self.navigationController?.pushViewController(sportCenter, animated: true)
            }
            break;
        case ActionIndex.logout:
            Preferences.isLogged = false
            
            if (FBSDKAccessToken.current()) != nil {
                let fbLoginManager : FBSDKLoginManager = FBSDKLoginManager()
                fbLoginManager.logOut()
            }
            
            let loginModel = LoginModel()
            loginModel.delete()
            
            self.delegate?.didLogout()
            break;
        case ActionIndex.changePassword:
            let changePassword = ChangePasswordViewController()
            self.navigationController?.pushViewController(changePassword, animated: true)
            break;
        
        }
        
        
    }
    
}
