//
//  HomeViewController.swift
//  Qiu
//
//  Created by Marcos Tirao on 7/26/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit
import FBSDKCoreKit


class HomeViewController: UITabBarController, UITabBarControllerDelegate, LoginControllerDelegate, ProfileDelegate {
    
    enum SelectedTab : Int {
        case calendar = 0
        case profile
        case turn
        case notification
        case news
    }
    
    var tabSelection : SelectedTab = .calendar
    let loginViewController = LoginViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //UINavigationBar.appearance().barTintColor = Theme.navigationBackgroundColor
                
        let calendarViewController = CalendarPageViewController(transitionStyle: .scroll, navigationOrientation: .horizontal, options: nil)
        let navigationCalendar = UINavigationController(rootViewController: calendarViewController)
        
        
        let titleView = UIView(frame:navigationCalendar.navigationBar.frame)
        let titleLabel = UILabel(frame: CGRect(x: 0, y: 10, width: titleView.frame.width, height: 22))
        titleLabel.text = "CALENDAR".localizable()
        titleView.addSubview(titleLabel)
        titleLabel.textColor = UIColor.white
        titleLabel.font = UIFont.systemFont(ofSize: 20)
        navigationCalendar.navigationBar.topItem?.titleView = titleView
        calendarViewController.titleLabel = titleLabel
        
        
        let turnViewController = TurnViewController()
        let navigationTurn = UINavigationController(rootViewController: turnViewController)
        navigationTurn.navigationBar.barStyle = .black
        navigationTurn.navigationBar.topItem?.title = "TURN".localizable()
        
        let profileViewController = ProfileViewController()
        profileViewController.delegate = self
        let navigationProfile = UINavigationController(rootViewController: profileViewController)
        navigationProfile.navigationBar.barStyle = .black
        navigationProfile.navigationBar.topItem?.title = "PROFILE".localizable()
        
        let notificationViewController = NotificationViewController()
        let navigationNotification = UINavigationController(rootViewController: notificationViewController)
        navigationNotification.navigationBar.barStyle = .black
        navigationNotification.navigationBar.topItem?.title = "NOTIFICATIONS".localizable()
        
        let socialViewController = SocialViewController()
        let navigationSocial = UINavigationController(rootViewController: socialViewController)
        navigationSocial.navigationBar.barStyle = .black
        navigationSocial.navigationBar.topItem?.title = "SOCIAL".localizable()
        
        let calendarImage = UIImage(named:"calendar")
        let calendarSelectedImage = UIImage(named:"calendar-selected")
        let tabItemCalendar = UITabBarItem(title: "CALENDAR".localizable(), image: calendarImage, selectedImage: calendarSelectedImage)
        navigationCalendar.tabBarItem = tabItemCalendar
        
        let courtImage = UIImage(named:"turn")
        let courtSelectedImage = UIImage(named:"turn-selected")
        let tabItemCourt = UITabBarItem(title: "TURN".localizable(), image: courtImage, selectedImage: courtSelectedImage)
        navigationTurn.tabBarItem = tabItemCourt
        
        let profileImage = UIImage(named:"profile")
        let profileSelectedImage = UIImage(named:"profile-selected")
        let tabItemProfile = UITabBarItem(title: "PROFILE".localizable(), image: profileImage, selectedImage: profileSelectedImage)
        navigationProfile.tabBarItem = tabItemProfile
        
        let notificationImage = UIImage(named:"notification")
        let notificationSelectedImage = UIImage(named:"notification-selected")
        let tabItemNotification = UITabBarItem(title: "NOTIFICATIONS".localizable(), image: notificationImage, selectedImage: notificationSelectedImage)
        navigationNotification.tabBarItem = tabItemNotification
        
        let socialImage = UIImage(named:"social")
        let socialSelectedImage = UIImage(named:"social-selected")
        let tabItemSocial = UITabBarItem(title: "SOCIAL".localizable(), image: socialImage, selectedImage: socialSelectedImage)
        navigationSocial.tabBarItem = tabItemSocial

        let unselectedItem: NSDictionary = [kCTForegroundColorAttributeName: UIColor.lightGray]
        let selectedItem: NSDictionary = [kCTForegroundColorAttributeName: Theme.qiuRed]
        
        tabItemCalendar.setTitleTextAttributes(unselectedItem as? [NSAttributedStringKey : AnyObject], for: .normal)
        tabItemCalendar.setTitleTextAttributes(selectedItem as? [NSAttributedStringKey : AnyObject], for: .selected)
        
        tabItemProfile.setTitleTextAttributes(unselectedItem as? [NSAttributedStringKey : AnyObject], for: .normal)
        tabItemProfile.setTitleTextAttributes(selectedItem as? [NSAttributedStringKey : AnyObject], for: .selected)
        
        tabItemSocial.setTitleTextAttributes(unselectedItem as? [NSAttributedStringKey : AnyObject], for: .normal)
        tabItemSocial.setTitleTextAttributes(selectedItem as? [NSAttributedStringKey : AnyObject], for: .selected)
        
        tabItemNotification.setTitleTextAttributes(unselectedItem as? [NSAttributedStringKey : AnyObject], for: .normal)
        tabItemNotification.setTitleTextAttributes(selectedItem as? [NSAttributedStringKey : AnyObject], for: .selected)
        
        tabItemCourt.setTitleTextAttributes(unselectedItem as? [NSAttributedStringKey : AnyObject], for: .normal)
        tabItemCourt.setTitleTextAttributes(selectedItem as? [NSAttributedStringKey : AnyObject], for: .selected)
        
        let controllers = [navigationCalendar, navigationProfile, navigationTurn, navigationNotification, navigationSocial]
        
        self.viewControllers = controllers
        
        self.selectedViewController = navigationCalendar
        
        validateAndReplaceViewControler(viewController: navigationTurn)
        
        self.selectedIndex = 2
        
        self.delegate = self
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.tabBar.barStyle = .default
        self.tabBar.isTranslucent = false
        
        self.tabBar.backgroundColor = Theme.qiuGreen
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool {
        
        let selectedTab = SelectedTab(rawValue: (tabBarController.viewControllers?.index(of: viewController))!)
        
        if let navController = viewController as? UINavigationController {
            navController.popViewController(animated: false)
        }
        
        if selectedTab == .notification || selectedTab == .profile {
            
            if !Preferences.isLogged {
                self.tabSelection = selectedTab!
                loginViewController.delegate = self
                self.present(loginViewController, animated: true, completion: nil)
                return false
            }
        }else if selectedTab == .turn {
            validateAndReplaceViewControler(viewController: viewController)
        }
        
        return true;
    }

    
    func validateAndReplaceViewControler(viewController: UIViewController?) -> Void {
        let sportCenterModel = SportCenterModel()
        
        if sportCenterModel.isLoad {
            let sportCourtViewController = TurnOwnViewController()
            if let navigationController = viewController as? UINavigationController {
                navigationController.viewControllers[0] =  sportCourtViewController
            }
        }
    }
    
    func didFinishedLogin() {
        loginViewController.dismiss(animated: true, completion: {
            self.selectedIndex = self.tabSelection.rawValue
        })
        
    }
    
    func didFinshedLoginWithError() {
        loginViewController.dismiss(animated: true, completion: {
            self.selectedIndex = 2
        })
    }
    
    func didLogout() {
        DispatchQueue.main.async {
            self.selectedIndex = 2
        }
    }
}
