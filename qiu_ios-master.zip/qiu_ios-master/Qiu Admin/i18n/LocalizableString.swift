//
//  LocalizableString.swift
//  Qiu
//
//  Created by Marcos Tirao on 7/26/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation

extension String {
    
    func localizable() -> String {
        return NSLocalizedString(self, comment: "")
    }
    
}
