//
//  AuthorizationViewModel.swift
//  Qiu
//
//  Created by Marcos Tirao on 03/12/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class AuthorizationViewModel: NSObject {
    
    let dataProvider : DataProvider
    
    private var authorizeResource : String = ""
    
    init(dataProvider: DataProvider) {
        self.dataProvider = dataProvider
        
        authorizeResource = Request.url(resource: "authorize")
    }
    
    
    func loginMobile(mobile: String, completion:@escaping (String) -> Void,  error: @escaping (ErrorResponse?) -> Void) {
        
        
        self.authorize(mobile: mobile, completion:{ (response) -> Void in
            
            //completion()
            //Preferences.serverToken = response._id
            //self.confirm.hideLoading()
            
            response.save()
            
            if Preferences.onboarded {
                
                let keychain = KeychainWrapper()
                let token = (keychain.myObject(forKey: "v_Data") as? String) ?? ""
                
                let profileViewModel = ProfileViewModel(dataProvider:self.dataProvider)
                profileViewModel.profile(token: token, completion: {
                    
                    completion(token)
                    
                }, error: {(err) -> Void in
                    error(err)
                    
                })
                
            }else {
                NotificationController.postNotification(name: Notes.endOnboardNotification.notification, userInfo: nil)
            }
            
        }, error: {(err) -> Void in
            
            error(err)
        })
    }
    
    
    
    //MARK: - Authorize resource
    func authorize(email: String, password: String, completion: @escaping (AuthResponse) -> Void, error: @escaping (ErrorResponse?) -> Void) {
        self.authorize(email: email, password: password, mobile:nil, name: nil, oldPassword: nil, completion: completion, error: error)
    }
    
    func authorize(email: String, name:String, completion: @escaping (AuthResponse) -> Void, error: @escaping (ErrorResponse?) -> Void) {
        self.authorize(email: email, password: nil, mobile: nil, name: name, oldPassword: nil, completion: completion, error: error)
    }
    
    func authorize(mobile: String, completion: @escaping (AuthResponse) -> Void, error: @escaping (ErrorResponse?) -> Void) {
        self.authorize(email: nil, password: nil, mobile: mobile, name: nil, oldPassword: nil, completion: completion, error: error)
    }
    
    func authorize(oldPassword: String, newPassword: String, completion: @escaping (AuthResponse) -> Void, error: @escaping (ErrorResponse?) -> Void) {
        self.authorize(email: nil, password: newPassword, mobile: nil, name: nil, oldPassword: oldPassword, completion: completion, error: error)
    }
    
    private func authorize(email: String?, password: String?, mobile: String?, name: String?, oldPassword:String?, completion: @escaping (AuthResponse) -> Void, error: @escaping (ErrorResponse?) -> Void) {
        
        
        var method : HTTPMethod = .POST
    
        
        if oldPassword != nil &&  password != nil{
            method = .PUT
        }
        
        
        let request = LoginRequest(password: password ?? "", name: name ?? "", email: email ?? "", mobile: mobile ?? "")
        
        
        dataProvider.makeRequest(url: authorizeResource, method: method, parameters:request, completion: { data in
            
            if let data = data,
            let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String : Any] {
                
                if let authResponse = AuthResponse(json:json) {
                    completion(authResponse)
                }else {
                    error(.serializationError )
                }
            }
        }, error: { result in
            error(result)
            
        })
        
    }
    
}
