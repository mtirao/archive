//
//  ProfileViewModel.swift
//  Qiu
//
//  Created by Marcos Tirao on 03/12/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class ProfileViewModel: NSObject {
    
    let dataProvider : DataProvider
    
    private var profileResource : String = ""
    
    var name: String?
    var mobile: String?
    var email: String?
    var about: String?
    var address: String?
    var deviceId: String?
    var emailVerified: Bool = false
    var facebookVerified: Bool = false
    var mobileVerified: Bool = false
    
    init(dataProvider: DataProvider) {
        self.dataProvider = dataProvider
        
        profileResource = Request.url(resource: "profile")
        
    }
    
    //MARK: - Profile resource
    func profile(token:String, completion: @escaping (() -> Void), error: @escaping ((ErrorResponse?) -> Void)) {
        
        let profileUrl = "\(profileResource)/\(token)"
        
        dataProvider.makeRequest(url: profileUrl, method: .GET, parameters: nil, completion: { data in
            
            if let data = data,
                let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                
                if let profileResponse = ProfileResponse(json:json!) {
                    profileResponse.save()
                    completion()
                }else {
                    error(.serializationError )
                }
            }
        }, error: { result in
            error(result)
            
        })
    }
    
    func profile(token:String) {
        self.profile(token: token, completion: {}, error: {_ in })
    }
    
    func updateProfile(completion: @escaping (ProfileResponse) -> Void, error: @escaping (ErrorResponse?) -> Void) {
        
        let request = ProfileRequest()
        request.name = name
        request.email = email
        request.about = about
        request.address = address
        request.mobile = mobile
        request.deviceId = Preferences.deviceToken        
        request.emailVerified = emailVerified
        request.facebookVerified = facebookVerified
        request.mobileVerified = mobileVerified
        
        dataProvider.makeRequest(url: profileResource, method: .PUT, parameters: request, completion: { data in
            
            if let data = data,
                let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                
                if let profileResponse = ProfileResponse(json:json!) {
                    completion(profileResponse)
                }else {
                    error(.serializationError )
                }
            }
        }, error: { result in
            error(result)
            
        })
        
    }
    
}
