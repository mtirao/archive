//
//  GroundViewModel.swift
//  Qiu
//
//  Created by Marcos Tirao on 03/12/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class GroundViewModel: NSObject {
    
    let dataProvider : DataProvider
    
    private var groundResource : String = ""
    
    init(dataProvider: DataProvider) {
        self.dataProvider = dataProvider
        
        groundResource = Request.url(resource: "ground")
        
    }
    
    //MARK: - Ground resource
    
    func updateGround(ground:String, param:RequestProtocol, completion: @escaping (GroundResponse) -> Void, error: @escaping (ErrorResponse?) -> Void) {
        
        let groundUrl = "\(groundResource)/\(ground)"
        
        dataProvider.makeRequest(url: groundUrl, method: .PUT, parameters: param, completion: { data in
            
            if let data = data,
                let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                    completion(GroundResponse(json:json)!)
                }
        }, error: { result in
            error(result)
            
        })
       
    }
    
    func addGround(sportcenter:String, param:RequestProtocol, completion: @escaping (GroundResponse) -> Void, error: @escaping (ErrorResponse?) -> Void) {
        let groundUrl = "\(groundResource)/\(sportcenter)"
        
        dataProvider.makeRequest(url: groundUrl, method: .POST, parameters: param, completion: { data in
            
            if let data = data,
                let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                
                if let ground = GroundResponse(json:json!) {
                        completion(ground)
                }else {
                    error(.serializationError )
                }
            }
        }, error: { result in
            error(result)
            
        })

    }
    
    func listGround(sportcenter:String, completion: @escaping (GroundResponseList) -> Void, error: @escaping (ErrorResponse?) -> Void) {
        let groundUrl = "\(groundResource)/\(sportcenter)"
        
        dataProvider.makeRequest(url: groundUrl, method: .GET, parameters: nil, completion: { data in
            
            if let data = data,
                let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [Any] {
                
                if let ground = GroundResponseList(json:json!) {
                    completion(ground)
                }
            }
        }, error: { result in
            error(result)
        })
    }
    
    func deleteGround(sportcenter:String, completion: @escaping (GroundResponse) -> Void, error: @escaping (ErrorResponse?) -> Void) {
        let groundUrl = "\(groundResource)/\(sportcenter)"
        
        dataProvider.makeRequest(url: groundUrl, method: .DELETE, parameters: nil, completion: { data in
            
            if let data = data,
                let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                
                if let ground = GroundResponse(json:json!) {
                    completion(ground)
                }else {
                    error(.serializationError )
                }
            }
        }, error: { result in
            error(result)
        })
    }
    
}
