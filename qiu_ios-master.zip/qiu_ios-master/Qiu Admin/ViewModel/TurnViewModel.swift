//
//  TurnViewModel.swift
//  Qiu
//
//  Created by Marcos Tirao on 03/12/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class TurnViewModel: NSObject {
    
    let dataProvider: DataProvider
    
    private var turnResource : String = ""
    private var turnBySportCenterResource : String = ""
    private var turnByOwnerResource : String = ""
    private var turnsAllOwnerResource : String = ""
    
    private let secondsPerHour : Int = 3600
    
    init(dataProvider: DataProvider) {
        self.dataProvider = dataProvider
        
        turnResource = Request.url(resource: "turn")
        turnBySportCenterResource = Request.url(resource: "turnsBySportcenter")
        turnByOwnerResource = Request.url(resource: "turnsByOnwer")
        turnsAllOwnerResource = Request.url(resource: "turnsAllOwner")
    }
    
    //MARK: - Public method
    func addTurn(param:[RequestProtocol], completion: @escaping (String) -> Void, error: @escaping (ErrorResponse?) -> Void) {
        
        if param.count > 1 {
            
            self.turn(param:param[0], method:.POST, completion:{ (response1) -> Void in
                self.turn(param:param[1], method:.POST, completion:{ (response2) -> Void in
                    response1.save()
                    response2.save()
                    completion(response2.partner)
                }, error: error)
            }, error: error)
            
        }
    
    }
    
    
    func removeTurn(turnId: String, completion: @escaping (TurnResponse) -> Void, error: @escaping (ErrorResponse?) -> Void) {
        self.turn(turnId:turnId, method:.DELETE, completion:completion, error: error)
    }
    
    func updateTurn(turnId: String, param:RequestProtocol, completion: @escaping (TurnResponse) -> Void, error: @escaping (ErrorResponse?) -> Void) {
        self.turn(turnId:turnId, param:param, method:.PUT, completion:completion, error: error)
    }
    
    func turn(byId: String, completion: @escaping (TurnResponse) -> Void, error: @escaping (ErrorResponse?) -> Void) {
        self.turn(turnId:byId, method:.GET, completion:completion, error: error)
    }
    
    func turn(completion: @escaping () -> Void, error: @escaping (ErrorResponse?) -> Void) {
        
        let sportCenter = SportCenterModel()
        let turnUrl = "\(turnBySportCenterResource)/\(sportCenter.id)"
        
        dataProvider.makeRequest(url: turnUrl, method: .GET, parameters: nil, completion: { data in
            
            if let data = data,
                let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [Any] {
                
                if let turn = TurnResponseList(json:json!) {
                    turn.save()
                    completion()
                }else {
                    error(.serializationError )
                }
            }
        }, error: { result in
            error(result)
            
        })
        
    }
    
    func turn(completion: @escaping () -> Void) {
        
        let login = LoginModel()
        login.load()
        let turnUrl = "\(turnByOwnerResource)/\(login.token)"
        
        dataProvider.makeRequest(url: turnUrl, method: .GET, parameters: nil, completion: { data in
            
            if let data = data,
                let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [Any] {
                
                if let turn = TurnResponseList(json:json!) {
                    turn.save()
                    completion()
                }
            }
        }, error: { result in
            print(result)
        })
        
    }
    
    func turnAllOwner(completion: @escaping () -> Void) {
        
        let login = LoginModel()
        login.load()
        let turnUrl = "\(turnsAllOwnerResource)/\(login.token)"
        
        let sportcenter = SportCenterModel()
        
        let request = TurnRequest()
        request.sportcenter = sportcenter.id
        
        dataProvider.makeRequest(url: turnUrl, method: .GET, parameters: request, completion: { data in
            
            if let data = data,
                let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [Any] {
                
                if let turn = TurnResponseList(json:json!) {
                    turn.save()
                    completion()
                }
            }
        }, error: { result in
            print(result)
        })
        
    }
    
    
    //MARK: - Private method
    private func turn(turnId: String? = nil,  param:RequestProtocol? = nil, method: HTTPMethod, completion: @escaping (TurnResponse) -> Void, error: @escaping (ErrorResponse?) -> Void) {
        
        var turnUrl = "\(turnResource)"
        
        if turnId != nil {
            turnUrl = "\(turnResource)/\(turnId!)"
        }
    
        
        dataProvider.makeRequest(url: turnUrl, method: method, parameters: param, completion: { data in
            
            if let data = data, let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [Any]{
                
                if let turn = TurnResponseList(json:json!) {
                    turn.save()
                    completion(turn.turns[0])
                }else {
                    error(.serializationError )
                }
            }
        }, error: { result in
            error(result)
            
        })
        
        
    }
    
}
