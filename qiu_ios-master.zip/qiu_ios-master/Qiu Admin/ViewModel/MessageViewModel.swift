//
//  MessageViewModel.swift
//  Qiu
//
//  Created by Marcos Tirao on 15/12/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class MessageViewModel: NSObject, UITableViewDataSource {
    
    static let cellIdentifier = "cellIdentifier"
    
    let dataProvider : DataProvider
    
    private var messageResource : String = ""
    
    private var messages : MessageResponseList?
    
    init(dataProvider: DataProvider) {
        
        self.dataProvider = dataProvider
        
        messageResource = Request.url(resource: "message")
        
    }
    
    func sendMessage(to: MessageResponse.MessageRecipient, title: String, message: String, type: MessageResponse.MessageType, completion:@escaping () -> Void,  error: @escaping (ErrorResponse?) -> Void) {
        
        let param = MessageRequest(to: to, title: title, message: message, type: type)
        
        
        dataProvider.makeRequest(url: messageResource, method: .POST, parameters: param, completion: { data in
            
            if let data = data,
                let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                
                if let message = MessageResponse(json:json!) {
                    print(message.to)
                    completion()
                }else {
                    error(.serializationError )
                }
            }
        }, error: { result in
            error(result)
            
        })
    }
    
    func message(completion:@escaping () -> Void,  error: @escaping (ErrorResponse?) -> Void) {
        
        let loginModel = LoginModel()
        loginModel.load()
        
        let token = loginModel.token
        
        let messageUrl = "\(messageResource)/\(token)"
        
        dataProvider.makeRequest(url: messageUrl, method: .GET, parameters: nil, completion: { data in
            
            if let data = data,
                let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [Any] {
                
                if let message = MessageResponseList(json:json!) {
                        
                    self.messages = message
                    
                    completion()
                }else {
                    error(.serializationError )
                }
            }
        }, error: { result in
            error(result)
            
        })
    }
    
    func message(atIndex indexPath: IndexPath) -> MessageResponse? {
        
        guard let messageList = self.messages else {
            return nil
        }
        
        if indexPath.row >= 0 && indexPath.row < messageList.messages.count {
            return self.messages?.messages[indexPath.row]
        }
        
        return nil
        
    }
}


extension MessageViewModel {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.messages?.messages.count ?? 0
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: MessageViewModel.cellIdentifier) as! NotificationTableCell
        
        let message = self.messages?.messages[indexPath.row]
        
        cell.descriptionLabel.text = message?.message
        cell.titleLabel.text = message?.title
        cell.imageLabel.image = UIImage(named: "message")
        
        return cell
    }
    
}
