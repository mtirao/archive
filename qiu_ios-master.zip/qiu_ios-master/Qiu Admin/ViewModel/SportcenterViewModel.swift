//
//  SportcenterViewModel.swift
//  QiuTests
//
//  Created by Marcos Tirao on 29/11/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class SportcenterViewModel: NSObject {
    
    var name: String = ""
    var address: String = ""
    var phone : String = ""
    var email : String = ""
    var about : String = ""
    var mobileverify : String = "true"
    var emailverify : String = "true"
    var feerequired : String = ""
    var openAt : CGFloat = 0
    var closeAt : CGFloat = 0
    var latitude : Double = 0
    var longitude : Double = 0
    
    let dataProvider : DataProvider
    
    private var sportCenterResource : String = ""
    private var sportCenterResourceById : String = ""
    private var sportcenterOwnedBy : String = ""
    private var sportcenterDelete : String = ""
    
    init(dataProvider: DataProvider) {
        
        self.dataProvider = dataProvider
        
        sportCenterResource = Request.url(resource: "sportcenter")
        sportCenterResourceById = Request.url(resource: "sportcenterById")
        sportcenterOwnedBy = Request.url(resource: "sportcenterOwnedBy")
    }
    
    func validate() -> ErrorResponse? {
        
        if !Preferences.isLogged {
            return ErrorResponse.authorizedFailedError
        }
        
        if address.count <= 5 {
           return ErrorResponse.requestFailedError
        }
        
        if name.count <= 5 {
            return ErrorResponse.requestFailedError
        }
        
        if about.count <= 5 {
            return ErrorResponse.requestFailedError
        }
        
        if phone.count <= 5 {
            return ErrorResponse.requestFailedError
        }
        
        if openAt <= 0 || closeAt <= openAt {
            return ErrorResponse.requestFailedError
        }
        
        return nil
        
    }
    
    func addSportcenter(id: String?, completion:@escaping () -> Void,  error: @escaping (ErrorResponse?) -> Void) {
        
        let request = SportcenterRequest()
        request.name = name
        request.address = address
        request.phone = phone
        request.email = email
        request.about = about
        request.mobileverify = mobileverify
        request.emailverify = emailverify
        request.feerequired = feerequired
        request.openAt = openAt
        request.closeAt = closeAt
        request.latitude = latitude
        request.longitude = longitude
        request.status = "new"
        
        self.addSportCenter(param: request, sportcenterId: id , completion: {(response) -> Void in
            response.save()
            completion()
        }, error: {(err) -> Void in
            
            error(err)
            
        })
    }
    
    func sportcenter(byId: String, completion: @escaping (SportCenterResponse) -> Void, error: @escaping (ErrorResponse?) -> Void) {
        
        let sportcenterUrl = "\(sportCenterResourceById)/\(byId)"
        
        dataProvider.makeRequest(url: sportcenterUrl, method: .GET, parameters: nil, completion: { data in
            
            if let data = data,
                let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [Any] {
                
                if json!.count > 0 {
                    let sportcenter = json![0] as! [String : Any]
                    if let sportCenter = SportCenterResponse(json:sportcenter) {
                        completion(sportCenter)
                    }else {
                        error(.serializationError )
                    }
                }
            }
        }, error: { result in
            error(result)
            
        })
        
    }
    
    func listSportCenter(completion: @escaping (SportCenterResponseList) -> Void, error: @escaping (ErrorResponse?) -> Void) {
        
        let login = LoginModel()
        let token = login.token
        
        let sportcenter = "\(sportCenterResource)/\(token)"
        
        dataProvider.makeRequest(url: sportcenter, method: .GET, parameters:nil, completion: { data in
            
            if let data = data,
                let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                
                if let sportCenter = SportCenterResponseList(json:json?["sportcenters"] as? [Any]) {
                    completion(sportCenter)
                }else {
                    error(.serializationError )
                }
            }
        }, error: { result in
            error(result)
            
        })
    }
    
    func listSportCenterOwned(completion: @escaping () -> Void, error: @escaping (ErrorResponse?) -> Void) {
        
        let login = LoginModel()
        let token = login.token
        
        let sportcenter = "\(sportcenterOwnedBy)/\(token)"
        
        dataProvider.makeRequest(url: sportcenter, method: .GET, parameters:nil, completion: { data in
            
            if let data = data,
                let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                
                if let sportcenters = json?["sportcenters"] as? [Any], sportcenters.count > 0 {
                    if let sportcenter = sportcenters[0] as? [String:Any] {
                        if let sportCenter = SportCenterResponse(json:sportcenter) {
                            sportCenter.save()
                            
                            let groundViewModel = GroundViewModel(dataProvider: self.dataProvider)
                            groundViewModel.listGround(sportcenter: sportCenter._id, completion: {(groundResponse) -> Void in
                                groundResponse.save()
                                completion()
                            }, error: { _ in
                                completion()
                            })
                            
                        }else {
                            error(.serializationError )
                        }
                    } else {
                        completion()
                    }
                }else {
                    completion()
                }
            }
        }, error: { result in
            error(result)
            
        })
        
    }
    
    func deleteSportcenter() {
        
        let sportcenter = SportCenterModel()
        
        let sportcenterResource = "\(sportCenterResourceById)/\(sportcenter.id)"
        
        let sportcenterRequest = SportcenterRequest()
        
        dataProvider.makeRequest(url: sportcenterResource, method: .DELETE, parameters:sportcenterRequest, completion: { data in
            
            sportcenter.delete()
            
        }, error: { result in
            
        })
        
    }
    
    //MARK: - Sport Center resource
    func addSportCenter(param:SportcenterRequest, sportcenterId: String?, completion: @escaping (SportCenterResponse) -> Void, error: @escaping (ErrorResponse?) -> Void) {
        
        var method : HTTPMethod = .POST
        var sportCenterURL = sportCenterResourceById
        
        if let id = sportcenterId {
            method = .PUT
            sportCenterURL = "\(sportCenterResourceById)/\(id)"
        }
        
        dataProvider.makeRequest(url: sportCenterURL, method: method, parameters: param, completion: { data in
            
            if let data = data,
                let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                
                if let sportCenter = SportCenterResponse(json:json!) {
                    completion(sportCenter)
                }else {
                    error(.serializationError )
                }
            }else {
                error(.serializationError )
            }
        }, error: { result in
            error(result)
            
        })
        
    }
    
}
