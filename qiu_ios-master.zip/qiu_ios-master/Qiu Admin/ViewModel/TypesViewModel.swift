//
//  TypesViewModel.swift
//  Qiu
//
//  Created by Marcos Tirao on 03/12/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class TypesViewModel: NSObject {
    
    let dataProvider : DataProvider
    
    private var typesResource: String = ""
    
    
    init(dataProvider: DataProvider) {
        self.dataProvider = dataProvider
        
        typesResource = Request.url(resource: "types")
        
    }
    
    //MARK: - All public request
    func types(completion: @escaping (TypesResponseList) -> Void, error: @escaping (ErrorResponse?) -> Void) {
        
        
        dataProvider.makeRequest(url: typesResource, method: .GET, parameters: nil, completion: { data in
            
            if let data = data,
                let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                
                if let typesResponse = TypesResponseList(json:json?["turns"] as? [Any]) {
                        completion(typesResponse)
                      //  error(.authorizedFailedError)
                }else {
                    error(.serializationError )
                }
            }
        }, error: { result in
            error(result)
        })
    }
    
}
