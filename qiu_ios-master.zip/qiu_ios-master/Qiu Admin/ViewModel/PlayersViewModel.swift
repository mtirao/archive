//
//  PlayersViewModel.swift
//  Qiu
//
//  Created by Marcos Tirao on 03/12/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit

class PlayersViewModel: NSObject {

    let dataProvider : DataProvider
    private var playersResource : String = ""
    
    init(dataProvider: DataProvider) {
        self.dataProvider = dataProvider
        
        playersResource = Request.url(resource: "players")
    }
    
    //MARK: - Players resource
    func addPlayers(param:PlayersRequest, completion: @escaping (PlayersResponse) -> Void, error: @escaping (ErrorResponse?) -> Void) {
        
        dataProvider.makeRequest(url: playersResource, method: .POST, parameters: param, completion: { data in
            
            if let data = data,
                let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                
                if let players = PlayersResponse(json:json!) {
                    if players.code == 200 {
                        completion(players)
                    }else {
                        error(.requestFailedError)
                    }
                }else {
                    error(.serializationError )
                }
            }
        }, error: { result in
            error(result)
            
        })
        
    }
}
