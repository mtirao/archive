//
//  ProfileModel.swift
//  Qiu
//
//  Created by Marcos Tirao on 8/22/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation
import CoreData

class ProfileModel {
    
    private var profile : Profile?
    
    var about : String {
        get {
            return profile?.about ?? "ABOUT".localizable()
        }
        
        set {
            profile?.about = newValue
        }
    }
    
    var address : String {
        get {
           return profile?.address ?? "ADDRESS".localizable()
        }
        
        set {
            profile?.address = newValue
        }
    }
    
    var contact : String {
        get {
            return profile?.email ?? "CONTACT".localizable()
        }
        
        set {
            profile?.email = newValue
        }
    }
    
    var name : String {
        get {
            return profile?.name ?? "NAME".localizable()
        }
        
        set {
            profile?.name = newValue
        }
    }
    
    var phone : String {
        get {
            return profile?.mobile ?? "PHONE".localizable()
        }
        
        set {
            profile?.mobile = newValue
        }
    }
    
    var mobileVerified : Bool {
        get {
            return profile?.mobileVerified ?? false
        }
        
        set {
            profile?.mobileVerified = newValue
        }
    }
    
    var facebookVerified : Bool {
        get {
            return profile?.facebookVerified ?? false
        }
        
        set {
            profile?.facebookVerified = newValue
        }
    }
    
    var emailVerified : Bool {
        get {
            return profile?.emailVerified ?? false
        }
        
        set {
            profile?.emailVerified = newValue
        }
    }
    
    init() {
        self.reloadData()
    }
    
    
    func delete() {
        
        let dataController = AppDelegate.dataController!
        if let login = self.profile {
            dataController.persistentContainer.viewContext.delete(login)
        }
        
        
    }
    
    func reloadData() {
        
        let request : NSFetchRequest<Profile>  = Profile.fetchRequest()
        
        do {
            
            let dataController = AppDelegate.dataController!
            let login = try dataController.persistentContainer.viewContext.fetch(request)
            
            
            if login.count > 0 {
                profile = login[0]
            }else {
                profile = nil
            }
           
        } catch let error as NSError {
            profile = nil
            print("Error in fetch :\(error)")
        }

    }
    
}
