//
//  GroundModel.swift
//  Qiu
//
//  Created by Marcos Tirao on 9/20/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation
import CoreData

class GroundModel {
    
    private var grounds : [Ground] = [Ground]()
    private var ground : Ground?
    
    var name: String {
        set {
            ground?.name = newValue
        }
        
        get {
            return ground?.name ?? ""
        }
    }
    
    var type: String {
        set {
            ground?.type = newValue
        }
        
        get {
            return ground?.type ?? ""
        }
    }
    
    var fee : Int16{
        set {
            ground?.fee = newValue
        }
        
        get {
            return ground?.fee ?? 0
        }
    }
    
    var price : Int16 {
        set {
            ground?.price = newValue
        }
        
        get {
            return ground?.price ?? 0
        }
    }
    
    var id : String {
        get {
            return ground?.id ?? ""
        }
    }
    
    var count: Int {
        get {
            return self.grounds.count
        }
    }
    
   
    init() {
        self.reloadData()
    }
    
    func ground(at indexPath: IndexPath) -> Ground {
        
        return self.grounds[indexPath.row]
        
    }
    
    func select(withId: String) {
        let request : NSFetchRequest = Ground.fetchRequest()
        request.predicate = NSPredicate(format: "(id == %@)", withId)
        request.sortDescriptors = [NSSortDescriptor(key: "name", ascending: false)]
        
        
        do {
            
            let dataController = AppDelegate.dataController!
            let context = dataController.persistentContainer.viewContext
            
            let ground = try context.fetch(request)
            
            if ground.count > 0 {
                self.ground = ground[0];
            }
            
        } catch let error as NSError {
            print("Error in fetch :\(error)")
        }
    }
    
    func select(index: Int) {
        if index>=0 && index < self.grounds.count {
            self.ground = self.grounds[index]
        }else {
            self.ground = nil
        }
    }
    
    func delete(withId: String) {
        
        let request : NSFetchRequest = Ground.fetchRequest()
        request.predicate = NSPredicate(format: "(id == %@)", withId)
        request.sortDescriptors = [NSSortDescriptor(key: "name", ascending: false)]
        
        
        do {
            let dataController = AppDelegate.dataController!
            let context = dataController.persistentContainer.viewContext
            
            let ground = try context.fetch(request)
            
            if ground.count > 0 {
                 context.delete(ground[0])
            }
            
            dataController.saveContext()
            
            
        } catch let error as NSError {
            print("Error in fetch :\(error)")
        }
    }
    
    func delete() {
        
        let dataController = AppDelegate.dataController!
        if let ground = self.ground {
            dataController.persistentContainer.viewContext.delete(ground)
        }
        
    }
    
    func reloadData() {
        
        let request : NSFetchRequest<Ground>  = Ground.fetchRequest()
        
        do {
            
            let dataController = AppDelegate.dataController!
            let center = try dataController.persistentContainer.viewContext.fetch(request)
            
            self.grounds.removeAll()
            
            for g in center {
                self.grounds.append(g)
            }
            
            
        } catch let error as NSError {
            ground = nil
            print("Error in fetch :\(error)")
        }
        
    }
    
    
}
