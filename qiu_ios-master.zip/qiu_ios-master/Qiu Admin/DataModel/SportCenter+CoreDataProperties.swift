//
//  SportCenter+CoreDataProperties.swift
//  
//
//  Created by Marcos Tirao on 9/6/17.
//
//

import Foundation
import CoreData


extension SportCenter {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<SportCenter> {
        return NSFetchRequest<SportCenter>(entityName: "SportCenter")
    }

    @NSManaged public var about: String?
    @NSManaged public var address: String?
    @NSManaged public var email: String?
    @NSManaged public var emailverify: Bool
    @NSManaged public var mobile: String?
    @NSManaged public var mobileverify: Bool
    @NSManaged public var name: String?
    @NSManaged public var id: String?
    @NSManaged public var feerequired: Bool
    @NSManaged public var latitude: Double
    @NSManaged public var longitude: Double
    @NSManaged public var openAt: Double
    @NSManaged public var closeAt: Double

}
