//
//  Ground+CoreDataProperties.swift
//  
//
//  Created by Marcos Tirao on 9/8/17.
//
//

import Foundation
import CoreData


extension Ground {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Ground> {
        return NSFetchRequest<Ground>(entityName: "Ground")
    }

    @NSManaged public var name: String?
    @NSManaged public var type: String?
    @NSManaged public var center: String?
    @NSManaged public var id: String?
    @NSManaged public var fee: Int16
    @NSManaged public var price: Int16


}
