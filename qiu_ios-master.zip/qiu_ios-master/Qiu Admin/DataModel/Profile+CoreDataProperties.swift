//
//  Profile+CoreDataProperties.swift
//  
//
//  Created by Marcos Tirao on 8/30/17.
//
//

import Foundation
import CoreData


extension Profile {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Profile> {
        return NSFetchRequest<Profile>(entityName: "Profile")
    }

    @NSManaged public var about: String?
    @NSManaged public var address: String?
    @NSManaged public var emailVerified: Bool
    @NSManaged public var email: String?
    @NSManaged public var mobile: String?
    @NSManaged public var mobileVerified: Bool
    @NSManaged public var facebookVerified: Bool
    @NSManaged public var name: String?

}
