//
//  LoginModel.swift
//  Qiu
//
//  Created by Marcos Tirao on 8/29/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation

class LoginModel {
    
    var token: String = ""
    
    init() {
        load()
    }
    
    func load() {
        
        let keychain = KeychainWrapper()
        if let keychainToken = keychain.myObject(forKey: "v_Data") as? String, keychainToken.count > 0 {
            self.token = keychainToken
        }
        
    }
    
    func delete() {
        
        let keychain = KeychainWrapper()
        keychain.mySetObject("", forKey: "v_Data")
        keychain.writeToKeychain()

    }
}
