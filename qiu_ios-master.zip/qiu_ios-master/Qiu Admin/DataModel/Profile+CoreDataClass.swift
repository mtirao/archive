//
//  Profile+CoreDataClass.swift
//  
//
//  Created by Marcos Tirao on 8/30/17.
//
//

import Foundation
import CoreData

@objc(Profile)
public class Profile: NSManagedObject {

}
