//
//  TypeModel.swift
//  Qiu
//
//  Created by Marcos Tirao on 26/09/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation
import CoreData

class TypeModel {
    
    private var types : [Types] = [Types]()
    private var type : Types?
    
    var name: String {
        set {
            type?.name = newValue
        }
        
        get {
            return type?.name ?? ""
        }
    }
    
    var players: Int16 {
        set {
            type?.players = newValue
        }
        
        get {
            return type?.players ?? 0
        }
    }
    
    var id : String {
        get {
            return type?.id ?? ""
        }
    }
    
    var count: Int {
        get {
            return self.types.count
        }
    }
    
    init() {
        self.reloadData()
    }
    
    func select(withId: String) {
        let request : NSFetchRequest = Types.fetchRequest()
        request.predicate = NSPredicate(format: "(id == %@)", withId)
        request.sortDescriptors = [NSSortDescriptor(key: "name", ascending: false)]
        
        
        do {
            let dataController = AppDelegate.dataController!
            let context = dataController.persistentContainer.viewContext
            
            let typs = try context.fetch(request)
            
            if typs.count > 0 {
                self.type = typs[0];
            }
            
            
        } catch let error as NSError {
            print("Error in fetch :\(error)")
        }
    }
    
    func select(index: Int) {
        if index>=0 && index < self.types.count {
            self.type = self.types[index]
        }else {
            self.type = nil
        }
    }
    
    func reloadData() {
        
        let request : NSFetchRequest<Types>  = Types.fetchRequest()
        
        do {
            
            let dataController = AppDelegate.dataController!
            let center = try dataController.persistentContainer.viewContext.fetch(request)
            
            self.types.removeAll()
            
            for g in center {
                self.types.append(g)
            }
            
        
        } catch let error as NSError {
            type = nil
            print("Error in fetch :\(error)")
        }
    }
}
