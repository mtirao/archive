//
//  TurnModel.swift
//  Qiu
//
//  Created by Marcos Tirao on 01/10/2017.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation
import CoreData

class TurnModel {
    
    private var turns : [Float: Turn?] = [Float: Turn?]()
    private var turn :  Turn?
    
    
    var name: String {
        set {
            turn?.name = newValue
        }
        
        get {
            return turn?.name ?? ""
        }
    }
    
    var ground: String {
        set {
            turn?.ground = newValue
        }
        
        get {
            return turn?.ground ?? ""
        }
    }
    
    var sportcenter: String {
        set {
            turn?.sportcenter = newValue
        }
        get {
            return turn?.sportcenter ?? ""
        }
    }
    
    var time: Float {
        set {
            turn?.time = newValue
        }
        
        get {
            return (turn?.time) ?? 0
        }
    }
    
    var date: Int64 {
        set {
            turn?.date = newValue
        }
        
        get {
            return turn?.date ?? 0
        }
    }
    
    var id: String {
        get {
           return  turn?.id ?? ""
        }
    }
    
    var count: Int {
        get {
            return self.turns.count
        }
    }
    
    func fetch(at date: Date) -> [Turn] {
        var turnss : [Turn] = [Turn]()
        
        do {
            
            let (year, month, day) = CalendarUtil.componentsForDate(forDate: date)
            let start = CalendarUtil.dateFromComponents(day: day, month: month, year: year, hour: 0, minute: 0, second: 0)
            let intDate = Theme.turnDateToInt(date: start)
            
            let request : NSFetchRequest<Turn> = Turn.fetchRequest()
            request.predicate = NSPredicate(format: "date == \(intDate)")
            request.sortDescriptors = [NSSortDescriptor(key: "time", ascending: true)]
            
            let dataController = AppDelegate.dataController!
            let turnsss = try dataController.persistentContainer.viewContext.fetch(request)
            
            for turn in turnsss {
                turnss.append(turn)
            }
            
            
        } catch let error as NSError {
            print("Error in fetch :\(error)")
        }
        
        return turnss
    }
    
    func fetch(for time: Float) -> Turn? {
        
        if let t = self.turns[time] {
            return t
        }
        
        return nil
    }
    
    func select(with id: String) {
        do {
            
            let request : NSFetchRequest<Turn> = Turn.fetchRequest()
            request.predicate = NSPredicate(format: "(id == %@)", id)
            request.sortDescriptors = [NSSortDescriptor(key: "from", ascending: false)]
            
            let dataController = AppDelegate.dataController!
            let turnss = try dataController.persistentContainer.viewContext.fetch(request)
            
            if turnss.count > 0 {
                turn = turnss[0]
            }
            
            
        } catch let error as NSError {
            print("Error in fetch :\(error)")
            turn = nil
        }
        
        turn = nil
    }
    
    func load(for date: Date, ground:String, sportcenter:String) {
        
        self.turns.removeAll()
        
        let turns = fetch(at:date)
        
        for turn in turns {
            self.turns[turn.time] = turn

        }
        
    }
    
    func delete(withId: String) {
        
        let request : NSFetchRequest = Turn.fetchRequest()
        request.predicate = NSPredicate(format: "(id == %@)", withId)        
        
        do {
            let dataController = AppDelegate.dataController!
            
            let context = dataController.persistentContainer.viewContext
            
            let turnss = try context.fetch(request)
            
            if turnss.count > 0 {
                context.delete(turnss[0])
            }
            
            dataController.saveContext()
            
            
        } catch let error as NSError {
            print("Error in fetch :\(error)")
        }
    }

    func reloadData() {
        
    }
    
    
}
