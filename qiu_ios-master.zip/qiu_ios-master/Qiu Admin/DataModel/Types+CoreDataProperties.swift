//
//  QiuTypes+CoreDataProperties.swift
//  
//
//  Created by Marcos Tirao on 8/22/17.
//
//

import Foundation
import CoreData


extension Types {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Types> {
        return NSFetchRequest<Types>(entityName: "Types")
    }

    @NSManaged public var name: String?
    @NSManaged public var id: String?
    @NSManaged public var players: Int16

}
