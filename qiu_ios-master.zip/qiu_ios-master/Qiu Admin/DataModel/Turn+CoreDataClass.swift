//
//  Turn+CoreDataClass.swift
//  Qiu
//
//  Created by Marcos Tirao on 06/05/2018.
//  Copyright © 2018 Marcos Tirao. All rights reserved.
//

import Foundation
import CoreData

@objc(Turn)
public class Turn : NSManagedObject {

}
