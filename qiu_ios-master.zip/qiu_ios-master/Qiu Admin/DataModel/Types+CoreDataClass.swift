//
//  QiuTypes+CoreDataClass.swift
//  
//
//  Created by Marcos Tirao on 8/22/17.
//
//

import Foundation
import CoreData


@objc(Types)
public class Types: NSManagedObject {

}
