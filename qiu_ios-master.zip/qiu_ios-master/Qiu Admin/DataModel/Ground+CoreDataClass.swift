//
//  Ground+CoreDataClass.swift
//  
//
//  Created by Marcos Tirao on 9/8/17.
//
//

import Foundation
import CoreData

@objc(Ground)
public class Ground: NSManagedObject {

}
