//
//  TypeCollectionModel.swift
//  Qiu
//
//  Created by Marcos Tirao on 8/22/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import UIKit
import CoreData

class TypeCollectionModel: NSObject, UICollectionViewDataSource{
    
    static let cellIdentifier = "sportCell"
    
    var qiuTypes : TypeModel?
    var selectedType : [Bool]?
    
    let label = UILabel()
    
    func loadData() {
        if qiuTypes == nil {
            qiuTypes = TypeModel()
        }
        
        qiuTypes?.reloadData()
        
        selectedType = Array(repeating: false, count:qiuTypes?.count ?? 0)
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        let count = qiuTypes?.count ?? 0
        
        if(count == 0) {
            label.text = "No courts yet!"
            collectionView.backgroundView = label
        }else {
            collectionView.backgroundView = nil
        }
        
        return count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: TypeCollectionModel.cellIdentifier, for: indexPath as IndexPath)
        cell.backgroundColor = Theme.dayColor
        
        if let sportCell = cell as? SportCollectionCell {
            sportCell.sportImage.image = UIImage(named:"sport-soccer")
            qiuTypes?.select(index: indexPath.row)
            sportCell.sportName.text = qiuTypes?.name ?? ""
            sportCell.setSelect(state: selectedType![indexPath.row])
            return sportCell
        }
        
        return cell
    }
    
    func select(itemAt indexPath: IndexPath, collectionView: UICollectionView) -> String {
        
        if let sportCell = collectionView.cellForItem(at: indexPath) as? SportCollectionCell {
            sportCell.setSelect(state: true)
        }
        
        selectedType![indexPath.row] = true
        self.qiuTypes?.select(index: indexPath.row)
        
        return self.qiuTypes?.id ?? ""
    }
    
    func deselect(itemAt indexPath: IndexPath, collectionView: UICollectionView) {
        
        if let sportCell = collectionView.cellForItem(at: indexPath) as? SportCollectionCell {
            sportCell.setSelect(state: false)
        }
        
        selectedType![indexPath.row] = false
     
    }
    
    func select(itemWithId: String, collectionView: UICollectionView) {
        
        guard let types = self.qiuTypes else {
            return
        }
        
        for i in 0 ..< types.count {
            types.select(index: i)
            if itemWithId == types.id {
                _ = self.select(itemAt: IndexPath(row: i, section: 0), collectionView: collectionView)
            }
        }
        
    }
}
