//
//  SportCenterModel.swift
//  Qiu
//
//  Created by Marcos Tirao on 9/7/17.
//  Copyright © 2017 Marcos Tirao. All rights reserved.
//

import Foundation
import CoreData

class SportCenterModel: ModelProtocol {
    
    private var sportCenter : SportCenter?
    
    var about : String {
        get {
            return sportCenter?.about ?? "ABOUT".localizable()
        }
        
        set {
            sportCenter?.about = newValue
        }
    }
    
    var address : String {
        get {
            return sportCenter?.address ?? "ADDRESS".localizable()
        }
        
        set {
            sportCenter?.address = newValue
        }
    }
    
    var contact : String {
        get {
            return sportCenter?.email ?? "CONTACT".localizable()
        }
        
        set {
            sportCenter?.email = newValue
        }
    }
    
    var name : String {
        get {
            return sportCenter?.name ?? "NAME".localizable()
        }
        
        set {
            sportCenter?.name = newValue
        }
    }
    
    var phone : String {
        get {
            return sportCenter?.mobile ?? "PHONE".localizable()
        }
        
        set {
            sportCenter?.mobile = newValue
        }
    }
    
    var latitud: Double {
        get {
            return sportCenter?.latitude ?? 0
        }
        
        set {
            sportCenter?.latitude = newValue
        }
    }
    
    var longitude : Double {
        get {
            return sportCenter?.longitude ?? 0
        }
        
        set {
            sportCenter?.longitude = newValue
        }
    }
    
    var openAt: Double {
        get {
            return sportCenter?.openAt ?? 0
        }
        
        set {
            sportCenter?.openAt = newValue
        }
    }
    
    var closeAt: Double {
        get {
            return sportCenter?.closeAt ?? 23
        }
        
        set {
            sportCenter?.closeAt = newValue
        }
    }
    
    var id:String {
        get {
            return sportCenter?.id ?? ""
        }
    }
    
    var feerequired: Bool {
        get {
            return sportCenter?.feerequired ?? false
        }
        
        set {
            sportCenter?.feerequired = newValue
        }
    }
    
    var emailverify: Bool {
        get {
            return sportCenter?.emailverify ?? false
        }
        
        set {
            sportCenter?.emailverify = newValue
        }
    }
    
    var mobileverify: Bool {
        get {
            return sportCenter?.mobileverify ?? false
        }
        
        set {
            sportCenter?.mobileverify = newValue
        }
    }
    
    var isLoad : Bool {
        get {
            return self.sportCenter != nil
        }
    }
    
    init() {
        self.reloadData()
    }
    
    
    func delete() {
        
        do {
            let dataController = AppDelegate.dataController!
            if let sportCenter = self.sportCenter {
                dataController.persistentContainer.viewContext.delete(sportCenter)
                try dataController.persistentContainer.viewContext.save()
            }
        } catch let error as NSError {
            sportCenter = nil
            print("Error in delete :\(error)")
        }
    }
    
    func reloadData() {
        
        let request : NSFetchRequest<SportCenter>  = SportCenter.fetchRequest()
        
        do {
            
            let dataController = AppDelegate.dataController!
            let center = try dataController.persistentContainer.viewContext.fetch(request)
            
            
            if center.count > 0 {
                sportCenter = center[0]
            }else {
                sportCenter = nil
            }
                
           
        } catch let error as NSError {
            sportCenter = nil
            print("Error in fetch :\(error)")
        }
        
    }

    
}
