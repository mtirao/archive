//
//  SportCenter+CoreDataClass.swift
//  
//
//  Created by Marcos Tirao on 9/6/17.
//
//

import Foundation
import CoreData

@objc(SportCenter)
public class SportCenter: NSManagedObject {

}
