//
//  Turn+CoreDataProperties.swift
//  
//
//  Created by Marcos Tirao on 09/05/2018.
//
//

import Foundation
import CoreData


extension Turn {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Turn> {
        return NSFetchRequest<Turn>(entityName: "Turn")
    }

    @NSManaged public var date: Int64
    @NSManaged public var ground: String?
    @NSManaged public var id: String?
    @NSManaged public var isstitcky: Bool
    @NSManaged public var name: String?
    @NSManaged public var partner: String?
    @NSManaged public var phone: String?
    @NSManaged public var sportcenter: String?
    @NSManaged public var status: String?
    @NSManaged public var time: Float
    @NSManaged public var token: String?

}
